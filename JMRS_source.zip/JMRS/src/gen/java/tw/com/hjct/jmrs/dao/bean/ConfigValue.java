package tw.com.hjct.jmrs.dao.bean;

public class ConfigValue extends ConfigValueKey {
    private String value;

    private String state;

    private String readOnly;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value == null ? null : value.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getReadOnly() {
        return readOnly;
    }

    public void setReadOnly(String readOnly) {
        this.readOnly = readOnly == null ? null : readOnly.trim();
    }
}