package tw.com.hjct.jmrs.dao.bean;

import java.util.ArrayList;
import java.util.List;

public class RdJobInfoExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public RdJobInfoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andNumIsNull() {
            addCriterion("NUM is null");
            return (Criteria) this;
        }

        public Criteria andNumIsNotNull() {
            addCriterion("NUM is not null");
            return (Criteria) this;
        }

        public Criteria andNumEqualTo(String value) {
            addCriterion("NUM =", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumNotEqualTo(String value) {
            addCriterion("NUM <>", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumGreaterThan(String value) {
            addCriterion("NUM >", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumGreaterThanOrEqualTo(String value) {
            addCriterion("NUM >=", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumLessThan(String value) {
            addCriterion("NUM <", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumLessThanOrEqualTo(String value) {
            addCriterion("NUM <=", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumLike(String value) {
            addCriterion("NUM like", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumNotLike(String value) {
            addCriterion("NUM not like", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumIn(List<String> values) {
            addCriterion("NUM in", values, "num");
            return (Criteria) this;
        }

        public Criteria andNumNotIn(List<String> values) {
            addCriterion("NUM not in", values, "num");
            return (Criteria) this;
        }

        public Criteria andNumBetween(String value1, String value2) {
            addCriterion("NUM between", value1, value2, "num");
            return (Criteria) this;
        }

        public Criteria andNumNotBetween(String value1, String value2) {
            addCriterion("NUM not between", value1, value2, "num");
            return (Criteria) this;
        }

        public Criteria andJobnameIsNull() {
            addCriterion("JOBNAME is null");
            return (Criteria) this;
        }

        public Criteria andJobnameIsNotNull() {
            addCriterion("JOBNAME is not null");
            return (Criteria) this;
        }

        public Criteria andJobnameEqualTo(String value) {
            addCriterion("JOBNAME =", value, "jobname");
            return (Criteria) this;
        }

        public Criteria andJobnameNotEqualTo(String value) {
            addCriterion("JOBNAME <>", value, "jobname");
            return (Criteria) this;
        }

        public Criteria andJobnameGreaterThan(String value) {
            addCriterion("JOBNAME >", value, "jobname");
            return (Criteria) this;
        }

        public Criteria andJobnameGreaterThanOrEqualTo(String value) {
            addCriterion("JOBNAME >=", value, "jobname");
            return (Criteria) this;
        }

        public Criteria andJobnameLessThan(String value) {
            addCriterion("JOBNAME <", value, "jobname");
            return (Criteria) this;
        }

        public Criteria andJobnameLessThanOrEqualTo(String value) {
            addCriterion("JOBNAME <=", value, "jobname");
            return (Criteria) this;
        }

        public Criteria andJobnameLike(String value) {
            addCriterion("JOBNAME like", value, "jobname");
            return (Criteria) this;
        }

        public Criteria andJobnameNotLike(String value) {
            addCriterion("JOBNAME not like", value, "jobname");
            return (Criteria) this;
        }

        public Criteria andJobnameIn(List<String> values) {
            addCriterion("JOBNAME in", values, "jobname");
            return (Criteria) this;
        }

        public Criteria andJobnameNotIn(List<String> values) {
            addCriterion("JOBNAME not in", values, "jobname");
            return (Criteria) this;
        }

        public Criteria andJobnameBetween(String value1, String value2) {
            addCriterion("JOBNAME between", value1, value2, "jobname");
            return (Criteria) this;
        }

        public Criteria andJobnameNotBetween(String value1, String value2) {
            addCriterion("JOBNAME not between", value1, value2, "jobname");
            return (Criteria) this;
        }

        public Criteria andJobsysIsNull() {
            addCriterion("JOBSYS is null");
            return (Criteria) this;
        }

        public Criteria andJobsysIsNotNull() {
            addCriterion("JOBSYS is not null");
            return (Criteria) this;
        }

        public Criteria andJobsysEqualTo(String value) {
            addCriterion("JOBSYS =", value, "jobsys");
            return (Criteria) this;
        }

        public Criteria andJobsysNotEqualTo(String value) {
            addCriterion("JOBSYS <>", value, "jobsys");
            return (Criteria) this;
        }

        public Criteria andJobsysGreaterThan(String value) {
            addCriterion("JOBSYS >", value, "jobsys");
            return (Criteria) this;
        }

        public Criteria andJobsysGreaterThanOrEqualTo(String value) {
            addCriterion("JOBSYS >=", value, "jobsys");
            return (Criteria) this;
        }

        public Criteria andJobsysLessThan(String value) {
            addCriterion("JOBSYS <", value, "jobsys");
            return (Criteria) this;
        }

        public Criteria andJobsysLessThanOrEqualTo(String value) {
            addCriterion("JOBSYS <=", value, "jobsys");
            return (Criteria) this;
        }

        public Criteria andJobsysLike(String value) {
            addCriterion("JOBSYS like", value, "jobsys");
            return (Criteria) this;
        }

        public Criteria andJobsysNotLike(String value) {
            addCriterion("JOBSYS not like", value, "jobsys");
            return (Criteria) this;
        }

        public Criteria andJobsysIn(List<String> values) {
            addCriterion("JOBSYS in", values, "jobsys");
            return (Criteria) this;
        }

        public Criteria andJobsysNotIn(List<String> values) {
            addCriterion("JOBSYS not in", values, "jobsys");
            return (Criteria) this;
        }

        public Criteria andJobsysBetween(String value1, String value2) {
            addCriterion("JOBSYS between", value1, value2, "jobsys");
            return (Criteria) this;
        }

        public Criteria andJobsysNotBetween(String value1, String value2) {
            addCriterion("JOBSYS not between", value1, value2, "jobsys");
            return (Criteria) this;
        }

        public Criteria andFileDescriptionIsNull() {
            addCriterion("FILE_DESCRIPTION is null");
            return (Criteria) this;
        }

        public Criteria andFileDescriptionIsNotNull() {
            addCriterion("FILE_DESCRIPTION is not null");
            return (Criteria) this;
        }

        public Criteria andFileDescriptionEqualTo(String value) {
            addCriterion("FILE_DESCRIPTION =", value, "fileDescription");
            return (Criteria) this;
        }

        public Criteria andFileDescriptionNotEqualTo(String value) {
            addCriterion("FILE_DESCRIPTION <>", value, "fileDescription");
            return (Criteria) this;
        }

        public Criteria andFileDescriptionGreaterThan(String value) {
            addCriterion("FILE_DESCRIPTION >", value, "fileDescription");
            return (Criteria) this;
        }

        public Criteria andFileDescriptionGreaterThanOrEqualTo(String value) {
            addCriterion("FILE_DESCRIPTION >=", value, "fileDescription");
            return (Criteria) this;
        }

        public Criteria andFileDescriptionLessThan(String value) {
            addCriterion("FILE_DESCRIPTION <", value, "fileDescription");
            return (Criteria) this;
        }

        public Criteria andFileDescriptionLessThanOrEqualTo(String value) {
            addCriterion("FILE_DESCRIPTION <=", value, "fileDescription");
            return (Criteria) this;
        }

        public Criteria andFileDescriptionLike(String value) {
            addCriterion("FILE_DESCRIPTION like", value, "fileDescription");
            return (Criteria) this;
        }

        public Criteria andFileDescriptionNotLike(String value) {
            addCriterion("FILE_DESCRIPTION not like", value, "fileDescription");
            return (Criteria) this;
        }

        public Criteria andFileDescriptionIn(List<String> values) {
            addCriterion("FILE_DESCRIPTION in", values, "fileDescription");
            return (Criteria) this;
        }

        public Criteria andFileDescriptionNotIn(List<String> values) {
            addCriterion("FILE_DESCRIPTION not in", values, "fileDescription");
            return (Criteria) this;
        }

        public Criteria andFileDescriptionBetween(String value1, String value2) {
            addCriterion("FILE_DESCRIPTION between", value1, value2, "fileDescription");
            return (Criteria) this;
        }

        public Criteria andFileDescriptionNotBetween(String value1, String value2) {
            addCriterion("FILE_DESCRIPTION not between", value1, value2, "fileDescription");
            return (Criteria) this;
        }

        public Criteria andJsNameIsNull() {
            addCriterion("JS_NAME is null");
            return (Criteria) this;
        }

        public Criteria andJsNameIsNotNull() {
            addCriterion("JS_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andJsNameEqualTo(String value) {
            addCriterion("JS_NAME =", value, "jsName");
            return (Criteria) this;
        }

        public Criteria andJsNameNotEqualTo(String value) {
            addCriterion("JS_NAME <>", value, "jsName");
            return (Criteria) this;
        }

        public Criteria andJsNameGreaterThan(String value) {
            addCriterion("JS_NAME >", value, "jsName");
            return (Criteria) this;
        }

        public Criteria andJsNameGreaterThanOrEqualTo(String value) {
            addCriterion("JS_NAME >=", value, "jsName");
            return (Criteria) this;
        }

        public Criteria andJsNameLessThan(String value) {
            addCriterion("JS_NAME <", value, "jsName");
            return (Criteria) this;
        }

        public Criteria andJsNameLessThanOrEqualTo(String value) {
            addCriterion("JS_NAME <=", value, "jsName");
            return (Criteria) this;
        }

        public Criteria andJsNameLike(String value) {
            addCriterion("JS_NAME like", value, "jsName");
            return (Criteria) this;
        }

        public Criteria andJsNameNotLike(String value) {
            addCriterion("JS_NAME not like", value, "jsName");
            return (Criteria) this;
        }

        public Criteria andJsNameIn(List<String> values) {
            addCriterion("JS_NAME in", values, "jsName");
            return (Criteria) this;
        }

        public Criteria andJsNameNotIn(List<String> values) {
            addCriterion("JS_NAME not in", values, "jsName");
            return (Criteria) this;
        }

        public Criteria andJsNameBetween(String value1, String value2) {
            addCriterion("JS_NAME between", value1, value2, "jsName");
            return (Criteria) this;
        }

        public Criteria andJsNameNotBetween(String value1, String value2) {
            addCriterion("JS_NAME not between", value1, value2, "jsName");
            return (Criteria) this;
        }

        public Criteria andFirstNameIsNull() {
            addCriterion("FIRST_NAME is null");
            return (Criteria) this;
        }

        public Criteria andFirstNameIsNotNull() {
            addCriterion("FIRST_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andFirstNameEqualTo(String value) {
            addCriterion("FIRST_NAME =", value, "firstName");
            return (Criteria) this;
        }

        public Criteria andFirstNameNotEqualTo(String value) {
            addCriterion("FIRST_NAME <>", value, "firstName");
            return (Criteria) this;
        }

        public Criteria andFirstNameGreaterThan(String value) {
            addCriterion("FIRST_NAME >", value, "firstName");
            return (Criteria) this;
        }

        public Criteria andFirstNameGreaterThanOrEqualTo(String value) {
            addCriterion("FIRST_NAME >=", value, "firstName");
            return (Criteria) this;
        }

        public Criteria andFirstNameLessThan(String value) {
            addCriterion("FIRST_NAME <", value, "firstName");
            return (Criteria) this;
        }

        public Criteria andFirstNameLessThanOrEqualTo(String value) {
            addCriterion("FIRST_NAME <=", value, "firstName");
            return (Criteria) this;
        }

        public Criteria andFirstNameLike(String value) {
            addCriterion("FIRST_NAME like", value, "firstName");
            return (Criteria) this;
        }

        public Criteria andFirstNameNotLike(String value) {
            addCriterion("FIRST_NAME not like", value, "firstName");
            return (Criteria) this;
        }

        public Criteria andFirstNameIn(List<String> values) {
            addCriterion("FIRST_NAME in", values, "firstName");
            return (Criteria) this;
        }

        public Criteria andFirstNameNotIn(List<String> values) {
            addCriterion("FIRST_NAME not in", values, "firstName");
            return (Criteria) this;
        }

        public Criteria andFirstNameBetween(String value1, String value2) {
            addCriterion("FIRST_NAME between", value1, value2, "firstName");
            return (Criteria) this;
        }

        public Criteria andFirstNameNotBetween(String value1, String value2) {
            addCriterion("FIRST_NAME not between", value1, value2, "firstName");
            return (Criteria) this;
        }

        public Criteria andSecondNameIsNull() {
            addCriterion("SECOND_NAME is null");
            return (Criteria) this;
        }

        public Criteria andSecondNameIsNotNull() {
            addCriterion("SECOND_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andSecondNameEqualTo(String value) {
            addCriterion("SECOND_NAME =", value, "secondName");
            return (Criteria) this;
        }

        public Criteria andSecondNameNotEqualTo(String value) {
            addCriterion("SECOND_NAME <>", value, "secondName");
            return (Criteria) this;
        }

        public Criteria andSecondNameGreaterThan(String value) {
            addCriterion("SECOND_NAME >", value, "secondName");
            return (Criteria) this;
        }

        public Criteria andSecondNameGreaterThanOrEqualTo(String value) {
            addCriterion("SECOND_NAME >=", value, "secondName");
            return (Criteria) this;
        }

        public Criteria andSecondNameLessThan(String value) {
            addCriterion("SECOND_NAME <", value, "secondName");
            return (Criteria) this;
        }

        public Criteria andSecondNameLessThanOrEqualTo(String value) {
            addCriterion("SECOND_NAME <=", value, "secondName");
            return (Criteria) this;
        }

        public Criteria andSecondNameLike(String value) {
            addCriterion("SECOND_NAME like", value, "secondName");
            return (Criteria) this;
        }

        public Criteria andSecondNameNotLike(String value) {
            addCriterion("SECOND_NAME not like", value, "secondName");
            return (Criteria) this;
        }

        public Criteria andSecondNameIn(List<String> values) {
            addCriterion("SECOND_NAME in", values, "secondName");
            return (Criteria) this;
        }

        public Criteria andSecondNameNotIn(List<String> values) {
            addCriterion("SECOND_NAME not in", values, "secondName");
            return (Criteria) this;
        }

        public Criteria andSecondNameBetween(String value1, String value2) {
            addCriterion("SECOND_NAME between", value1, value2, "secondName");
            return (Criteria) this;
        }

        public Criteria andSecondNameNotBetween(String value1, String value2) {
            addCriterion("SECOND_NAME not between", value1, value2, "secondName");
            return (Criteria) this;
        }

        public Criteria andIsdraftIsNull() {
            addCriterion("ISDRAFT is null");
            return (Criteria) this;
        }

        public Criteria andIsdraftIsNotNull() {
            addCriterion("ISDRAFT is not null");
            return (Criteria) this;
        }

        public Criteria andIsdraftEqualTo(String value) {
            addCriterion("ISDRAFT =", value, "isdraft");
            return (Criteria) this;
        }

        public Criteria andIsdraftNotEqualTo(String value) {
            addCriterion("ISDRAFT <>", value, "isdraft");
            return (Criteria) this;
        }

        public Criteria andIsdraftGreaterThan(String value) {
            addCriterion("ISDRAFT >", value, "isdraft");
            return (Criteria) this;
        }

        public Criteria andIsdraftGreaterThanOrEqualTo(String value) {
            addCriterion("ISDRAFT >=", value, "isdraft");
            return (Criteria) this;
        }

        public Criteria andIsdraftLessThan(String value) {
            addCriterion("ISDRAFT <", value, "isdraft");
            return (Criteria) this;
        }

        public Criteria andIsdraftLessThanOrEqualTo(String value) {
            addCriterion("ISDRAFT <=", value, "isdraft");
            return (Criteria) this;
        }

        public Criteria andIsdraftLike(String value) {
            addCriterion("ISDRAFT like", value, "isdraft");
            return (Criteria) this;
        }

        public Criteria andIsdraftNotLike(String value) {
            addCriterion("ISDRAFT not like", value, "isdraft");
            return (Criteria) this;
        }

        public Criteria andIsdraftIn(List<String> values) {
            addCriterion("ISDRAFT in", values, "isdraft");
            return (Criteria) this;
        }

        public Criteria andIsdraftNotIn(List<String> values) {
            addCriterion("ISDRAFT not in", values, "isdraft");
            return (Criteria) this;
        }

        public Criteria andIsdraftBetween(String value1, String value2) {
            addCriterion("ISDRAFT between", value1, value2, "isdraft");
            return (Criteria) this;
        }

        public Criteria andIsdraftNotBetween(String value1, String value2) {
            addCriterion("ISDRAFT not between", value1, value2, "isdraft");
            return (Criteria) this;
        }

        public Criteria andGroupNameIsNull() {
            addCriterion("GROUP_NAME is null");
            return (Criteria) this;
        }

        public Criteria andGroupNameIsNotNull() {
            addCriterion("GROUP_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andGroupNameEqualTo(String value) {
            addCriterion("GROUP_NAME =", value, "groupName");
            return (Criteria) this;
        }

        public Criteria andGroupNameNotEqualTo(String value) {
            addCriterion("GROUP_NAME <>", value, "groupName");
            return (Criteria) this;
        }

        public Criteria andGroupNameGreaterThan(String value) {
            addCriterion("GROUP_NAME >", value, "groupName");
            return (Criteria) this;
        }

        public Criteria andGroupNameGreaterThanOrEqualTo(String value) {
            addCriterion("GROUP_NAME >=", value, "groupName");
            return (Criteria) this;
        }

        public Criteria andGroupNameLessThan(String value) {
            addCriterion("GROUP_NAME <", value, "groupName");
            return (Criteria) this;
        }

        public Criteria andGroupNameLessThanOrEqualTo(String value) {
            addCriterion("GROUP_NAME <=", value, "groupName");
            return (Criteria) this;
        }

        public Criteria andGroupNameLike(String value) {
            addCriterion("GROUP_NAME like", value, "groupName");
            return (Criteria) this;
        }

        public Criteria andGroupNameNotLike(String value) {
            addCriterion("GROUP_NAME not like", value, "groupName");
            return (Criteria) this;
        }

        public Criteria andGroupNameIn(List<String> values) {
            addCriterion("GROUP_NAME in", values, "groupName");
            return (Criteria) this;
        }

        public Criteria andGroupNameNotIn(List<String> values) {
            addCriterion("GROUP_NAME not in", values, "groupName");
            return (Criteria) this;
        }

        public Criteria andGroupNameBetween(String value1, String value2) {
            addCriterion("GROUP_NAME between", value1, value2, "groupName");
            return (Criteria) this;
        }

        public Criteria andGroupNameNotBetween(String value1, String value2) {
            addCriterion("GROUP_NAME not between", value1, value2, "groupName");
            return (Criteria) this;
        }

        public Criteria andIssendmailIsNull() {
            addCriterion("ISSENDMAIL is null");
            return (Criteria) this;
        }

        public Criteria andIssendmailIsNotNull() {
            addCriterion("ISSENDMAIL is not null");
            return (Criteria) this;
        }

        public Criteria andIssendmailEqualTo(String value) {
            addCriterion("ISSENDMAIL =", value, "issendmail");
            return (Criteria) this;
        }

        public Criteria andIssendmailNotEqualTo(String value) {
            addCriterion("ISSENDMAIL <>", value, "issendmail");
            return (Criteria) this;
        }

        public Criteria andIssendmailGreaterThan(String value) {
            addCriterion("ISSENDMAIL >", value, "issendmail");
            return (Criteria) this;
        }

        public Criteria andIssendmailGreaterThanOrEqualTo(String value) {
            addCriterion("ISSENDMAIL >=", value, "issendmail");
            return (Criteria) this;
        }

        public Criteria andIssendmailLessThan(String value) {
            addCriterion("ISSENDMAIL <", value, "issendmail");
            return (Criteria) this;
        }

        public Criteria andIssendmailLessThanOrEqualTo(String value) {
            addCriterion("ISSENDMAIL <=", value, "issendmail");
            return (Criteria) this;
        }

        public Criteria andIssendmailLike(String value) {
            addCriterion("ISSENDMAIL like", value, "issendmail");
            return (Criteria) this;
        }

        public Criteria andIssendmailNotLike(String value) {
            addCriterion("ISSENDMAIL not like", value, "issendmail");
            return (Criteria) this;
        }

        public Criteria andIssendmailIn(List<String> values) {
            addCriterion("ISSENDMAIL in", values, "issendmail");
            return (Criteria) this;
        }

        public Criteria andIssendmailNotIn(List<String> values) {
            addCriterion("ISSENDMAIL not in", values, "issendmail");
            return (Criteria) this;
        }

        public Criteria andIssendmailBetween(String value1, String value2) {
            addCriterion("ISSENDMAIL between", value1, value2, "issendmail");
            return (Criteria) this;
        }

        public Criteria andIssendmailNotBetween(String value1, String value2) {
            addCriterion("ISSENDMAIL not between", value1, value2, "issendmail");
            return (Criteria) this;
        }

        public Criteria andMemoIsNull() {
            addCriterion("MEMO is null");
            return (Criteria) this;
        }

        public Criteria andMemoIsNotNull() {
            addCriterion("MEMO is not null");
            return (Criteria) this;
        }

        public Criteria andMemoEqualTo(String value) {
            addCriterion("MEMO =", value, "memo");
            return (Criteria) this;
        }

        public Criteria andMemoNotEqualTo(String value) {
            addCriterion("MEMO <>", value, "memo");
            return (Criteria) this;
        }

        public Criteria andMemoGreaterThan(String value) {
            addCriterion("MEMO >", value, "memo");
            return (Criteria) this;
        }

        public Criteria andMemoGreaterThanOrEqualTo(String value) {
            addCriterion("MEMO >=", value, "memo");
            return (Criteria) this;
        }

        public Criteria andMemoLessThan(String value) {
            addCriterion("MEMO <", value, "memo");
            return (Criteria) this;
        }

        public Criteria andMemoLessThanOrEqualTo(String value) {
            addCriterion("MEMO <=", value, "memo");
            return (Criteria) this;
        }

        public Criteria andMemoLike(String value) {
            addCriterion("MEMO like", value, "memo");
            return (Criteria) this;
        }

        public Criteria andMemoNotLike(String value) {
            addCriterion("MEMO not like", value, "memo");
            return (Criteria) this;
        }

        public Criteria andMemoIn(List<String> values) {
            addCriterion("MEMO in", values, "memo");
            return (Criteria) this;
        }

        public Criteria andMemoNotIn(List<String> values) {
            addCriterion("MEMO not in", values, "memo");
            return (Criteria) this;
        }

        public Criteria andMemoBetween(String value1, String value2) {
            addCriterion("MEMO between", value1, value2, "memo");
            return (Criteria) this;
        }

        public Criteria andMemoNotBetween(String value1, String value2) {
            addCriterion("MEMO not between", value1, value2, "memo");
            return (Criteria) this;
        }

        public Criteria andJobStimeIsNull() {
            addCriterion("JOB_STIME is null");
            return (Criteria) this;
        }

        public Criteria andJobStimeIsNotNull() {
            addCriterion("JOB_STIME is not null");
            return (Criteria) this;
        }

        public Criteria andJobStimeEqualTo(String value) {
            addCriterion("JOB_STIME =", value, "jobStime");
            return (Criteria) this;
        }

        public Criteria andJobStimeNotEqualTo(String value) {
            addCriterion("JOB_STIME <>", value, "jobStime");
            return (Criteria) this;
        }

        public Criteria andJobStimeGreaterThan(String value) {
            addCriterion("JOB_STIME >", value, "jobStime");
            return (Criteria) this;
        }

        public Criteria andJobStimeGreaterThanOrEqualTo(String value) {
            addCriterion("JOB_STIME >=", value, "jobStime");
            return (Criteria) this;
        }

        public Criteria andJobStimeLessThan(String value) {
            addCriterion("JOB_STIME <", value, "jobStime");
            return (Criteria) this;
        }

        public Criteria andJobStimeLessThanOrEqualTo(String value) {
            addCriterion("JOB_STIME <=", value, "jobStime");
            return (Criteria) this;
        }

        public Criteria andJobStimeLike(String value) {
            addCriterion("JOB_STIME like", value, "jobStime");
            return (Criteria) this;
        }

        public Criteria andJobStimeNotLike(String value) {
            addCriterion("JOB_STIME not like", value, "jobStime");
            return (Criteria) this;
        }

        public Criteria andJobStimeIn(List<String> values) {
            addCriterion("JOB_STIME in", values, "jobStime");
            return (Criteria) this;
        }

        public Criteria andJobStimeNotIn(List<String> values) {
            addCriterion("JOB_STIME not in", values, "jobStime");
            return (Criteria) this;
        }

        public Criteria andJobStimeBetween(String value1, String value2) {
            addCriterion("JOB_STIME between", value1, value2, "jobStime");
            return (Criteria) this;
        }

        public Criteria andJobStimeNotBetween(String value1, String value2) {
            addCriterion("JOB_STIME not between", value1, value2, "jobStime");
            return (Criteria) this;
        }

        public Criteria andJobEtimeIsNull() {
            addCriterion("JOB_ETIME is null");
            return (Criteria) this;
        }

        public Criteria andJobEtimeIsNotNull() {
            addCriterion("JOB_ETIME is not null");
            return (Criteria) this;
        }

        public Criteria andJobEtimeEqualTo(String value) {
            addCriterion("JOB_ETIME =", value, "jobEtime");
            return (Criteria) this;
        }

        public Criteria andJobEtimeNotEqualTo(String value) {
            addCriterion("JOB_ETIME <>", value, "jobEtime");
            return (Criteria) this;
        }

        public Criteria andJobEtimeGreaterThan(String value) {
            addCriterion("JOB_ETIME >", value, "jobEtime");
            return (Criteria) this;
        }

        public Criteria andJobEtimeGreaterThanOrEqualTo(String value) {
            addCriterion("JOB_ETIME >=", value, "jobEtime");
            return (Criteria) this;
        }

        public Criteria andJobEtimeLessThan(String value) {
            addCriterion("JOB_ETIME <", value, "jobEtime");
            return (Criteria) this;
        }

        public Criteria andJobEtimeLessThanOrEqualTo(String value) {
            addCriterion("JOB_ETIME <=", value, "jobEtime");
            return (Criteria) this;
        }

        public Criteria andJobEtimeLike(String value) {
            addCriterion("JOB_ETIME like", value, "jobEtime");
            return (Criteria) this;
        }

        public Criteria andJobEtimeNotLike(String value) {
            addCriterion("JOB_ETIME not like", value, "jobEtime");
            return (Criteria) this;
        }

        public Criteria andJobEtimeIn(List<String> values) {
            addCriterion("JOB_ETIME in", values, "jobEtime");
            return (Criteria) this;
        }

        public Criteria andJobEtimeNotIn(List<String> values) {
            addCriterion("JOB_ETIME not in", values, "jobEtime");
            return (Criteria) this;
        }

        public Criteria andJobEtimeBetween(String value1, String value2) {
            addCriterion("JOB_ETIME between", value1, value2, "jobEtime");
            return (Criteria) this;
        }

        public Criteria andJobEtimeNotBetween(String value1, String value2) {
            addCriterion("JOB_ETIME not between", value1, value2, "jobEtime");
            return (Criteria) this;
        }

        public Criteria andIsrunIsNull() {
            addCriterion("ISRUN is null");
            return (Criteria) this;
        }

        public Criteria andIsrunIsNotNull() {
            addCriterion("ISRUN is not null");
            return (Criteria) this;
        }

        public Criteria andIsrunEqualTo(String value) {
            addCriterion("ISRUN =", value, "isrun");
            return (Criteria) this;
        }

        public Criteria andIsrunNotEqualTo(String value) {
            addCriterion("ISRUN <>", value, "isrun");
            return (Criteria) this;
        }

        public Criteria andIsrunGreaterThan(String value) {
            addCriterion("ISRUN >", value, "isrun");
            return (Criteria) this;
        }

        public Criteria andIsrunGreaterThanOrEqualTo(String value) {
            addCriterion("ISRUN >=", value, "isrun");
            return (Criteria) this;
        }

        public Criteria andIsrunLessThan(String value) {
            addCriterion("ISRUN <", value, "isrun");
            return (Criteria) this;
        }

        public Criteria andIsrunLessThanOrEqualTo(String value) {
            addCriterion("ISRUN <=", value, "isrun");
            return (Criteria) this;
        }

        public Criteria andIsrunLike(String value) {
            addCriterion("ISRUN like", value, "isrun");
            return (Criteria) this;
        }

        public Criteria andIsrunNotLike(String value) {
            addCriterion("ISRUN not like", value, "isrun");
            return (Criteria) this;
        }

        public Criteria andIsrunIn(List<String> values) {
            addCriterion("ISRUN in", values, "isrun");
            return (Criteria) this;
        }

        public Criteria andIsrunNotIn(List<String> values) {
            addCriterion("ISRUN not in", values, "isrun");
            return (Criteria) this;
        }

        public Criteria andIsrunBetween(String value1, String value2) {
            addCriterion("ISRUN between", value1, value2, "isrun");
            return (Criteria) this;
        }

        public Criteria andIsrunNotBetween(String value1, String value2) {
            addCriterion("ISRUN not between", value1, value2, "isrun");
            return (Criteria) this;
        }

        public Criteria andMflagIsNull() {
            addCriterion("MFLAG is null");
            return (Criteria) this;
        }

        public Criteria andMflagIsNotNull() {
            addCriterion("MFLAG is not null");
            return (Criteria) this;
        }

        public Criteria andMflagEqualTo(String value) {
            addCriterion("MFLAG =", value, "mflag");
            return (Criteria) this;
        }

        public Criteria andMflagNotEqualTo(String value) {
            addCriterion("MFLAG <>", value, "mflag");
            return (Criteria) this;
        }

        public Criteria andMflagGreaterThan(String value) {
            addCriterion("MFLAG >", value, "mflag");
            return (Criteria) this;
        }

        public Criteria andMflagGreaterThanOrEqualTo(String value) {
            addCriterion("MFLAG >=", value, "mflag");
            return (Criteria) this;
        }

        public Criteria andMflagLessThan(String value) {
            addCriterion("MFLAG <", value, "mflag");
            return (Criteria) this;
        }

        public Criteria andMflagLessThanOrEqualTo(String value) {
            addCriterion("MFLAG <=", value, "mflag");
            return (Criteria) this;
        }

        public Criteria andMflagLike(String value) {
            addCriterion("MFLAG like", value, "mflag");
            return (Criteria) this;
        }

        public Criteria andMflagNotLike(String value) {
            addCriterion("MFLAG not like", value, "mflag");
            return (Criteria) this;
        }

        public Criteria andMflagIn(List<String> values) {
            addCriterion("MFLAG in", values, "mflag");
            return (Criteria) this;
        }

        public Criteria andMflagNotIn(List<String> values) {
            addCriterion("MFLAG not in", values, "mflag");
            return (Criteria) this;
        }

        public Criteria andMflagBetween(String value1, String value2) {
            addCriterion("MFLAG between", value1, value2, "mflag");
            return (Criteria) this;
        }

        public Criteria andMflagNotBetween(String value1, String value2) {
            addCriterion("MFLAG not between", value1, value2, "mflag");
            return (Criteria) this;
        }

        public Criteria andMonitorIsNull() {
            addCriterion("MONITOR is null");
            return (Criteria) this;
        }

        public Criteria andMonitorIsNotNull() {
            addCriterion("MONITOR is not null");
            return (Criteria) this;
        }

        public Criteria andMonitorEqualTo(String value) {
            addCriterion("MONITOR =", value, "monitor");
            return (Criteria) this;
        }

        public Criteria andMonitorNotEqualTo(String value) {
            addCriterion("MONITOR <>", value, "monitor");
            return (Criteria) this;
        }

        public Criteria andMonitorGreaterThan(String value) {
            addCriterion("MONITOR >", value, "monitor");
            return (Criteria) this;
        }

        public Criteria andMonitorGreaterThanOrEqualTo(String value) {
            addCriterion("MONITOR >=", value, "monitor");
            return (Criteria) this;
        }

        public Criteria andMonitorLessThan(String value) {
            addCriterion("MONITOR <", value, "monitor");
            return (Criteria) this;
        }

        public Criteria andMonitorLessThanOrEqualTo(String value) {
            addCriterion("MONITOR <=", value, "monitor");
            return (Criteria) this;
        }

        public Criteria andMonitorLike(String value) {
            addCriterion("MONITOR like", value, "monitor");
            return (Criteria) this;
        }

        public Criteria andMonitorNotLike(String value) {
            addCriterion("MONITOR not like", value, "monitor");
            return (Criteria) this;
        }

        public Criteria andMonitorIn(List<String> values) {
            addCriterion("MONITOR in", values, "monitor");
            return (Criteria) this;
        }

        public Criteria andMonitorNotIn(List<String> values) {
            addCriterion("MONITOR not in", values, "monitor");
            return (Criteria) this;
        }

        public Criteria andMonitorBetween(String value1, String value2) {
            addCriterion("MONITOR between", value1, value2, "monitor");
            return (Criteria) this;
        }

        public Criteria andMonitorNotBetween(String value1, String value2) {
            addCriterion("MONITOR not between", value1, value2, "monitor");
            return (Criteria) this;
        }

        public Criteria andDelYnIsNull() {
            addCriterion("DEL_YN is null");
            return (Criteria) this;
        }

        public Criteria andDelYnIsNotNull() {
            addCriterion("DEL_YN is not null");
            return (Criteria) this;
        }

        public Criteria andDelYnEqualTo(String value) {
            addCriterion("DEL_YN =", value, "delYn");
            return (Criteria) this;
        }

        public Criteria andDelYnNotEqualTo(String value) {
            addCriterion("DEL_YN <>", value, "delYn");
            return (Criteria) this;
        }

        public Criteria andDelYnGreaterThan(String value) {
            addCriterion("DEL_YN >", value, "delYn");
            return (Criteria) this;
        }

        public Criteria andDelYnGreaterThanOrEqualTo(String value) {
            addCriterion("DEL_YN >=", value, "delYn");
            return (Criteria) this;
        }

        public Criteria andDelYnLessThan(String value) {
            addCriterion("DEL_YN <", value, "delYn");
            return (Criteria) this;
        }

        public Criteria andDelYnLessThanOrEqualTo(String value) {
            addCriterion("DEL_YN <=", value, "delYn");
            return (Criteria) this;
        }

        public Criteria andDelYnLike(String value) {
            addCriterion("DEL_YN like", value, "delYn");
            return (Criteria) this;
        }

        public Criteria andDelYnNotLike(String value) {
            addCriterion("DEL_YN not like", value, "delYn");
            return (Criteria) this;
        }

        public Criteria andDelYnIn(List<String> values) {
            addCriterion("DEL_YN in", values, "delYn");
            return (Criteria) this;
        }

        public Criteria andDelYnNotIn(List<String> values) {
            addCriterion("DEL_YN not in", values, "delYn");
            return (Criteria) this;
        }

        public Criteria andDelYnBetween(String value1, String value2) {
            addCriterion("DEL_YN between", value1, value2, "delYn");
            return (Criteria) this;
        }

        public Criteria andDelYnNotBetween(String value1, String value2) {
            addCriterion("DEL_YN not between", value1, value2, "delYn");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}