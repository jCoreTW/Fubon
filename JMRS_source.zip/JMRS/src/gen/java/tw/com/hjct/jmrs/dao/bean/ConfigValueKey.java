package tw.com.hjct.jmrs.dao.bean;

public class ConfigValueKey {
    private Integer configId;

    private String code;

    public Integer getConfigId() {
        return configId;
    }

    public void setConfigId(Integer configId) {
        this.configId = configId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code == null ? null : code.trim();
    }
}