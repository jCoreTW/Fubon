package tw.com.hjct.jmrs.dao.bean;

public class RdSubmitJob {
    private String num;

    private String mainJsname;

    private String mainJobname;

    private String subJobname;

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num == null ? null : num.trim();
    }

    public String getMainJsname() {
        return mainJsname;
    }

    public void setMainJsname(String mainJsname) {
        this.mainJsname = mainJsname == null ? null : mainJsname.trim();
    }

    public String getMainJobname() {
        return mainJobname;
    }

    public void setMainJobname(String mainJobname) {
        this.mainJobname = mainJobname == null ? null : mainJobname.trim();
    }

    public String getSubJobname() {
        return subJobname;
    }

    public void setSubJobname(String subJobname) {
        this.subJobname = subJobname == null ? null : subJobname.trim();
    }
}