package tw.com.hjct.jmrs.dao.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import tw.com.hjct.jmrs.dao.bean.Whitelist;
import tw.com.hjct.jmrs.dao.bean.WhitelistExample;

public interface WhitelistMapper {
    long countByExample(WhitelistExample example);

    int deleteByExample(WhitelistExample example);

    int deleteByPrimaryKey(Integer whitelistId);

    int insert(Whitelist record);

    int insertSelective(Whitelist record);

    List<Whitelist> selectByExample(WhitelistExample example);

    Whitelist selectByPrimaryKey(Integer whitelistId);

    int updateByExampleSelective(@Param("record") Whitelist record, @Param("example") WhitelistExample example);

    int updateByExample(@Param("record") Whitelist record, @Param("example") WhitelistExample example);

    int updateByPrimaryKeySelective(Whitelist record);

    int updateByPrimaryKey(Whitelist record);
}