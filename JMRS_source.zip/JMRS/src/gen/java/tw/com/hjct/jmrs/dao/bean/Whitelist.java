package tw.com.hjct.jmrs.dao.bean;

import java.util.Date;

public class Whitelist {
    private Integer whitelistId;

    private String account;

    private String domain;

    private String role;

    private Date loginTime;

    private Date lastLoginTime;

    public Integer getWhitelistId() {
        return whitelistId;
    }

    public void setWhitelistId(Integer whitelistId) {
        this.whitelistId = whitelistId;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account == null ? null : account.trim();
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain == null ? null : domain.trim();
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role == null ? null : role.trim();
    }

    public Date getLoginTime() {
        return loginTime;
    }

    public void setLoginTime(Date loginTime) {
        this.loginTime = loginTime;
    }

    public Date getLastLoginTime() {
        return lastLoginTime;
    }

    public void setLastLoginTime(Date lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }
}