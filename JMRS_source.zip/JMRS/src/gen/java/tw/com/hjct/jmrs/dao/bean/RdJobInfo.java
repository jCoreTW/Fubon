package tw.com.hjct.jmrs.dao.bean;

public class RdJobInfo {
    private String num;

    private String jobname;

    private String jobsys;

    private String fileDescription;

    private String jsName;

    private String firstName;

    private String secondName;

    private String isdraft;

    private String groupName;

    private String issendmail;

    private String memo;

    private String jobStime;

    private String jobEtime;

    private String isrun;

    private String mflag;

    private String monitor;

    private String delYn;

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num == null ? null : num.trim();
    }

    public String getJobname() {
        return jobname;
    }

    public void setJobname(String jobname) {
        this.jobname = jobname == null ? null : jobname.trim();
    }

    public String getJobsys() {
        return jobsys;
    }

    public void setJobsys(String jobsys) {
        this.jobsys = jobsys == null ? null : jobsys.trim();
    }

    public String getFileDescription() {
        return fileDescription;
    }

    public void setFileDescription(String fileDescription) {
        this.fileDescription = fileDescription == null ? null : fileDescription.trim();
    }

    public String getJsName() {
        return jsName;
    }

    public void setJsName(String jsName) {
        this.jsName = jsName == null ? null : jsName.trim();
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName == null ? null : firstName.trim();
    }

    public String getSecondName() {
        return secondName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName == null ? null : secondName.trim();
    }

    public String getIsdraft() {
        return isdraft;
    }

    public void setIsdraft(String isdraft) {
        this.isdraft = isdraft == null ? null : isdraft.trim();
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName == null ? null : groupName.trim();
    }

    public String getIssendmail() {
        return issendmail;
    }

    public void setIssendmail(String issendmail) {
        this.issendmail = issendmail == null ? null : issendmail.trim();
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo == null ? null : memo.trim();
    }

    public String getJobStime() {
        return jobStime;
    }

    public void setJobStime(String jobStime) {
        this.jobStime = jobStime == null ? null : jobStime.trim();
    }

    public String getJobEtime() {
        return jobEtime;
    }

    public void setJobEtime(String jobEtime) {
        this.jobEtime = jobEtime == null ? null : jobEtime.trim();
    }

    public String getIsrun() {
        return isrun;
    }

    public void setIsrun(String isrun) {
        this.isrun = isrun == null ? null : isrun.trim();
    }

    public String getMflag() {
        return mflag;
    }

    public void setMflag(String mflag) {
        this.mflag = mflag == null ? null : mflag.trim();
    }

    public String getMonitor() {
        return monitor;
    }

    public void setMonitor(String monitor) {
        this.monitor = monitor == null ? null : monitor.trim();
    }

    public String getDelYn() {
        return delYn;
    }

    public void setDelYn(String delYn) {
        this.delYn = delYn == null ? null : delYn.trim();
    }
}