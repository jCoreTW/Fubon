package tw.com.hjct.jmrs.dao.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import tw.com.hjct.jmrs.dao.bean.RdJobTgtInfo;
import tw.com.hjct.jmrs.dao.bean.RdJobTgtInfoExample;
import tw.com.hjct.jmrs.dao.bean.RdJobTgtInfoKey;

public interface RdJobTgtInfoMapper {
    long countByExample(RdJobTgtInfoExample example);

    int deleteByExample(RdJobTgtInfoExample example);

    int deleteByPrimaryKey(RdJobTgtInfoKey key);

    int insert(RdJobTgtInfo record);

    int insertSelective(RdJobTgtInfo record);

    List<RdJobTgtInfo> selectByExample(RdJobTgtInfoExample example);

    RdJobTgtInfo selectByPrimaryKey(RdJobTgtInfoKey key);

    int updateByExampleSelective(@Param("record") RdJobTgtInfo record, @Param("example") RdJobTgtInfoExample example);

    int updateByExample(@Param("record") RdJobTgtInfo record, @Param("example") RdJobTgtInfoExample example);

    int updateByPrimaryKeySelective(RdJobTgtInfo record);

    int updateByPrimaryKey(RdJobTgtInfo record);
}