package tw.com.hjct.jmrs.dao.bean;

public class RdJobHashInfo extends RdJobHashInfoKey {
    private String jobname;

    private String name;

    private String ftflag;

    private String owner;

    private String conname;

    private String fregrExp;

    public String getJobname() {
        return jobname;
    }

    public void setJobname(String jobname) {
        this.jobname = jobname == null ? null : jobname.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getFtflag() {
        return ftflag;
    }

    public void setFtflag(String ftflag) {
        this.ftflag = ftflag == null ? null : ftflag.trim();
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner == null ? null : owner.trim();
    }

    public String getConname() {
        return conname;
    }

    public void setConname(String conname) {
        this.conname = conname == null ? null : conname.trim();
    }

    public String getFregrExp() {
        return fregrExp;
    }

    public void setFregrExp(String fregrExp) {
        this.fregrExp = fregrExp == null ? null : fregrExp.trim();
    }
}