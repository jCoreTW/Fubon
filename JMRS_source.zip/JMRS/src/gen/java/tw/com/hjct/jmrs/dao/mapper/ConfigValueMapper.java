package tw.com.hjct.jmrs.dao.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import tw.com.hjct.jmrs.dao.bean.ConfigValue;
import tw.com.hjct.jmrs.dao.bean.ConfigValueExample;
import tw.com.hjct.jmrs.dao.bean.ConfigValueKey;

public interface ConfigValueMapper {
    long countByExample(ConfigValueExample example);

    int deleteByExample(ConfigValueExample example);

    int deleteByPrimaryKey(ConfigValueKey key);

    int insert(ConfigValue record);

    int insertSelective(ConfigValue record);

    List<ConfigValue> selectByExample(ConfigValueExample example);

    ConfigValue selectByPrimaryKey(ConfigValueKey key);

    int updateByExampleSelective(@Param("record") ConfigValue record, @Param("example") ConfigValueExample example);

    int updateByExample(@Param("record") ConfigValue record, @Param("example") ConfigValueExample example);

    int updateByPrimaryKeySelective(ConfigValue record);

    int updateByPrimaryKey(ConfigValue record);
}