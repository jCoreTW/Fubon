package tw.com.hjct.jmrs.dao.bean;

public class RdJobTgtInfo extends RdJobTgtInfoKey {
    private String jobname;

    private String name;

    private String ftflag;

    private String owner;

    private String folder;

    private String conname;

    private String tgtNode;

    private String tgtDir;

    private String tgtFilename;

    private String srcFiletype;

    private String tgtFiletype;

    public String getJobname() {
        return jobname;
    }

    public void setJobname(String jobname) {
        this.jobname = jobname == null ? null : jobname.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getFtflag() {
        return ftflag;
    }

    public void setFtflag(String ftflag) {
        this.ftflag = ftflag == null ? null : ftflag.trim();
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner == null ? null : owner.trim();
    }

    public String getFolder() {
        return folder;
    }

    public void setFolder(String folder) {
        this.folder = folder == null ? null : folder.trim();
    }

    public String getConname() {
        return conname;
    }

    public void setConname(String conname) {
        this.conname = conname == null ? null : conname.trim();
    }

    public String getTgtNode() {
        return tgtNode;
    }

    public void setTgtNode(String tgtNode) {
        this.tgtNode = tgtNode == null ? null : tgtNode.trim();
    }

    public String getTgtDir() {
        return tgtDir;
    }

    public void setTgtDir(String tgtDir) {
        this.tgtDir = tgtDir == null ? null : tgtDir.trim();
    }

    public String getTgtFilename() {
        return tgtFilename;
    }

    public void setTgtFilename(String tgtFilename) {
        this.tgtFilename = tgtFilename == null ? null : tgtFilename.trim();
    }

    public String getSrcFiletype() {
        return srcFiletype;
    }

    public void setSrcFiletype(String srcFiletype) {
        this.srcFiletype = srcFiletype == null ? null : srcFiletype.trim();
    }

    public String getTgtFiletype() {
        return tgtFiletype;
    }

    public void setTgtFiletype(String tgtFiletype) {
        this.tgtFiletype = tgtFiletype == null ? null : tgtFiletype.trim();
    }
}