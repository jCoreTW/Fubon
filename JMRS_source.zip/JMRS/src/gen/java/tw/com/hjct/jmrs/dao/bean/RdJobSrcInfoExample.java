package tw.com.hjct.jmrs.dao.bean;

import java.util.ArrayList;
import java.util.List;

public class RdJobSrcInfoExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public RdJobSrcInfoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andNumIsNull() {
            addCriterion("NUM is null");
            return (Criteria) this;
        }

        public Criteria andNumIsNotNull() {
            addCriterion("NUM is not null");
            return (Criteria) this;
        }

        public Criteria andNumEqualTo(String value) {
            addCriterion("NUM =", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumNotEqualTo(String value) {
            addCriterion("NUM <>", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumGreaterThan(String value) {
            addCriterion("NUM >", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumGreaterThanOrEqualTo(String value) {
            addCriterion("NUM >=", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumLessThan(String value) {
            addCriterion("NUM <", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumLessThanOrEqualTo(String value) {
            addCriterion("NUM <=", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumLike(String value) {
            addCriterion("NUM like", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumNotLike(String value) {
            addCriterion("NUM not like", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumIn(List<String> values) {
            addCriterion("NUM in", values, "num");
            return (Criteria) this;
        }

        public Criteria andNumNotIn(List<String> values) {
            addCriterion("NUM not in", values, "num");
            return (Criteria) this;
        }

        public Criteria andNumBetween(String value1, String value2) {
            addCriterion("NUM between", value1, value2, "num");
            return (Criteria) this;
        }

        public Criteria andNumNotBetween(String value1, String value2) {
            addCriterion("NUM not between", value1, value2, "num");
            return (Criteria) this;
        }

        public Criteria andRancodeIsNull() {
            addCriterion("RANCODE is null");
            return (Criteria) this;
        }

        public Criteria andRancodeIsNotNull() {
            addCriterion("RANCODE is not null");
            return (Criteria) this;
        }

        public Criteria andRancodeEqualTo(String value) {
            addCriterion("RANCODE =", value, "rancode");
            return (Criteria) this;
        }

        public Criteria andRancodeNotEqualTo(String value) {
            addCriterion("RANCODE <>", value, "rancode");
            return (Criteria) this;
        }

        public Criteria andRancodeGreaterThan(String value) {
            addCriterion("RANCODE >", value, "rancode");
            return (Criteria) this;
        }

        public Criteria andRancodeGreaterThanOrEqualTo(String value) {
            addCriterion("RANCODE >=", value, "rancode");
            return (Criteria) this;
        }

        public Criteria andRancodeLessThan(String value) {
            addCriterion("RANCODE <", value, "rancode");
            return (Criteria) this;
        }

        public Criteria andRancodeLessThanOrEqualTo(String value) {
            addCriterion("RANCODE <=", value, "rancode");
            return (Criteria) this;
        }

        public Criteria andRancodeLike(String value) {
            addCriterion("RANCODE like", value, "rancode");
            return (Criteria) this;
        }

        public Criteria andRancodeNotLike(String value) {
            addCriterion("RANCODE not like", value, "rancode");
            return (Criteria) this;
        }

        public Criteria andRancodeIn(List<String> values) {
            addCriterion("RANCODE in", values, "rancode");
            return (Criteria) this;
        }

        public Criteria andRancodeNotIn(List<String> values) {
            addCriterion("RANCODE not in", values, "rancode");
            return (Criteria) this;
        }

        public Criteria andRancodeBetween(String value1, String value2) {
            addCriterion("RANCODE between", value1, value2, "rancode");
            return (Criteria) this;
        }

        public Criteria andRancodeNotBetween(String value1, String value2) {
            addCriterion("RANCODE not between", value1, value2, "rancode");
            return (Criteria) this;
        }

        public Criteria andJobnameIsNull() {
            addCriterion("JOBNAME is null");
            return (Criteria) this;
        }

        public Criteria andJobnameIsNotNull() {
            addCriterion("JOBNAME is not null");
            return (Criteria) this;
        }

        public Criteria andJobnameEqualTo(String value) {
            addCriterion("JOBNAME =", value, "jobname");
            return (Criteria) this;
        }

        public Criteria andJobnameNotEqualTo(String value) {
            addCriterion("JOBNAME <>", value, "jobname");
            return (Criteria) this;
        }

        public Criteria andJobnameGreaterThan(String value) {
            addCriterion("JOBNAME >", value, "jobname");
            return (Criteria) this;
        }

        public Criteria andJobnameGreaterThanOrEqualTo(String value) {
            addCriterion("JOBNAME >=", value, "jobname");
            return (Criteria) this;
        }

        public Criteria andJobnameLessThan(String value) {
            addCriterion("JOBNAME <", value, "jobname");
            return (Criteria) this;
        }

        public Criteria andJobnameLessThanOrEqualTo(String value) {
            addCriterion("JOBNAME <=", value, "jobname");
            return (Criteria) this;
        }

        public Criteria andJobnameLike(String value) {
            addCriterion("JOBNAME like", value, "jobname");
            return (Criteria) this;
        }

        public Criteria andJobnameNotLike(String value) {
            addCriterion("JOBNAME not like", value, "jobname");
            return (Criteria) this;
        }

        public Criteria andJobnameIn(List<String> values) {
            addCriterion("JOBNAME in", values, "jobname");
            return (Criteria) this;
        }

        public Criteria andJobnameNotIn(List<String> values) {
            addCriterion("JOBNAME not in", values, "jobname");
            return (Criteria) this;
        }

        public Criteria andJobnameBetween(String value1, String value2) {
            addCriterion("JOBNAME between", value1, value2, "jobname");
            return (Criteria) this;
        }

        public Criteria andJobnameNotBetween(String value1, String value2) {
            addCriterion("JOBNAME not between", value1, value2, "jobname");
            return (Criteria) this;
        }

        public Criteria andNameIsNull() {
            addCriterion("NAME is null");
            return (Criteria) this;
        }

        public Criteria andNameIsNotNull() {
            addCriterion("NAME is not null");
            return (Criteria) this;
        }

        public Criteria andNameEqualTo(String value) {
            addCriterion("NAME =", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotEqualTo(String value) {
            addCriterion("NAME <>", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThan(String value) {
            addCriterion("NAME >", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThanOrEqualTo(String value) {
            addCriterion("NAME >=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThan(String value) {
            addCriterion("NAME <", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThanOrEqualTo(String value) {
            addCriterion("NAME <=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLike(String value) {
            addCriterion("NAME like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotLike(String value) {
            addCriterion("NAME not like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameIn(List<String> values) {
            addCriterion("NAME in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotIn(List<String> values) {
            addCriterion("NAME not in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameBetween(String value1, String value2) {
            addCriterion("NAME between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotBetween(String value1, String value2) {
            addCriterion("NAME not between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andFtflagIsNull() {
            addCriterion("FTFLAG is null");
            return (Criteria) this;
        }

        public Criteria andFtflagIsNotNull() {
            addCriterion("FTFLAG is not null");
            return (Criteria) this;
        }

        public Criteria andFtflagEqualTo(String value) {
            addCriterion("FTFLAG =", value, "ftflag");
            return (Criteria) this;
        }

        public Criteria andFtflagNotEqualTo(String value) {
            addCriterion("FTFLAG <>", value, "ftflag");
            return (Criteria) this;
        }

        public Criteria andFtflagGreaterThan(String value) {
            addCriterion("FTFLAG >", value, "ftflag");
            return (Criteria) this;
        }

        public Criteria andFtflagGreaterThanOrEqualTo(String value) {
            addCriterion("FTFLAG >=", value, "ftflag");
            return (Criteria) this;
        }

        public Criteria andFtflagLessThan(String value) {
            addCriterion("FTFLAG <", value, "ftflag");
            return (Criteria) this;
        }

        public Criteria andFtflagLessThanOrEqualTo(String value) {
            addCriterion("FTFLAG <=", value, "ftflag");
            return (Criteria) this;
        }

        public Criteria andFtflagLike(String value) {
            addCriterion("FTFLAG like", value, "ftflag");
            return (Criteria) this;
        }

        public Criteria andFtflagNotLike(String value) {
            addCriterion("FTFLAG not like", value, "ftflag");
            return (Criteria) this;
        }

        public Criteria andFtflagIn(List<String> values) {
            addCriterion("FTFLAG in", values, "ftflag");
            return (Criteria) this;
        }

        public Criteria andFtflagNotIn(List<String> values) {
            addCriterion("FTFLAG not in", values, "ftflag");
            return (Criteria) this;
        }

        public Criteria andFtflagBetween(String value1, String value2) {
            addCriterion("FTFLAG between", value1, value2, "ftflag");
            return (Criteria) this;
        }

        public Criteria andFtflagNotBetween(String value1, String value2) {
            addCriterion("FTFLAG not between", value1, value2, "ftflag");
            return (Criteria) this;
        }

        public Criteria andOwnerIsNull() {
            addCriterion("OWNER is null");
            return (Criteria) this;
        }

        public Criteria andOwnerIsNotNull() {
            addCriterion("OWNER is not null");
            return (Criteria) this;
        }

        public Criteria andOwnerEqualTo(String value) {
            addCriterion("OWNER =", value, "owner");
            return (Criteria) this;
        }

        public Criteria andOwnerNotEqualTo(String value) {
            addCriterion("OWNER <>", value, "owner");
            return (Criteria) this;
        }

        public Criteria andOwnerGreaterThan(String value) {
            addCriterion("OWNER >", value, "owner");
            return (Criteria) this;
        }

        public Criteria andOwnerGreaterThanOrEqualTo(String value) {
            addCriterion("OWNER >=", value, "owner");
            return (Criteria) this;
        }

        public Criteria andOwnerLessThan(String value) {
            addCriterion("OWNER <", value, "owner");
            return (Criteria) this;
        }

        public Criteria andOwnerLessThanOrEqualTo(String value) {
            addCriterion("OWNER <=", value, "owner");
            return (Criteria) this;
        }

        public Criteria andOwnerLike(String value) {
            addCriterion("OWNER like", value, "owner");
            return (Criteria) this;
        }

        public Criteria andOwnerNotLike(String value) {
            addCriterion("OWNER not like", value, "owner");
            return (Criteria) this;
        }

        public Criteria andOwnerIn(List<String> values) {
            addCriterion("OWNER in", values, "owner");
            return (Criteria) this;
        }

        public Criteria andOwnerNotIn(List<String> values) {
            addCriterion("OWNER not in", values, "owner");
            return (Criteria) this;
        }

        public Criteria andOwnerBetween(String value1, String value2) {
            addCriterion("OWNER between", value1, value2, "owner");
            return (Criteria) this;
        }

        public Criteria andOwnerNotBetween(String value1, String value2) {
            addCriterion("OWNER not between", value1, value2, "owner");
            return (Criteria) this;
        }

        public Criteria andCtlFileIsNull() {
            addCriterion("CTL_FILE is null");
            return (Criteria) this;
        }

        public Criteria andCtlFileIsNotNull() {
            addCriterion("CTL_FILE is not null");
            return (Criteria) this;
        }

        public Criteria andCtlFileEqualTo(String value) {
            addCriterion("CTL_FILE =", value, "ctlFile");
            return (Criteria) this;
        }

        public Criteria andCtlFileNotEqualTo(String value) {
            addCriterion("CTL_FILE <>", value, "ctlFile");
            return (Criteria) this;
        }

        public Criteria andCtlFileGreaterThan(String value) {
            addCriterion("CTL_FILE >", value, "ctlFile");
            return (Criteria) this;
        }

        public Criteria andCtlFileGreaterThanOrEqualTo(String value) {
            addCriterion("CTL_FILE >=", value, "ctlFile");
            return (Criteria) this;
        }

        public Criteria andCtlFileLessThan(String value) {
            addCriterion("CTL_FILE <", value, "ctlFile");
            return (Criteria) this;
        }

        public Criteria andCtlFileLessThanOrEqualTo(String value) {
            addCriterion("CTL_FILE <=", value, "ctlFile");
            return (Criteria) this;
        }

        public Criteria andCtlFileLike(String value) {
            addCriterion("CTL_FILE like", value, "ctlFile");
            return (Criteria) this;
        }

        public Criteria andCtlFileNotLike(String value) {
            addCriterion("CTL_FILE not like", value, "ctlFile");
            return (Criteria) this;
        }

        public Criteria andCtlFileIn(List<String> values) {
            addCriterion("CTL_FILE in", values, "ctlFile");
            return (Criteria) this;
        }

        public Criteria andCtlFileNotIn(List<String> values) {
            addCriterion("CTL_FILE not in", values, "ctlFile");
            return (Criteria) this;
        }

        public Criteria andCtlFileBetween(String value1, String value2) {
            addCriterion("CTL_FILE between", value1, value2, "ctlFile");
            return (Criteria) this;
        }

        public Criteria andCtlFileNotBetween(String value1, String value2) {
            addCriterion("CTL_FILE not between", value1, value2, "ctlFile");
            return (Criteria) this;
        }

        public Criteria andFolderIsNull() {
            addCriterion("FOLDER is null");
            return (Criteria) this;
        }

        public Criteria andFolderIsNotNull() {
            addCriterion("FOLDER is not null");
            return (Criteria) this;
        }

        public Criteria andFolderEqualTo(String value) {
            addCriterion("FOLDER =", value, "folder");
            return (Criteria) this;
        }

        public Criteria andFolderNotEqualTo(String value) {
            addCriterion("FOLDER <>", value, "folder");
            return (Criteria) this;
        }

        public Criteria andFolderGreaterThan(String value) {
            addCriterion("FOLDER >", value, "folder");
            return (Criteria) this;
        }

        public Criteria andFolderGreaterThanOrEqualTo(String value) {
            addCriterion("FOLDER >=", value, "folder");
            return (Criteria) this;
        }

        public Criteria andFolderLessThan(String value) {
            addCriterion("FOLDER <", value, "folder");
            return (Criteria) this;
        }

        public Criteria andFolderLessThanOrEqualTo(String value) {
            addCriterion("FOLDER <=", value, "folder");
            return (Criteria) this;
        }

        public Criteria andFolderLike(String value) {
            addCriterion("FOLDER like", value, "folder");
            return (Criteria) this;
        }

        public Criteria andFolderNotLike(String value) {
            addCriterion("FOLDER not like", value, "folder");
            return (Criteria) this;
        }

        public Criteria andFolderIn(List<String> values) {
            addCriterion("FOLDER in", values, "folder");
            return (Criteria) this;
        }

        public Criteria andFolderNotIn(List<String> values) {
            addCriterion("FOLDER not in", values, "folder");
            return (Criteria) this;
        }

        public Criteria andFolderBetween(String value1, String value2) {
            addCriterion("FOLDER between", value1, value2, "folder");
            return (Criteria) this;
        }

        public Criteria andFolderNotBetween(String value1, String value2) {
            addCriterion("FOLDER not between", value1, value2, "folder");
            return (Criteria) this;
        }

        public Criteria andConnameIsNull() {
            addCriterion("CONNAME is null");
            return (Criteria) this;
        }

        public Criteria andConnameIsNotNull() {
            addCriterion("CONNAME is not null");
            return (Criteria) this;
        }

        public Criteria andConnameEqualTo(String value) {
            addCriterion("CONNAME =", value, "conname");
            return (Criteria) this;
        }

        public Criteria andConnameNotEqualTo(String value) {
            addCriterion("CONNAME <>", value, "conname");
            return (Criteria) this;
        }

        public Criteria andConnameGreaterThan(String value) {
            addCriterion("CONNAME >", value, "conname");
            return (Criteria) this;
        }

        public Criteria andConnameGreaterThanOrEqualTo(String value) {
            addCriterion("CONNAME >=", value, "conname");
            return (Criteria) this;
        }

        public Criteria andConnameLessThan(String value) {
            addCriterion("CONNAME <", value, "conname");
            return (Criteria) this;
        }

        public Criteria andConnameLessThanOrEqualTo(String value) {
            addCriterion("CONNAME <=", value, "conname");
            return (Criteria) this;
        }

        public Criteria andConnameLike(String value) {
            addCriterion("CONNAME like", value, "conname");
            return (Criteria) this;
        }

        public Criteria andConnameNotLike(String value) {
            addCriterion("CONNAME not like", value, "conname");
            return (Criteria) this;
        }

        public Criteria andConnameIn(List<String> values) {
            addCriterion("CONNAME in", values, "conname");
            return (Criteria) this;
        }

        public Criteria andConnameNotIn(List<String> values) {
            addCriterion("CONNAME not in", values, "conname");
            return (Criteria) this;
        }

        public Criteria andConnameBetween(String value1, String value2) {
            addCriterion("CONNAME between", value1, value2, "conname");
            return (Criteria) this;
        }

        public Criteria andConnameNotBetween(String value1, String value2) {
            addCriterion("CONNAME not between", value1, value2, "conname");
            return (Criteria) this;
        }

        public Criteria andFregrExpIsNull() {
            addCriterion("FREGR_EXP is null");
            return (Criteria) this;
        }

        public Criteria andFregrExpIsNotNull() {
            addCriterion("FREGR_EXP is not null");
            return (Criteria) this;
        }

        public Criteria andFregrExpEqualTo(String value) {
            addCriterion("FREGR_EXP =", value, "fregrExp");
            return (Criteria) this;
        }

        public Criteria andFregrExpNotEqualTo(String value) {
            addCriterion("FREGR_EXP <>", value, "fregrExp");
            return (Criteria) this;
        }

        public Criteria andFregrExpGreaterThan(String value) {
            addCriterion("FREGR_EXP >", value, "fregrExp");
            return (Criteria) this;
        }

        public Criteria andFregrExpGreaterThanOrEqualTo(String value) {
            addCriterion("FREGR_EXP >=", value, "fregrExp");
            return (Criteria) this;
        }

        public Criteria andFregrExpLessThan(String value) {
            addCriterion("FREGR_EXP <", value, "fregrExp");
            return (Criteria) this;
        }

        public Criteria andFregrExpLessThanOrEqualTo(String value) {
            addCriterion("FREGR_EXP <=", value, "fregrExp");
            return (Criteria) this;
        }

        public Criteria andFregrExpLike(String value) {
            addCriterion("FREGR_EXP like", value, "fregrExp");
            return (Criteria) this;
        }

        public Criteria andFregrExpNotLike(String value) {
            addCriterion("FREGR_EXP not like", value, "fregrExp");
            return (Criteria) this;
        }

        public Criteria andFregrExpIn(List<String> values) {
            addCriterion("FREGR_EXP in", values, "fregrExp");
            return (Criteria) this;
        }

        public Criteria andFregrExpNotIn(List<String> values) {
            addCriterion("FREGR_EXP not in", values, "fregrExp");
            return (Criteria) this;
        }

        public Criteria andFregrExpBetween(String value1, String value2) {
            addCriterion("FREGR_EXP between", value1, value2, "fregrExp");
            return (Criteria) this;
        }

        public Criteria andFregrExpNotBetween(String value1, String value2) {
            addCriterion("FREGR_EXP not between", value1, value2, "fregrExp");
            return (Criteria) this;
        }

        public Criteria andTwsActionIsNull() {
            addCriterion("TWS_ACTION is null");
            return (Criteria) this;
        }

        public Criteria andTwsActionIsNotNull() {
            addCriterion("TWS_ACTION is not null");
            return (Criteria) this;
        }

        public Criteria andTwsActionEqualTo(String value) {
            addCriterion("TWS_ACTION =", value, "twsAction");
            return (Criteria) this;
        }

        public Criteria andTwsActionNotEqualTo(String value) {
            addCriterion("TWS_ACTION <>", value, "twsAction");
            return (Criteria) this;
        }

        public Criteria andTwsActionGreaterThan(String value) {
            addCriterion("TWS_ACTION >", value, "twsAction");
            return (Criteria) this;
        }

        public Criteria andTwsActionGreaterThanOrEqualTo(String value) {
            addCriterion("TWS_ACTION >=", value, "twsAction");
            return (Criteria) this;
        }

        public Criteria andTwsActionLessThan(String value) {
            addCriterion("TWS_ACTION <", value, "twsAction");
            return (Criteria) this;
        }

        public Criteria andTwsActionLessThanOrEqualTo(String value) {
            addCriterion("TWS_ACTION <=", value, "twsAction");
            return (Criteria) this;
        }

        public Criteria andTwsActionLike(String value) {
            addCriterion("TWS_ACTION like", value, "twsAction");
            return (Criteria) this;
        }

        public Criteria andTwsActionNotLike(String value) {
            addCriterion("TWS_ACTION not like", value, "twsAction");
            return (Criteria) this;
        }

        public Criteria andTwsActionIn(List<String> values) {
            addCriterion("TWS_ACTION in", values, "twsAction");
            return (Criteria) this;
        }

        public Criteria andTwsActionNotIn(List<String> values) {
            addCriterion("TWS_ACTION not in", values, "twsAction");
            return (Criteria) this;
        }

        public Criteria andTwsActionBetween(String value1, String value2) {
            addCriterion("TWS_ACTION between", value1, value2, "twsAction");
            return (Criteria) this;
        }

        public Criteria andTwsActionNotBetween(String value1, String value2) {
            addCriterion("TWS_ACTION not between", value1, value2, "twsAction");
            return (Criteria) this;
        }

        public Criteria andPriorityIsNull() {
            addCriterion("PRIORITY is null");
            return (Criteria) this;
        }

        public Criteria andPriorityIsNotNull() {
            addCriterion("PRIORITY is not null");
            return (Criteria) this;
        }

        public Criteria andPriorityEqualTo(String value) {
            addCriterion("PRIORITY =", value, "priority");
            return (Criteria) this;
        }

        public Criteria andPriorityNotEqualTo(String value) {
            addCriterion("PRIORITY <>", value, "priority");
            return (Criteria) this;
        }

        public Criteria andPriorityGreaterThan(String value) {
            addCriterion("PRIORITY >", value, "priority");
            return (Criteria) this;
        }

        public Criteria andPriorityGreaterThanOrEqualTo(String value) {
            addCriterion("PRIORITY >=", value, "priority");
            return (Criteria) this;
        }

        public Criteria andPriorityLessThan(String value) {
            addCriterion("PRIORITY <", value, "priority");
            return (Criteria) this;
        }

        public Criteria andPriorityLessThanOrEqualTo(String value) {
            addCriterion("PRIORITY <=", value, "priority");
            return (Criteria) this;
        }

        public Criteria andPriorityLike(String value) {
            addCriterion("PRIORITY like", value, "priority");
            return (Criteria) this;
        }

        public Criteria andPriorityNotLike(String value) {
            addCriterion("PRIORITY not like", value, "priority");
            return (Criteria) this;
        }

        public Criteria andPriorityIn(List<String> values) {
            addCriterion("PRIORITY in", values, "priority");
            return (Criteria) this;
        }

        public Criteria andPriorityNotIn(List<String> values) {
            addCriterion("PRIORITY not in", values, "priority");
            return (Criteria) this;
        }

        public Criteria andPriorityBetween(String value1, String value2) {
            addCriterion("PRIORITY between", value1, value2, "priority");
            return (Criteria) this;
        }

        public Criteria andPriorityNotBetween(String value1, String value2) {
            addCriterion("PRIORITY not between", value1, value2, "priority");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}