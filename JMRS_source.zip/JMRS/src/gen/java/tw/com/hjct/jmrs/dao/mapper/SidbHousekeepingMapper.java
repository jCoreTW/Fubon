package tw.com.hjct.jmrs.dao.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import tw.com.hjct.jmrs.dao.bean.SidbHousekeeping;
import tw.com.hjct.jmrs.dao.bean.SidbHousekeepingExample;
import tw.com.hjct.jmrs.dao.bean.SidbHousekeepingKey;

public interface SidbHousekeepingMapper {
    long countByExample(SidbHousekeepingExample example);

    int deleteByExample(SidbHousekeepingExample example);

    int deleteByPrimaryKey(SidbHousekeepingKey key);

    int insert(SidbHousekeeping record);

    int insertSelective(SidbHousekeeping record);

    List<SidbHousekeeping> selectByExample(SidbHousekeepingExample example);

    SidbHousekeeping selectByPrimaryKey(SidbHousekeepingKey key);

    int updateByExampleSelective(@Param("record") SidbHousekeeping record, @Param("example") SidbHousekeepingExample example);

    int updateByExample(@Param("record") SidbHousekeeping record, @Param("example") SidbHousekeepingExample example);

    int updateByPrimaryKeySelective(SidbHousekeeping record);

    int updateByPrimaryKey(SidbHousekeeping record);
}