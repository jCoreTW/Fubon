package tw.com.hjct.jmrs.dao.bean;

public class RdOsHousekeepingKey {
    private String folder;

    private String rsFlag;

    private String action;

    public String getFolder() {
        return folder;
    }

    public void setFolder(String folder) {
        this.folder = folder == null ? null : folder.trim();
    }

    public String getRsFlag() {
        return rsFlag;
    }

    public void setRsFlag(String rsFlag) {
        this.rsFlag = rsFlag == null ? null : rsFlag.trim();
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action == null ? null : action.trim();
    }
}