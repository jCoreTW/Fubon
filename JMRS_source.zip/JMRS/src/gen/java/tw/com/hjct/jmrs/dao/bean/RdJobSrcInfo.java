package tw.com.hjct.jmrs.dao.bean;

public class RdJobSrcInfo extends RdJobSrcInfoKey {
    private String jobname;

    private String name;

    private String ftflag;

    private String owner;

    private String ctlFile;

    private String folder;

    private String conname;

    private String fregrExp;

    private String twsAction;

    private String priority;

    public String getJobname() {
        return jobname;
    }

    public void setJobname(String jobname) {
        this.jobname = jobname == null ? null : jobname.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getFtflag() {
        return ftflag;
    }

    public void setFtflag(String ftflag) {
        this.ftflag = ftflag == null ? null : ftflag.trim();
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner == null ? null : owner.trim();
    }

    public String getCtlFile() {
        return ctlFile;
    }

    public void setCtlFile(String ctlFile) {
        this.ctlFile = ctlFile == null ? null : ctlFile.trim();
    }

    public String getFolder() {
        return folder;
    }

    public void setFolder(String folder) {
        this.folder = folder == null ? null : folder.trim();
    }

    public String getConname() {
        return conname;
    }

    public void setConname(String conname) {
        this.conname = conname == null ? null : conname.trim();
    }

    public String getFregrExp() {
        return fregrExp;
    }

    public void setFregrExp(String fregrExp) {
        this.fregrExp = fregrExp == null ? null : fregrExp.trim();
    }

    public String getTwsAction() {
        return twsAction;
    }

    public void setTwsAction(String twsAction) {
        this.twsAction = twsAction == null ? null : twsAction.trim();
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority == null ? null : priority.trim();
    }
}