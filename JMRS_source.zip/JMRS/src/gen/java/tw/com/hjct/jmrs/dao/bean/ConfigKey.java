package tw.com.hjct.jmrs.dao.bean;

import java.math.BigDecimal;

public class ConfigKey {
    private BigDecimal configId;

    private String code;

    public BigDecimal getConfigId() {
        return configId;
    }

    public void setConfigId(BigDecimal configId) {
        this.configId = configId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code == null ? null : code.trim();
    }
}