package tw.com.hjct.jmrs.dao.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import tw.com.hjct.jmrs.dao.bean.RdJobInfo;
import tw.com.hjct.jmrs.dao.bean.RdJobInfoExample;

public interface RdJobInfoMapper {
    long countByExample(RdJobInfoExample example);

    int deleteByExample(RdJobInfoExample example);

    int deleteByPrimaryKey(String num);

    int insert(RdJobInfo record);

    int insertSelective(RdJobInfo record);

    List<RdJobInfo> selectByExample(RdJobInfoExample example);

    RdJobInfo selectByPrimaryKey(String num);

    int updateByExampleSelective(@Param("record") RdJobInfo record, @Param("example") RdJobInfoExample example);

    int updateByExample(@Param("record") RdJobInfo record, @Param("example") RdJobInfoExample example);

    int updateByPrimaryKeySelective(RdJobInfo record);

    int updateByPrimaryKey(RdJobInfo record);
}