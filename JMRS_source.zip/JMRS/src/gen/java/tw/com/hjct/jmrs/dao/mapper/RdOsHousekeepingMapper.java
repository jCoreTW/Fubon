package tw.com.hjct.jmrs.dao.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import tw.com.hjct.jmrs.dao.bean.RdOsHousekeeping;
import tw.com.hjct.jmrs.dao.bean.RdOsHousekeepingExample;
import tw.com.hjct.jmrs.dao.bean.RdOsHousekeepingKey;

public interface RdOsHousekeepingMapper {
    long countByExample(RdOsHousekeepingExample example);

    int deleteByExample(RdOsHousekeepingExample example);

    int deleteByPrimaryKey(RdOsHousekeepingKey key);

    int insert(RdOsHousekeeping record);

    int insertSelective(RdOsHousekeeping record);

    List<RdOsHousekeeping> selectByExample(RdOsHousekeepingExample example);

    RdOsHousekeeping selectByPrimaryKey(RdOsHousekeepingKey key);

    int updateByExampleSelective(@Param("record") RdOsHousekeeping record, @Param("example") RdOsHousekeepingExample example);

    int updateByExample(@Param("record") RdOsHousekeeping record, @Param("example") RdOsHousekeepingExample example);

    int updateByPrimaryKeySelective(RdOsHousekeeping record);

    int updateByPrimaryKey(RdOsHousekeeping record);
}