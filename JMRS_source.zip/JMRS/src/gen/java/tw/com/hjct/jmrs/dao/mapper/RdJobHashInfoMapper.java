package tw.com.hjct.jmrs.dao.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import tw.com.hjct.jmrs.dao.bean.RdJobHashInfo;
import tw.com.hjct.jmrs.dao.bean.RdJobHashInfoExample;
import tw.com.hjct.jmrs.dao.bean.RdJobHashInfoKey;

public interface RdJobHashInfoMapper {
    long countByExample(RdJobHashInfoExample example);

    int deleteByExample(RdJobHashInfoExample example);

    int deleteByPrimaryKey(RdJobHashInfoKey key);

    int insert(RdJobHashInfo record);

    int insertSelective(RdJobHashInfo record);

    List<RdJobHashInfo> selectByExample(RdJobHashInfoExample example);

    RdJobHashInfo selectByPrimaryKey(RdJobHashInfoKey key);

    int updateByExampleSelective(@Param("record") RdJobHashInfo record, @Param("example") RdJobHashInfoExample example);

    int updateByExample(@Param("record") RdJobHashInfo record, @Param("example") RdJobHashInfoExample example);

    int updateByPrimaryKeySelective(RdJobHashInfo record);

    int updateByPrimaryKey(RdJobHashInfo record);
}