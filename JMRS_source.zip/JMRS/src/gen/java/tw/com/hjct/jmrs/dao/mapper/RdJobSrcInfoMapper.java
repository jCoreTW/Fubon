package tw.com.hjct.jmrs.dao.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import tw.com.hjct.jmrs.dao.bean.RdJobSrcInfo;
import tw.com.hjct.jmrs.dao.bean.RdJobSrcInfoExample;
import tw.com.hjct.jmrs.dao.bean.RdJobSrcInfoKey;

public interface RdJobSrcInfoMapper {
    long countByExample(RdJobSrcInfoExample example);

    int deleteByExample(RdJobSrcInfoExample example);

    int deleteByPrimaryKey(RdJobSrcInfoKey key);

    int insert(RdJobSrcInfo record);

    int insertSelective(RdJobSrcInfo record);

    List<RdJobSrcInfo> selectByExample(RdJobSrcInfoExample example);

    RdJobSrcInfo selectByPrimaryKey(RdJobSrcInfoKey key);

    int updateByExampleSelective(@Param("record") RdJobSrcInfo record, @Param("example") RdJobSrcInfoExample example);

    int updateByExample(@Param("record") RdJobSrcInfo record, @Param("example") RdJobSrcInfoExample example);

    int updateByPrimaryKeySelective(RdJobSrcInfo record);

    int updateByPrimaryKey(RdJobSrcInfo record);
}