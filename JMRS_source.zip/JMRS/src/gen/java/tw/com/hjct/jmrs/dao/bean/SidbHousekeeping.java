package tw.com.hjct.jmrs.dao.bean;

public class SidbHousekeeping extends SidbHousekeepingKey {
    private String period;

    private String registEmp;

    private String rcNum;

    private String frequency;

    public String getPeriod() {
        return period;
    }

    public void setPeriod(String period) {
        this.period = period == null ? null : period.trim();
    }

    public String getRegistEmp() {
        return registEmp;
    }

    public void setRegistEmp(String registEmp) {
        this.registEmp = registEmp == null ? null : registEmp.trim();
    }

    public String getRcNum() {
        return rcNum;
    }

    public void setRcNum(String rcNum) {
        this.rcNum = rcNum == null ? null : rcNum.trim();
    }

    public String getFrequency() {
        return frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency == null ? null : frequency.trim();
    }
}