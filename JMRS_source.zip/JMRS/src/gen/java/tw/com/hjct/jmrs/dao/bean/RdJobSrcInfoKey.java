package tw.com.hjct.jmrs.dao.bean;

public class RdJobSrcInfoKey {
    private String num;

    private String rancode;

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num == null ? null : num.trim();
    }

    public String getRancode() {
        return rancode;
    }

    public void setRancode(String rancode) {
        this.rancode = rancode == null ? null : rancode.trim();
    }
}