package tw.com.hjct.jmrs.dao.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import tw.com.hjct.jmrs.dao.bean.WorkLog;
import tw.com.hjct.jmrs.dao.bean.WorkLogExample;

public interface WorkLogMapper {
    long countByExample(WorkLogExample example);

    int deleteByExample(WorkLogExample example);

    int deleteByPrimaryKey(Integer workLogId);

    int insert(WorkLog record);

    int insertSelective(WorkLog record);

    List<WorkLog> selectByExample(WorkLogExample example);

    WorkLog selectByPrimaryKey(Integer workLogId);

    int updateByExampleSelective(@Param("record") WorkLog record, @Param("example") WorkLogExample example);

    int updateByExample(@Param("record") WorkLog record, @Param("example") WorkLogExample example);

    int updateByPrimaryKeySelective(WorkLog record);

    int updateByPrimaryKey(WorkLog record);
}