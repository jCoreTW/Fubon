package tw.com.hjct.jmrs.dao.bean;

import java.util.ArrayList;
import java.util.List;

public class RdSubmitJobExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public RdSubmitJobExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andNumIsNull() {
            addCriterion("NUM is null");
            return (Criteria) this;
        }

        public Criteria andNumIsNotNull() {
            addCriterion("NUM is not null");
            return (Criteria) this;
        }

        public Criteria andNumEqualTo(String value) {
            addCriterion("NUM =", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumNotEqualTo(String value) {
            addCriterion("NUM <>", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumGreaterThan(String value) {
            addCriterion("NUM >", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumGreaterThanOrEqualTo(String value) {
            addCriterion("NUM >=", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumLessThan(String value) {
            addCriterion("NUM <", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumLessThanOrEqualTo(String value) {
            addCriterion("NUM <=", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumLike(String value) {
            addCriterion("NUM like", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumNotLike(String value) {
            addCriterion("NUM not like", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumIn(List<String> values) {
            addCriterion("NUM in", values, "num");
            return (Criteria) this;
        }

        public Criteria andNumNotIn(List<String> values) {
            addCriterion("NUM not in", values, "num");
            return (Criteria) this;
        }

        public Criteria andNumBetween(String value1, String value2) {
            addCriterion("NUM between", value1, value2, "num");
            return (Criteria) this;
        }

        public Criteria andNumNotBetween(String value1, String value2) {
            addCriterion("NUM not between", value1, value2, "num");
            return (Criteria) this;
        }

        public Criteria andMainJsnameIsNull() {
            addCriterion("MAIN_JSNAME is null");
            return (Criteria) this;
        }

        public Criteria andMainJsnameIsNotNull() {
            addCriterion("MAIN_JSNAME is not null");
            return (Criteria) this;
        }

        public Criteria andMainJsnameEqualTo(String value) {
            addCriterion("MAIN_JSNAME =", value, "mainJsname");
            return (Criteria) this;
        }

        public Criteria andMainJsnameNotEqualTo(String value) {
            addCriterion("MAIN_JSNAME <>", value, "mainJsname");
            return (Criteria) this;
        }

        public Criteria andMainJsnameGreaterThan(String value) {
            addCriterion("MAIN_JSNAME >", value, "mainJsname");
            return (Criteria) this;
        }

        public Criteria andMainJsnameGreaterThanOrEqualTo(String value) {
            addCriterion("MAIN_JSNAME >=", value, "mainJsname");
            return (Criteria) this;
        }

        public Criteria andMainJsnameLessThan(String value) {
            addCriterion("MAIN_JSNAME <", value, "mainJsname");
            return (Criteria) this;
        }

        public Criteria andMainJsnameLessThanOrEqualTo(String value) {
            addCriterion("MAIN_JSNAME <=", value, "mainJsname");
            return (Criteria) this;
        }

        public Criteria andMainJsnameLike(String value) {
            addCriterion("MAIN_JSNAME like", value, "mainJsname");
            return (Criteria) this;
        }

        public Criteria andMainJsnameNotLike(String value) {
            addCriterion("MAIN_JSNAME not like", value, "mainJsname");
            return (Criteria) this;
        }

        public Criteria andMainJsnameIn(List<String> values) {
            addCriterion("MAIN_JSNAME in", values, "mainJsname");
            return (Criteria) this;
        }

        public Criteria andMainJsnameNotIn(List<String> values) {
            addCriterion("MAIN_JSNAME not in", values, "mainJsname");
            return (Criteria) this;
        }

        public Criteria andMainJsnameBetween(String value1, String value2) {
            addCriterion("MAIN_JSNAME between", value1, value2, "mainJsname");
            return (Criteria) this;
        }

        public Criteria andMainJsnameNotBetween(String value1, String value2) {
            addCriterion("MAIN_JSNAME not between", value1, value2, "mainJsname");
            return (Criteria) this;
        }

        public Criteria andMainJobnameIsNull() {
            addCriterion("MAIN_JOBNAME is null");
            return (Criteria) this;
        }

        public Criteria andMainJobnameIsNotNull() {
            addCriterion("MAIN_JOBNAME is not null");
            return (Criteria) this;
        }

        public Criteria andMainJobnameEqualTo(String value) {
            addCriterion("MAIN_JOBNAME =", value, "mainJobname");
            return (Criteria) this;
        }

        public Criteria andMainJobnameNotEqualTo(String value) {
            addCriterion("MAIN_JOBNAME <>", value, "mainJobname");
            return (Criteria) this;
        }

        public Criteria andMainJobnameGreaterThan(String value) {
            addCriterion("MAIN_JOBNAME >", value, "mainJobname");
            return (Criteria) this;
        }

        public Criteria andMainJobnameGreaterThanOrEqualTo(String value) {
            addCriterion("MAIN_JOBNAME >=", value, "mainJobname");
            return (Criteria) this;
        }

        public Criteria andMainJobnameLessThan(String value) {
            addCriterion("MAIN_JOBNAME <", value, "mainJobname");
            return (Criteria) this;
        }

        public Criteria andMainJobnameLessThanOrEqualTo(String value) {
            addCriterion("MAIN_JOBNAME <=", value, "mainJobname");
            return (Criteria) this;
        }

        public Criteria andMainJobnameLike(String value) {
            addCriterion("MAIN_JOBNAME like", value, "mainJobname");
            return (Criteria) this;
        }

        public Criteria andMainJobnameNotLike(String value) {
            addCriterion("MAIN_JOBNAME not like", value, "mainJobname");
            return (Criteria) this;
        }

        public Criteria andMainJobnameIn(List<String> values) {
            addCriterion("MAIN_JOBNAME in", values, "mainJobname");
            return (Criteria) this;
        }

        public Criteria andMainJobnameNotIn(List<String> values) {
            addCriterion("MAIN_JOBNAME not in", values, "mainJobname");
            return (Criteria) this;
        }

        public Criteria andMainJobnameBetween(String value1, String value2) {
            addCriterion("MAIN_JOBNAME between", value1, value2, "mainJobname");
            return (Criteria) this;
        }

        public Criteria andMainJobnameNotBetween(String value1, String value2) {
            addCriterion("MAIN_JOBNAME not between", value1, value2, "mainJobname");
            return (Criteria) this;
        }

        public Criteria andSubJobnameIsNull() {
            addCriterion("SUB_JOBNAME is null");
            return (Criteria) this;
        }

        public Criteria andSubJobnameIsNotNull() {
            addCriterion("SUB_JOBNAME is not null");
            return (Criteria) this;
        }

        public Criteria andSubJobnameEqualTo(String value) {
            addCriterion("SUB_JOBNAME =", value, "subJobname");
            return (Criteria) this;
        }

        public Criteria andSubJobnameNotEqualTo(String value) {
            addCriterion("SUB_JOBNAME <>", value, "subJobname");
            return (Criteria) this;
        }

        public Criteria andSubJobnameGreaterThan(String value) {
            addCriterion("SUB_JOBNAME >", value, "subJobname");
            return (Criteria) this;
        }

        public Criteria andSubJobnameGreaterThanOrEqualTo(String value) {
            addCriterion("SUB_JOBNAME >=", value, "subJobname");
            return (Criteria) this;
        }

        public Criteria andSubJobnameLessThan(String value) {
            addCriterion("SUB_JOBNAME <", value, "subJobname");
            return (Criteria) this;
        }

        public Criteria andSubJobnameLessThanOrEqualTo(String value) {
            addCriterion("SUB_JOBNAME <=", value, "subJobname");
            return (Criteria) this;
        }

        public Criteria andSubJobnameLike(String value) {
            addCriterion("SUB_JOBNAME like", value, "subJobname");
            return (Criteria) this;
        }

        public Criteria andSubJobnameNotLike(String value) {
            addCriterion("SUB_JOBNAME not like", value, "subJobname");
            return (Criteria) this;
        }

        public Criteria andSubJobnameIn(List<String> values) {
            addCriterion("SUB_JOBNAME in", values, "subJobname");
            return (Criteria) this;
        }

        public Criteria andSubJobnameNotIn(List<String> values) {
            addCriterion("SUB_JOBNAME not in", values, "subJobname");
            return (Criteria) this;
        }

        public Criteria andSubJobnameBetween(String value1, String value2) {
            addCriterion("SUB_JOBNAME between", value1, value2, "subJobname");
            return (Criteria) this;
        }

        public Criteria andSubJobnameNotBetween(String value1, String value2) {
            addCriterion("SUB_JOBNAME not between", value1, value2, "subJobname");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}