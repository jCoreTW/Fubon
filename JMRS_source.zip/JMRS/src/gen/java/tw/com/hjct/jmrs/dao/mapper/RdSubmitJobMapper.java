package tw.com.hjct.jmrs.dao.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import tw.com.hjct.jmrs.dao.bean.RdSubmitJob;
import tw.com.hjct.jmrs.dao.bean.RdSubmitJobExample;

public interface RdSubmitJobMapper {
    long countByExample(RdSubmitJobExample example);

    int deleteByExample(RdSubmitJobExample example);

    int insert(RdSubmitJob record);

    int insertSelective(RdSubmitJob record);

    List<RdSubmitJob> selectByExample(RdSubmitJobExample example);

    int updateByExampleSelective(@Param("record") RdSubmitJob record, @Param("example") RdSubmitJobExample example);

    int updateByExample(@Param("record") RdSubmitJob record, @Param("example") RdSubmitJobExample example);
}