package tw.com.hjct.jmrs.dao.mapper;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.SelectProvider;

import tw.com.hjct.jmrs.dao.bean.RdJobInfo;
import tw.com.hjct.jmrs.dao.bean.RdOsHousekeeping;
import tw.com.hjct.jmrs.dao.bean.SidbHousekeeping;

public interface CustomMapper {
	
	static class PureSqlProvider {
        public String jobInfo(String where) {
        	String limit = "";
        	if (StringUtils.isBlank(where)) {
        		limit = " WHERE ROWNUM <= 1000";
        	} else {
        		limit = " AND ROWNUM <= 1000";
        	}
            return "SELECT NUM as num, JOBNAME as jobname, JOBSYS as jobsys, FILE_DESCRIPTION as fileDescription, JS_NAME as jsName, FIRST_NAME as firstName, SECOND_NAME as secondName, ISDRAFT as isdraft, GROUP_NAME as groupName, ISSENDMAIL as issendmail, MEMO as memo,  JOB_STIME as jobStime, JOB_ETIME as jobEtime, ISRUN as isrun, MFLAG as mflag, MONITOR as monitor, DEL_YN as delYn  FROM RD_JOBINFO " + where + limit;
        }
        
        public String osHousekeeping(String where) {
        	String limit = "";
        	if (StringUtils.isBlank(where)) {
        		limit = " WHERE ROWNUM <= 1000";
        	} else {
        		limit = " AND ROWNUM <= 1000";
        	}
            return "SELECT ACTION_NAME as actionName, FOLDER as folder, RS_FLAG as rsFlag, EXPIREDATE as expiredate, ACTION as action, DESTINATION as destination FROM RD_OS_HOUSEKEEPING " + where + limit;
        }
        
        public String sidbHousekeeping(String where) {
        	String limit = "";
        	if (StringUtils.isBlank(where)) {
        		limit = " WHERE ROWNUM <= 1000";
        	} else {
        		limit = " AND ROWNUM <= 1000";
        	}
            return "SELECT OWNER as owner, TABLE_NAME as tableName, COLUMN_NAME as columnName, PERIOD as period, REGIST_EMP as registEmp, RC_NUM as rcNum, FREQUENCY as frequency FROM SIDB_HOUSEKEEPING " + where + limit;
        }
        
    }
	
	public Integer selectSequence(@Param("seqName") String seqName);
	
	public String selectJobSrcMaxRancode(@Param("num") String num);
	
	public String selectJobTgtMaxRancode(@Param("num") String num);
	
	public String selectJobHashMaxRancode(@Param("num") String num);
	
	@SelectProvider(type = PureSqlProvider.class, method = "jobInfo")
    public List<RdJobInfo> selectJobInfo(String where);
	
	@SelectProvider(type = PureSqlProvider.class, method = "osHousekeeping")
    public List<RdOsHousekeeping> selectOsHousekeeping(String where);
	
	@SelectProvider(type = PureSqlProvider.class, method = "sidbHousekeeping")
    public List<SidbHousekeeping> selectSidbHousekeeping(String where);
}

