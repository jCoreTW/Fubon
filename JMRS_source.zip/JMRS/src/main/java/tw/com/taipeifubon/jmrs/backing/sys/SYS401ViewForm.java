package tw.com.taipeifubon.jmrs.backing.sys;

import java.util.List;
import java.util.Map;

import tw.com.hjct.jmrs.dao.bean.Config;
import tw.com.taipeifubon.jmrs.ViewForm;

@SuppressWarnings("serial")
public class SYS401ViewForm extends ViewForm {

	private List<String> roles;
	
	private Map<String, Map<String, Boolean>> permissions;
		
	private Config config;

	public Config getConfig() {
		return config;
	}

	public void setConfig(Config config) {
		this.config = config;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public Map<String, Map<String, Boolean>> getPermissions() {
		return permissions;
	}

	public void setPermissions(Map<String, Map<String, Boolean>> permissions) {
		this.permissions = permissions;
	}
	
}
