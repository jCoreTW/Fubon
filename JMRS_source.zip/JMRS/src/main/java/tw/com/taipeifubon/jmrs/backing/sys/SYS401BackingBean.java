package tw.com.taipeifubon.jmrs.backing.sys;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import org.springframework.beans.factory.annotation.Autowired;

import tw.com.hjct.jmrs.dao.bean.ConfigValue;
import tw.com.taipeifubon.jmrs.BackingBeanBase;
import tw.com.taipeifubon.jmrs.service.SystemService;
import tw.com.taipeifubon.jmrs.vo.ConfigValueVo;
import tw.com.taipeifubon.jmrs.vo.ConfigVo;

/**
 * <p>Title: tw.com.taipeifubon.jmrs.backing.sys.SYS401BackingBean</p>
 * <p>Description: WorkLog</p>
 * <p>Copyright: Copyright HJCT. 2020. All Rights Reserved.</p>
 * <p>Company: HJCT</p>
 * @author HJCT
 * @version 1.0
 */
@SuppressWarnings("serial")
@Named
@SessionScoped
public class SYS401BackingBean extends BackingBeanBase<SYS401ViewForm> {

	@Autowired
	protected SystemService systemService;
	
	@Override
	protected void init() {
		selectAll();
	}

	public void selectAll() {
		
		// 所有角色
		ConfigVo roleVo = systemService.findConfigByKey("USER_ROLE");
		List<String> roles = new ArrayList<>();
		for (ConfigValueVo roleValue : roleVo.getConfigValueVos()) {
			roles.add(roleValue.getCode());
		}
		viewForm.setRoles(roles);
		
		
		ConfigVo vo = systemService.findConfigByKey("ROLE_PERMISSION");
		viewForm.setConfig(vo.getConfig());
		
		Map<String, Map<String, Boolean>> permissions = new HashMap<>();
		for (String role : roles) {
			for (ConfigValueVo value : vo.getConfigValueVos()) {
				if (role.equals(value.getCode())) {
					permissions.put(role, createAuth(value));
				}
			}
			
			if (!permissions.containsKey(role)) {
				permissions.put(role, createAuth(null));
			}
		}
		viewForm.setPermissions(permissions);
	}
	
	public Map<String, Boolean> createAuth(ConfigValueVo value) {
		List<String> allFunc = Arrays.asList("SYS101", "SYS201", "SYS301", "SYS401", "REG101", "REG201", "REG301");
		
		Map<String, Boolean> auth = new HashMap<>();
		for (String func : allFunc) {
			auth.put(func, value == null ? false : value.getConfigValue().getValue().indexOf(func) > -1);
		}
		return auth;
	}
	
	public void doSaveAction() {
		Integer configId = viewForm.getConfig().getConfigId();
		List<ConfigValue> configValue = new ArrayList<>();
		for (String role : viewForm.getRoles()) {
			ConfigValue ap = new ConfigValue();
			ap.setConfigId(configId);
			ap.setCode(role);
			ap.setValue(createAuthString(viewForm.getPermissions().get(role)));
			ap.setState("T");
			ap.setReadOnly("F");
			configValue.add(ap);
		}
		
		try {
			
			systemService.updatePermission(configId, configValue);
			
			// 工作日誌
//			saveWorkLog("Configure", WorkLogAction.Update, logContent);
//			viewForm.setSelectType(oldType);
			setGlobalMessageFormat("msgs", "info.update.success");
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
			setGlobalErrorMessageFormat("error.update.fail", e.getMessage());
		}
	}
	
	private String createAuthString(Map<String, Boolean> auth) {
		StringBuffer result = new StringBuffer();
		for (String key : auth.keySet()) {
			if (auth.get(key)) {
				result.append(key).append(",");
			}
		}
		
		if (result.length() > 0) {
			result.setLength(result.length() - 1);
		} else {
			result.append("n/a");
		}
		return result.toString();
	}
}
