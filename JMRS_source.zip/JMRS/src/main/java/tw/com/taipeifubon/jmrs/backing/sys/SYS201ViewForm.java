package tw.com.taipeifubon.jmrs.backing.sys;

import java.util.List;

import javax.faces.model.SelectItem;

import tw.com.hjct.jmrs.dao.bean.Whitelist;
import tw.com.taipeifubon.jmrs.ViewForm;

@SuppressWarnings("serial")
public class SYS201ViewForm extends ViewForm {

	/** Role選項 */
	private List<SelectItem> roleItems;
	
	/** Domain選項 */
	private List<SelectItem> domainItems;
	
	private String account;
	
	private String domain;
	
	private String role;
	
	private List<Whitelist> whitelist;

	private String newAccount;
	
	private String newDomain;
	
	private String newRole;
	
	private Whitelist selectedWhitelist;
	
	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public List<SelectItem> getRoleItems() {
		return roleItems;
	}

	public void setRoleItems(List<SelectItem> roleItems) {
		this.roleItems = roleItems;
	}

	public List<Whitelist> getWhitelist() {
		return whitelist;
	}

	public void setWhitelist(List<Whitelist> whitelist) {
		this.whitelist = whitelist;
	}

	public String getNewAccount() {
		return newAccount;
	}

	public void setNewAccount(String newAccount) {
		this.newAccount = newAccount;
	}

	public String getNewDomain() {
		return newDomain;
	}

	public void setNewDomain(String newDomain) {
		this.newDomain = newDomain;
	}

	public String getNewRole() {
		return newRole;
	}

	public void setNewRole(String newRole) {
		this.newRole = newRole;
	}

	public Whitelist getSelectedWhitelist() {
		return selectedWhitelist;
	}

	public void setSelectedWhitelist(Whitelist selectedWhitelist) {
		this.selectedWhitelist = selectedWhitelist;
	}

	public List<SelectItem> getDomainItems() {
		return domainItems;
	}

	public void setDomainItems(List<SelectItem> domainItems) {
		this.domainItems = domainItems;
	}
	
}
