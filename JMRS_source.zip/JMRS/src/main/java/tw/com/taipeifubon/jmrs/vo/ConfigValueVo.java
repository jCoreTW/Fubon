package tw.com.taipeifubon.jmrs.vo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import tw.com.hjct.jmrs.dao.bean.ConfigValue;

/**
 * <p>Title: com.torsc.tcbis.ext.vo.ConfigValueVo</p>
 * <p>Description: ConfigValue資料物件</p>
 * <p>Copyright: Copyright jCore. 2018. All Rights Reserved.</p>
 * <p>Company: jCore</p>
 * @author jCore
 * @version 1.0
 */
public class ConfigValueVo {
	
	private Integer configId;
	
	private String code;
	
	/** 組態值 */
	private ConfigValue configValue;
	
	public Integer getConfigId() {
		return configId;
	}

	public void setConfigId(Integer configId) {
		this.configId = configId;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	public ConfigValue getConfigValue() {
		return configValue;
	}

	public void setConfigValue(ConfigValue configValue) {
		this.configValue = configValue;
	}

}
