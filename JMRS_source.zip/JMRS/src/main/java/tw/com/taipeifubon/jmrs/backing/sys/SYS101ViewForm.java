package tw.com.taipeifubon.jmrs.backing.sys;

import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import tw.com.taipeifubon.jmrs.ViewForm;
import tw.com.taipeifubon.jmrs.vo.ConfigValueVo;
import tw.com.taipeifubon.jmrs.vo.ConfigVo;

@SuppressWarnings("serial")
public class SYS101ViewForm extends ViewForm {

	/** 所有設定 */
	private Map<String, ConfigVo> configs;
	
	/** 組態分類選項 */
	private List<SelectItem> typeItems;
	
	/** 組態列表 */
	private List<ConfigVo> configVos;
	
	/** 選擇分類 */
	private String selectType = "C";
	private ConfigVo selectConfig;
	private ConfigValueVo selectValue;
	
	/** 組態代碼 */
	private String configCode;
	/** 組態分類 */
	private String configType;
	/** 描述 */
	private String configDesc;
	
	/** 設定碼 */
	private String valueCode;
	private boolean disableValueCode;
	
	/** 設定值 */
	private String value;
	/** 狀態 */
	private String state;
	
	private boolean disableDeleteBtn;

	public Map<String, ConfigVo> getConfigs() {
		return configs;
	}

	public void setConfigs(Map<String, ConfigVo> configs) {
		this.configs = configs;
	}

	public String getSelectType() {
		return selectType;
	}

	public void setSelectType(String selectType) {
		this.selectType = selectType;
	}

	public List<SelectItem> getTypeItems() {
		return typeItems;
	}

	public void setTypeItems(List<SelectItem> typeItems) {
		this.typeItems = typeItems;
	}

	public List<ConfigVo> getConfigVos() {
		return configVos;
	}

	public void setConfigVos(List<ConfigVo> configVos) {
		this.configVos = configVos;
	}

	public ConfigVo getSelectConfig() {
		return selectConfig;
	}

	public void setSelectConfig(ConfigVo selectConfig) {
		this.selectConfig = selectConfig;
	}

	public String getConfigCode() {
		return configCode;
	}

	public void setConfigCode(String configCode) {
		this.configCode = configCode;
	}

	public String getConfigType() {
		return configType;
	}

	public void setConfigType(String configType) {
		this.configType = configType;
	}

	public String getConfigDesc() {
		return configDesc;
	}

	public void setConfigDesc(String configDesc) {
		this.configDesc = configDesc;
	}

	public String getValueCode() {
		return valueCode;
	}

	public void setValueCode(String valueCode) {
		this.valueCode = valueCode;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public ConfigValueVo getSelectValue() {
		return selectValue;
	}

	public void setSelectValue(ConfigValueVo selectValue) {
		this.selectValue = selectValue;
	}

	public boolean isDisableValueCode() {
		return disableValueCode;
	}

	public void setDisableValueCode(boolean disableValueCode) {
		this.disableValueCode = disableValueCode;
	}

	public boolean isDisableDeleteBtn() {
		return disableDeleteBtn;
	}

	public void setDisableDeleteBtn(boolean disableDeleteBtn) {
		this.disableDeleteBtn = disableDeleteBtn;
	}
	
}
