package tw.com.taipeifubon.jmrs;

import java.io.Serializable;
import java.util.ResourceBundle;

import javax.faces.application.Application;
import javax.faces.context.FacesContext;

/**
 * <p>Title: tw.com.hjct.fos.ViewForm</p>
 * <p>Description: 頁面表單欄位介面</p>
 * <p>Copyright: Copyright HJCT. 2014. All Rights Reserved.</p>
 * <p>Company: HJCT</p>
 * @author HJCT
 * @version 1.0
 */
public class ViewForm implements Serializable {

	private static final long serialVersionUID = 8389835871900681703L;

	/** View Form所屬的Backing Bean */
	protected BackingBeanBase<ViewForm> backingBean;
	
	/** 是否停用功能 */
	protected boolean isDisableFunction;
	
	/**
	 * 取得多國語操作物件
	 * @param bundleName
	 * @return
	 */
	public ResourceBundle getResourceBundle(String bundleName) {
		FacesContext context = FacesContext.getCurrentInstance();
		Application app = FacesContext.getCurrentInstance().getApplication();
		return app.getResourceBundle(context, bundleName);
	}

	@SuppressWarnings("rawtypes")
	public BackingBeanBase getBackingBean() {
		return backingBean;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void setBackingBean(BackingBeanBase backingBean) {
		this.backingBean = backingBean;
	}

	public boolean isDisableFunction() {
		return isDisableFunction;
	}

	public void setDisableFunction(boolean isDisableFunction) {
		this.isDisableFunction = isDisableFunction;
	}

}
