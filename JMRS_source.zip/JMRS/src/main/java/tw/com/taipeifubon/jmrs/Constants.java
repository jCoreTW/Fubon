package tw.com.taipeifubon.jmrs;

/**
 * <p>Title: tw.com.taipeifubon.jmrs.Constants</p>
 * <p>Description: 共用常數</p>
 * <p>Copyright: Copyright HJCT. 2020. All Rights Reserved.</p>
 * <p>Company: HJCT</p>
 * @author Ricky
 * @version 1.0
 */
public interface Constants {
	
	public static final String SESSION_PROFILE = "SESSION_PROFILE"; // 登入者資料
	
	
	enum WorkLogAction {
		Add,
		Update,
		Delete,
		Execute
	};
	
}
