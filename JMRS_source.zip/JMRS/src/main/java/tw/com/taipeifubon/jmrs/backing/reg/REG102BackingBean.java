package tw.com.taipeifubon.jmrs.backing.reg;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.SessionScoped;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.model.SelectItem;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.primefaces.PrimeFaces;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import tw.com.hjct.jmrs.dao.bean.RdJobHashInfo;
import tw.com.hjct.jmrs.dao.bean.RdJobHashInfoKey;
import tw.com.hjct.jmrs.dao.bean.RdJobInfo;
import tw.com.hjct.jmrs.dao.bean.RdJobSrcInfo;
import tw.com.hjct.jmrs.dao.bean.RdJobSrcInfoKey;
import tw.com.hjct.jmrs.dao.bean.RdJobTgtInfo;
import tw.com.hjct.jmrs.dao.bean.RdJobTgtInfoKey;
import tw.com.hjct.jmrs.dao.bean.RdSubmitJob;
import tw.com.taipeifubon.jmrs.BackingBeanBase;
import tw.com.taipeifubon.jmrs.Constants.WorkLogAction;
import tw.com.taipeifubon.jmrs.service.RegisterService;
import tw.com.taipeifubon.jmrs.service.SystemService;
import tw.com.taipeifubon.jmrs.vo.ConfigVo;

/**
 * <p>Title: tw.com.taipeifubon.jmrs.backing.reg.REG102BackingBean</p>
 * <p>Description: JobInfo Detail</p>
 * <p>Copyright: Copyright HJCT. 2020. All Rights Reserved.</p>
 * <p>Company: HJCT</p>
 * @author HJCT
 * @version 1.0
 */
@SuppressWarnings("serial")
@Named
@SessionScoped
public class REG102BackingBean extends BackingBeanBase<REG102ViewForm> {

	@Autowired
	private SystemService systemService;
	
	@Autowired
	private RegisterService registerService;
	
	private DataTable submitJobTable;
	
	@Override
	protected void init() {
		ConfigVo config = systemService.findConfigByKey("MONITOR");
		List<SelectItem> monItems = new ArrayList<>();
		config.getConfigValueVos().forEach(valVo -> {
			monItems.add(new SelectItem(valVo.getCode(), valVo.getConfigValue().getValue()));
		});
		viewForm.setMonitorItems(monItems);
	}
	
	public void initialData() {
		String num = viewForm.getJobInfo().getNum();
		selectJobSrcInfo(num);
		selectJobTgtInfo(num);
		selectJobHashInfo(num);
		selectSubmitJobInfo(num);
	}
	
	private void selectJobSrcInfo(String num) {
		viewForm.setJobSrcInfos(registerService.selectJobSrcInfoByNum(num));
		List<Boolean> ckbox = new ArrayList<>();
		for (int i = 0; i < viewForm.getJobSrcInfos().size(); i++) {
			ckbox.add(false);
			
			if (i == viewForm.getJobSrcInfos().size() - 1) {
				viewForm.setCurrentSrcRanCode(Integer.valueOf(viewForm.getJobSrcInfos().get(i).getRancode()));
			}
		}
		viewForm.setSrcSelectCkbox(ckbox);
	}
	
	private void selectJobTgtInfo(String num) {
		viewForm.setJobTgtInfos(registerService.selectJobTgtInfoByNum(num));
		List<Boolean> ckbox = new ArrayList<>();
		for (int i = 0; i < viewForm.getJobTgtInfos().size(); i++) {
			ckbox.add(false);
		}
		viewForm.setTgtSelectCkbox(ckbox);
	}
	
	private void selectJobHashInfo(String num) {
		viewForm.setJobHashInfos(registerService.selectJobHashInfoByNum(num));
		List<Boolean> ckbox = new ArrayList<>();
		for (int i = 0; i < viewForm.getJobHashInfos().size(); i++) {
			ckbox.add(false);
		}
		viewForm.setHashSelectCkbox(ckbox);
	}
	
	private void selectSubmitJobInfo(String num) {
		viewForm.setSubmitJobs(registerService.selectSubmitJobByNum(num));
		List<Boolean> ckbox = new ArrayList<>();
		for (int i = 0; i < viewForm.getSubmitJobs().size(); i++) {
			ckbox.add(false);
		}
		viewForm.setSubmitSelectCkbox(ckbox);
	}

	public void doBackAction() {
		REG101BackingBean bean = findBean("REG101BackingBean");
		bean.getViewForm().getJobInfos().clear();
		bean.getViewForm().getJobInfos().add(viewForm.getJobInfo());
//		bean.doSearchAction();
		redirect("/WEB-INF/pages/REG/REG101/REG101.xhtml");
	}
	
	/**
	 * Delete confirm
	 */
	public void doConfirmDeleteAction() {
		// 查詢關聯
		String num = viewForm.getJobInfo().getNum();
		viewForm.setDeleteConfirmMsg(String.format("JobSrcInfo：%d\nJobTgtInfo：%d\nJobHashInfo：%d\nSubmitJob：%d", 
				registerService.countJobSrcInfoByNum(num),
				registerService.countJobTgtInfoByNum(num),
				registerService.countJobHashInfoByNum(num),
				registerService.countSubmitJobByNum(num)));
	}
	
	/**
	 * Delete
	 */
	public void doDeleteAction() {
		try {
			RdJobInfo info = viewForm.getJobInfo();
			registerService.deleteJobInfoByNum(info.getNum());
			viewForm.setDeleteConfirmMsg("");
			
			// 工作日誌
			String logContent = String.format("Delete JobInfo[NUM=%s][JOBNAME=%s][JOBSYS=%s][FILE_DESCRIPTION=%s][JS_NAME=%s][FIRST_NAME=%s][SECOND_NAME=%s][ISDRAFT=%s][GROUP_NAME=%s][ISSENDMAIL=%s][MEMO=%s][MFLAG=%s][MONITOR=%s]", 
					info.getNum(), info.getJobname(), info.getJobsys(), info.getFileDescription(),
					info.getJsName(), info.getFirstName(), info.getSecondName(), info.getIsdraft(),
					info.getGroupName(), info.getIssendmail(), info.getMemo(), info.getMflag(),
					info.getMonitor());
			saveWorkLog("JobInfo", WorkLogAction.Delete, logContent);
			
			setGlobalMessageFormat("msgs", "info.delete.success");
			doBackAction();
			
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
			setGlobalErrorMessageFormat("msgs", "error.delete.fail");
		}
	}
	
	/**
	 * Update
	 */
	public void doUpdateAction() {
		if (validateCreate()) {
			RdJobInfo src = viewForm.getJobInfo();
			RdJobInfo toUpdate = new RdJobInfo();
			BeanUtils.copyProperties(src, toUpdate);
			
			toUpdate.setJobname(viewForm.getJobName());
			toUpdate.setJobsys(viewForm.getJobSys());
			toUpdate.setJsName(viewForm.getJsName());
			toUpdate.setFirstName(viewForm.getFirstName());
			toUpdate.setSecondName(viewForm.getSecondName());
			toUpdate.setIsdraft(viewForm.getIsDraft());
			toUpdate.setIssendmail(viewForm.getIsSendMail());
			toUpdate.setMflag(viewForm.getmFlag());
			toUpdate.setMonitor(StringUtils.join(viewForm.getMonitor().toArray(), ","));
			toUpdate.setGroupName(viewForm.getGroupName());
			toUpdate.setFileDescription(viewForm.getFileDescription());
			toUpdate.setMemo(viewForm.getMemo());
			
			try {
				registerService.updateJobInfo(toUpdate);
				
				// 工作日誌
				String logContent = String.format("Update JobInfo[NUM=%s][JOBNAME=%s|%s][JOBSYS=%s|%s][FILE_DESCRIPTION=%s|%s][JS_NAME=%s|%s][FIRST_NAME=%s|%s][SECOND_NAME=%s|%s][ISDRAFT=%s|%s][GROUP_NAME=%s|%s][ISSENDMAIL=%s|%s][MEMO=%s|%s][MFLAG=%s|%s][MONITOR=%s|%s]", 
						src.getNum(), 
						src.getJobname(), toUpdate.getJobname(), 
						src.getJobsys(), toUpdate.getJobsys(), 
						src.getFileDescription(), toUpdate.getFileDescription(),
						src.getJsName(), toUpdate.getJsName(), 
						src.getFirstName(), toUpdate.getFirstName(), 
						src.getSecondName(), toUpdate.getSecondName(), 
						src.getIsdraft(), toUpdate.getIsdraft(), 
						src.getGroupName(), toUpdate.getGroupName(), 
						src.getIssendmail(), toUpdate.getIssendmail(), 
						src.getMemo(), toUpdate.getMemo(), 
						src.getMflag(), toUpdate.getMflag(),
						src.getMonitor(), toUpdate.getMonitor());
				saveWorkLog("JobInfo", WorkLogAction.Update, logContent);
				
				setGlobalMessageFormat("msgs", "info.update.success");
				
				viewForm.setJobInfo(toUpdate);
				
			} catch (Exception e) {
				_logger.error(e.getMessage(), e);
				setGlobalErrorMessageFormat("msgs", "error.update.fail");
			}
			
		}
	}
	
	private boolean validateCreate() {
		boolean result = true;
		
		if (StringUtils.isBlank(viewForm.getJobName())) {
			setComponentErrorMessage("uptTab:jobName", "msgs", "validate.required");
			result = false;
		}
		
		if (StringUtils.isBlank(viewForm.getJobSys())) {
			setComponentErrorMessage("uptTab:jobSys", "msgs", "validate.required");
			result = false;
		}
		
		if (StringUtils.isBlank(viewForm.getJsName())) {
			setComponentErrorMessage("uptTab:jsName", "msgs", "validate.required");
			result = false;
		}
		
		if (StringUtils.isBlank(viewForm.getFirstName())) {
			setComponentErrorMessage("uptTab:firstName", "msgs", "validate.required");
			result = false;
		}
		
		if (StringUtils.isBlank(viewForm.getSecondName())) {
			setComponentErrorMessage("uptTab:secondName", "msgs", "validate.required");
			result = false;
		}
		
		if (StringUtils.isBlank(viewForm.getGroupName())) {
			setComponentErrorMessage("uptTab:groupName", "msgs", "validate.required");
			result = false;
		}
		
		if (StringUtils.isBlank(viewForm.getFileDescription())) {
			setComponentErrorMessage("uptTab:fileDescription", "msgs", "validate.required");
			result = false;
		}
		
		if (result) {
			RdJobInfo src = viewForm.getJobInfo();
			if (!StringUtils.equals(viewForm.getJobName(), src.getJobname())
					|| !StringUtils.equals(viewForm.getJobSys(), src.getJobsys())) {
				RdJobInfo exist = registerService.findJobInfoByJobNameAndJobSys(viewForm.getJobName(), viewForm.getJobSys());
				if (exist != null) {
					setGlobalErrorMessageFormat("msgs", "error.jobinfo.uniquie.key.error");
					result = false;
				}
			}
		}
		
		return result;
	}
	
	/**
	 * Delete one JobSrcInfo
	 * @param src
	 */
	public void doDeleteSrcAction(RdJobSrcInfo src) {
		try {
			if (src == null) {
				src = viewForm.getSelectedJobSrcInfo();
			}
			
			RdJobSrcInfoKey pk = new RdJobSrcInfoKey();
			pk.setNum(src.getNum());
			pk.setRancode(src.getRancode());
			registerService.deleteJobSrcInfoByPk(pk);
			
			// 工作日誌
			String logContent = String.format("Delete JobSrcInfo[NUM=%s][RANCODE=%s]", src.getNum(), src.getRancode());
			saveWorkLog("JobSrcInfo", WorkLogAction.Delete, logContent);
			
			selectJobSrcInfo(src.getNum());
			setGlobalMessageFormat("msgs", "info.delete.success");
			
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
			setGlobalErrorMessageFormat("msgs", "error.delete.fail");
		}
	}
	
	/**
	 * Delete one JobTgtInfo
	 * @param src
	 */
	public void doDeleteTgtAction(RdJobTgtInfo tgt) {
		try {
			if (tgt == null) {
				tgt = viewForm.getSelectedJobTgtInfo();
			}
			
			RdJobTgtInfoKey pk = new RdJobTgtInfoKey();
			pk.setNum(tgt.getNum());
			pk.setRancode(tgt.getRancode());
			registerService.deleteJobTgtInfoByPk(pk);
			
			// 工作日誌
			String logContent = String.format("Delete JobTgtInfo[NUM=%s][RANCODE=%s]", tgt.getNum(), tgt.getRancode());
			saveWorkLog("JobTgtInfo", WorkLogAction.Delete, logContent);
			
			selectJobTgtInfo(tgt.getNum());
			setGlobalMessageFormat("msgs", "info.delete.success");
			
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
			setGlobalErrorMessageFormat("msgs", "error.delete.fail");
		}
	}
	
	/**
	 * Delete one JobHashInfo
	 * @param src
	 */
	public void doDeleteHashAction(RdJobHashInfo hash) {
		try {
			if (hash == null) {
				hash = viewForm.getSelectedJobHashInfo();
			}
			
			RdJobHashInfoKey pk = new RdJobHashInfoKey();
			pk.setNum(hash.getNum());
			pk.setRancode(hash.getRancode());
			registerService.deleteJobHashInfoByPk(pk);
			
			// 工作日誌
			String logContent = String.format("Delete JobHashInfo[NUM=%s][RANCODE=%s]", hash.getNum(), hash.getRancode());
			saveWorkLog("JobHashInfo", WorkLogAction.Delete, logContent);
			
			selectJobHashInfo(hash.getNum());
			setGlobalMessageFormat("msgs", "info.delete.success");
			
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
			setGlobalErrorMessageFormat("msgs", "error.delete.fail");
		}
	}
	
	public void doDeleteSubmitAction(RdSubmitJob job) {
		try {
			if (job == null) {
				job = viewForm.getSelectedRdSubmitJob();
			}
			
			registerService.deleteSubmitJob(job);
			
			// 工作日誌
			String logContent = String.format("Delete SubmitJob[NUM=%s][MAIN_JSNAME=%s][MAIN_JOBNAME=%s][SUB_JOBNAME=%s]", 
					job.getNum(), job.getMainJsname(), job.getMainJobname(), job.getSubJobname());
			saveWorkLog("SubmitJob", WorkLogAction.Delete, logContent);
			
			selectSubmitJobInfo(job.getNum());
			setGlobalMessageFormat("msgs", "info.delete.success");
			
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
			setGlobalErrorMessageFormat("msgs", "error.delete.fail");
		}
	}
	
	/**
	 * Add JobSrcInfo
	 */
	public void doAddSrcAction() {
		if (validateJobSrcInfo()) {
			RdJobSrcInfo info = new RdJobSrcInfo();
			info.setNum(viewForm.getJobInfo().getNum());
			info.setJobname(viewForm.getJobInfo().getJobname());
			info.setName(viewForm.getSrcName());
			info.setFtflag(viewForm.getSrcFTFlag());
			info.setOwner(viewForm.getSrcOwner());
			info.setCtlFile(viewForm.getSrcCtlFile());
			info.setFolder(viewForm.getSrcFolder());
			info.setConname(viewForm.getSrcConname());
			info.setFregrExp(viewForm.getSrcFregrExp());
			info.setTwsAction(viewForm.getSrcTwsAction());
			info.setPriority(viewForm.getSrcPriority());
			
			try {
				info = registerService.insertJobSrcInfo(info);
				clearSrcFields();
				selectJobSrcInfo(info.getNum());
				
				// 工作日誌
				String logContent = String.format("Add JobSrcInfo[Num=%s][Rancode=%s]", info.getNum(), info.getRancode());
				saveWorkLog("JobSrcInfo", WorkLogAction.Add, logContent);
				
				setGlobalMessageFormat("msgs", "info.create.success");
				
			} catch (Exception e) {
				_logger.error(e.getMessage(), e);
				setGlobalErrorMessageFormat("msgs", "error.create.fail");
			}
		}
	}
	
	/**
	 * Add JobTgtInfo
	 */
	public void doAddTgtAction() {
		if (validateJobTgtInfo()) {
			RdJobTgtInfo info = new RdJobTgtInfo();
			info.setNum(viewForm.getJobInfo().getNum());
			info.setJobname(viewForm.getJobInfo().getJobname());
			info.setName(viewForm.getTgtName());
			info.setFtflag(viewForm.getTgtFTFlag());
			info.setOwner(viewForm.getTgtOwner());
			info.setFolder(viewForm.getTgtFolder());
			info.setConname(viewForm.getTgtConname());
			info.setTgtNode(viewForm.getTgtNode());
			info.setTgtDir(viewForm.getTgtDir());
			info.setTgtFilename(viewForm.getTgtFilename());
			info.setSrcFiletype(viewForm.getTgtSrcFileType());
			info.setTgtFiletype(viewForm.getTgtFileType());
			
			try {
				info = registerService.insertJobTgtInfo(info);
				clearTgtFields();
				
				// 工作日誌
				String logContent = String.format("Add JobTgtInfo[Num=%s][Rancode=%s]", info.getNum(), info.getRancode());
				saveWorkLog("JobTgtInfo", WorkLogAction.Add, logContent);
				
				setGlobalMessageFormat("msgs", "info.create.success");
				selectJobTgtInfo(viewForm.getJobInfo().getNum());
				
			} catch (Exception e) {
				_logger.error(e.getMessage(), e);
				setGlobalErrorMessageFormat("msgs", "error.create.fail");
			}
		}
	}
	
	/**
	 * Add JobHashInfo
	 */
	public void doAddHashAction() {
		if (validateJobHashInfo()) {
			RdJobHashInfo info = new RdJobHashInfo();
			info.setNum(viewForm.getJobInfo().getNum());
			info.setJobname(viewForm.getJobInfo().getJobname());
			info.setName(viewForm.getHashName());
			info.setFtflag(viewForm.getHashFTFlag());
			info.setOwner(viewForm.getHashOwner());
			info.setConname(viewForm.getHashConname());
			info.setFregrExp(viewForm.getHashFregrExp());
			
			try {
				info = registerService.insertJobHashInfo(info);
				clearHashFields();
				
				// 工作日誌
				String logContent = String.format("Add JobHashInfo[Num=%s][Rancode=%s]", info.getNum(), info.getRancode());
				saveWorkLog("JobHashInfo", WorkLogAction.Add, logContent);
				
				setGlobalMessageFormat("msgs", "info.create.success");
				selectJobHashInfo(viewForm.getJobInfo().getNum());
				
			} catch (Exception e) {
				_logger.error(e.getMessage(), e);
				setGlobalErrorMessageFormat("msgs", "error.create.fail");
			}
		}
	}
	
	/**
	 * Add SubmitJob
	 */
	public void doAddSubmitAction() {
		if (validateSubmitJob()) {
			RdSubmitJob job = new RdSubmitJob();
			job.setNum(viewForm.getJobInfo().getNum());
			job.setMainJobname(viewForm.getJobInfo().getJobname());
			job.setMainJsname(viewForm.getJobInfo().getJsName());
			job.setSubJobname(viewForm.getSubmitSubJobName());
			
			try {
				registerService.insertSubmitJob(job);
				clearSubmitFields();
				
				// 工作日誌
				String logContent = String.format("Add SubmitJob[NUM=%s][MAIN_JSNAME=%s][MAIN_JOBNAME=%s][SUB_JOBNAME=%s]", 
						job.getNum(), job.getMainJobname(), job.getMainJsname(), job.getSubJobname());
				saveWorkLog("SubmitJob", WorkLogAction.Add, logContent);
				
				setGlobalMessageFormat("msgs", "info.create.success");
				selectSubmitJobInfo(viewForm.getJobInfo().getNum());
				
			} catch (Exception e) {
				_logger.error(e.getMessage(), e);
				setGlobalErrorMessageFormat("msgs", "error.create.fail");
			}
		}
	}
	
	public void ftFlagChanged(AjaxBehaviorEvent event) {
		if ("F".equals(viewForm.getSrcFTFlag())) {
			viewForm.setSrcOwner("");
		} else if ("T".equals(viewForm.getSrcFTFlag())) {
			viewForm.setSrcCtlFile("");
			viewForm.setSrcFolder("");
			viewForm.setSrcFregrExp("");
		}
	}
	
	public void tgtFTFlagChanged(AjaxBehaviorEvent event) {
		if ("F".equals(viewForm.getTgtFTFlag())) {
			viewForm.setTgtOwner("");
		} else if ("T".equals(viewForm.getTgtFTFlag())) {
			viewForm.setTgtFolder("");
			viewForm.setTgtNode("");
			viewForm.setTgtDir("");
			viewForm.setTgtFilename("");
			viewForm.setTgtSrcFileType("");
			viewForm.setTgtFileType("");
		}
	}
	
	public void hashFTFlagChanged(AjaxBehaviorEvent event) {
		if ("F".equals(viewForm.getHashFTFlag())) {
			viewForm.setHashOwner("");
		} else if ("T".equals(viewForm.getHashFTFlag())) {
			viewForm.setHashFregrExp("");
		}
	}
	
	public void clearSrcFields() {
		viewForm.setSrcName("");
		viewForm.setSrcFTFlag("F");
		viewForm.setSrcOwner("");
		viewForm.setSrcCtlFile("");
		viewForm.setSrcFolder("");
		viewForm.setSrcConname("");
		viewForm.setSrcFregrExp("");
		viewForm.setSrcTwsAction("");
		viewForm.setSrcPriority("");
		viewForm.setSelectedJobSrcInfo(null);
	}
	
	public void clearTgtFields() {
		viewForm.setTgtName("");
		viewForm.setTgtFTFlag("F");
		viewForm.setTgtOwner("");
		viewForm.setTgtFolder("");
		viewForm.setTgtConname("");
		viewForm.setTgtNode("");
		viewForm.setTgtDir("");
		viewForm.setTgtFilename("");
		viewForm.setTgtSrcFileType("");
		viewForm.setTgtFileType("");
		viewForm.setSelectedJobTgtInfo(null);
	}
	
	public void clearHashFields() {
		viewForm.setHashName("");
		viewForm.setHashFTFlag("F");
		viewForm.setHashOwner("");
		viewForm.setHashConname("");
		viewForm.setHashFregrExp("");
		viewForm.setSelectedJobHashInfo(null);
	}
	
	public void clearSubmitFields() {
		viewForm.setSubmitSubJobName("");
		viewForm.setSelectedRdSubmitJob(null);
	}
	
	private boolean validateJobSrcInfo() {
		boolean result = true;
		if (StringUtils.isBlank(viewForm.getSrcName())) {
			setComponentErrorMessage("srcName", "msgs", "validate.required");
			result = false;
		}
		
		if ("F".equals(viewForm.getSrcFTFlag())) {
			if (StringUtils.isBlank(viewForm.getSrcCtlFile())) {
				setComponentErrorMessage("srcCtlFile", "msgs", "validate.required");
				result = false;
			}
			
			if (StringUtils.isBlank(viewForm.getSrcFolder())) {
				setComponentErrorMessage("srcFolder", "msgs", "validate.required");
				result = false;
			}
			
			if (StringUtils.isBlank(viewForm.getSrcFregrExp())) {
				setComponentErrorMessage("srcFregrExp", "msgs", "validate.required");
				result = false;
			}
			
		} else if ("T".equals(viewForm.getSrcFTFlag())) {
			if (StringUtils.isBlank(viewForm.getSrcOwner())) {
				setComponentErrorMessage("srcOwner", "msgs", "validate.required");
				result = false;
			}
			
		}
		
		if (StringUtils.isNotBlank(viewForm.getSrcPriority())) {
			try {
				Integer i = Integer.valueOf(viewForm.getSrcPriority());
				if (i < 10 || i > 101) {
					setComponentErrorMessage("srcPriority", "msgs", "validate.date.out.of.range");
					result = false;
				}
			} catch (NumberFormatException ex) {
				setComponentErrorMessage("srcPriority", "msgs", "validate.not.a.number");
				result = false;
			}
		}
		
		return result;
	}
	
	private boolean validateJobTgtInfo() {
		boolean result = true;
		if (StringUtils.isBlank(viewForm.getTgtName())) {
			setComponentErrorMessage("tgtName", "msgs", "validate.required");
			result = false;
		}
		
		if ("F".equals(viewForm.getTgtFTFlag())) {
			if (StringUtils.isBlank(viewForm.getTgtFolder())) {
				setComponentErrorMessage("tgtFolder", "msgs", "validate.required");
				result = false;
			}
			
			if (StringUtils.isBlank(viewForm.getTgtNode())) {
				setComponentErrorMessage("tgtNode", "msgs", "validate.required");
				result = false;
			}
			
			if (StringUtils.isBlank(viewForm.getTgtDir())) {
				setComponentErrorMessage("tgtDir", "msgs", "validate.required");
				result = false;
			}
			
			if (StringUtils.isBlank(viewForm.getTgtFilename())) {
				setComponentErrorMessage("tgtFilename", "msgs", "validate.required");
				result = false;
			}
			
			if (StringUtils.isBlank(viewForm.getTgtSrcFileType())) {
				setComponentErrorMessage("tgtSrcFileType", "msgs", "validate.required");
				result = false;
			}
			
			if (StringUtils.isBlank(viewForm.getTgtFileType())) {
				setComponentErrorMessage("tgtFileType", "msgs", "validate.required");
				result = false;
			}
			
		} else if ("T".equals(viewForm.getTgtFTFlag())) {
			if (StringUtils.isBlank(viewForm.getTgtOwner())) {
				setComponentErrorMessage("tgtOwner", "msgs", "validate.required");
				result = false;
			}
			
		}
		
		return result;
	}
	
	private boolean validateJobHashInfo() {
		boolean result = true;
		if (StringUtils.isBlank(viewForm.getHashName())) {
			setComponentErrorMessage("hashName", "msgs", "validate.required");
			result = false;
		}
		
		if ("F".equals(viewForm.getHashFTFlag())) {
			if (StringUtils.isBlank(viewForm.getHashFregrExp())) {
				setComponentErrorMessage("hashFregrExp", "msgs", "validate.required");
				result = false;
			}
			
		} else if ("T".equals(viewForm.getHashFTFlag())) {
			if (StringUtils.isBlank(viewForm.getHashOwner())) {
				setComponentErrorMessage("hashOwner", "msgs", "validate.required");
				result = false;
			}
			
		}
		
		return result;
	}
	
	private boolean validateSubmitJob() {
		boolean result = true;
		if (StringUtils.isBlank(viewForm.getSubmitSubJobName())) {
			setComponentErrorMessage("submitSubJobName", "msgs", "validate.required");
			result = false;
		} else {
			List<RdJobInfo> jobs = registerService.selectJobInfos("where JOBNAME = '" + viewForm.getSubmitSubJobName() + "'");
			if (jobs.isEmpty()) {
				setComponentErrorMessage("submitSubJobName", "msgs", "validate.not.exist");
				result = false;
			}
		}
		
		return result;
	}
	
	public boolean getDisplaySrcDeleteBtn() {
		for (Boolean b : viewForm.getSrcSelectCkbox()) {
			if (b) {
				return true;
			}
		}
		return false;
	}
	
	public boolean getDisplayTgtDeleteBtn() {
		for (Boolean b : viewForm.getTgtSelectCkbox()) {
			if (b) {
				return true;
			}
		}
		return false;
	}
	
	public boolean getDisplayHashDeleteBtn() {
		for (Boolean b : viewForm.getHashSelectCkbox()) {
			if (b) {
				return true;
			}
		}
		return false;
	}
	
	public boolean getDisplaySubmitDeleteBtn() {
		for (Boolean b : viewForm.getSubmitSelectCkbox()) {
			if (b) {
				return true;
			}
		}
		return false;
	}
	
	public void doDeleteSrcSelectAction() {
		List<String> toDelete = new ArrayList<>();
		List<String> logs = new ArrayList<>();
		String num = viewForm.getJobInfo().getNum();
		
		for (int i = 0; i < viewForm.getSrcSelectCkbox().size(); i++) {
			if (viewForm.getSrcSelectCkbox().get(i)) {
				RdJobSrcInfo info = viewForm.getJobSrcInfos().get(i);
				toDelete.add(info.getRancode());
				
				String logContent = String.format("Delete JobSrcInfo[NUM=%s][JOBNAME=%s][NAME=%s][FTFLAG=%s][OWNER=%s][RANCODE=%s][CTL_FILE=%s][FOLDER=%s][CONNAME=%s][FREGR_EXP=%s][TWS_ACTION=%s][PRIORITY=%s]", 
						info.getNum(), info.getJobname(), info.getName(), info.getFtflag(),
						info.getOwner(), info.getRancode(), info.getCtlFile(), info.getFolder(),
						info.getConname(), info.getFregrExp(), info.getTwsAction(), info.getPriority());
				logs.add(logContent);
			}
		}
		
		try {
			registerService.deleteJobSrcInfosByPk(num, toDelete);
			// 工作日誌
			for (String logContent : logs) {
				saveWorkLog("JobSrcInfo", WorkLogAction.Delete, logContent);
			}
			
			selectJobSrcInfo(num);
			clearSrcFields();
			setGlobalMessageFormat("msgs", "info.delete.success");
			
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
			setGlobalErrorMessageFormat("msgs", "error.delete.fail");
		}
	}
	
	public void doDeleteTgtSelectAction() {
		List<String> toDelete = new ArrayList<>();
		List<String> logs = new ArrayList<>();
		String num = viewForm.getJobInfo().getNum();
		
		for (int i = 0; i < viewForm.getTgtSelectCkbox().size(); i++) {
			if (viewForm.getTgtSelectCkbox().get(i)) {
				RdJobTgtInfo info = viewForm.getJobTgtInfos().get(i);
				toDelete.add(info.getRancode());
				
				String logContent = String.format("Delete JobTgtInfo[NUM=%s][JOBNAME=%s][NAME=%s][FTFLAG=%s][OWNER=%s][RANCODE=%s][FOLDER=%s][CONNAME=%s][TGT_NODE=%s][TGT_DIR=%s][TGT_FILENAME=%s][SRC_FILETYPE=%s][TGT_FILETYPE=%s]", 
						info.getNum(), info.getJobname(), info.getName(), info.getFtflag(),
						info.getOwner(), info.getRancode(), info.getFolder(), info.getConname(),
						info.getTgtNode(), info.getTgtDir(), info.getTgtFilename(), info.getSrcFiletype(),
						info.getTgtFiletype());
				logs.add(logContent);
			}
		}
		
		try {
			registerService.deleteJobTgtInfosByPk(num, toDelete);
			// 工作日誌
			for (String logContent : logs) {
				saveWorkLog("JobTgtInfo", WorkLogAction.Delete, logContent);
			}
			
			selectJobTgtInfo(num);
			clearTgtFields();
			setGlobalMessageFormat("msgs", "info.delete.success");
			
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
			setGlobalErrorMessageFormat("msgs", "error.delete.fail");
		}
	}
	
	public void doDeleteHashSelectAction() {
		List<String> toDelete = new ArrayList<>();
		List<String> logs = new ArrayList<>();
		String num = viewForm.getJobInfo().getNum();
		
		for (int i = 0; i < viewForm.getHashSelectCkbox().size(); i++) {
			if (viewForm.getHashSelectCkbox().get(i)) {
				RdJobHashInfo info = viewForm.getJobHashInfos().get(i);
				toDelete.add(info.getRancode());
				
				String logContent = String.format("Delete JobHashInfo[NUM=%s][JOBNAME=%s][NAME=%s][FTFLAG=%s][OWNER=%s][RANCODE=%s][CONNAME=%s][FREGR_EXP=%s]", 
						info.getNum(), info.getJobname(), info.getName(), info.getFtflag(),
						info.getOwner(), info.getRancode(), info.getConname(), info.getFregrExp());
				logs.add(logContent);
			}
		}
		
		try {
			registerService.deleteJobHashInfosByPk(num, toDelete);
			// 工作日誌
			for (String logContent : logs) {
				saveWorkLog("JobHashInfo", WorkLogAction.Delete, logContent);
			}
			
			selectJobHashInfo(num);
			clearHashFields();
			setGlobalMessageFormat("msgs", "info.delete.success");
			
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
			setGlobalErrorMessageFormat("msgs", "error.delete.fail");
		}
	}
	
	public void doDeleteSubmitSelectAction() {
		List<RdSubmitJob> toDelete = new ArrayList<>();
		List<String> logs = new ArrayList<>();
		String num = viewForm.getJobInfo().getNum();
		
		for (int i = 0; i < viewForm.getHashSelectCkbox().size(); i++) {
			if (viewForm.getSubmitSelectCkbox().get(i)) {
				RdSubmitJob job = viewForm.getSubmitJobs().get(i);
				toDelete.add(job);
				
				String logContent = String.format("Delete SubmitJob[NUM=%s][MAIN_JSNAME=%s][MAIN_JOBNAME=%s][SUB_JOBNAME=%s]", 
						job.getNum(), job.getMainJsname(), job.getMainJobname(),job.getSubJobname());
				logs.add(logContent);
			}
		}
		
		try {
			registerService.deleteSubmitJobs(toDelete);
			// 工作日誌
			for (String logContent : logs) {
				saveWorkLog("SubmitJob", WorkLogAction.Delete, logContent);
			}
			
			selectSubmitJobInfo(num);
			clearSubmitFields();
			setGlobalMessageFormat("msgs", "info.delete.success");
			
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
			setGlobalErrorMessageFormat("msgs", "error.delete.fail");
		}
	}
	
	public void doSrcRowSelectAction(SelectEvent event) {
		RdJobSrcInfo info = (RdJobSrcInfo) event.getObject();
		viewForm.setSelectedJobSrcInfo(info);
		viewForm.setCurrentSrcRanCode(Integer.valueOf(info.getRancode()));
		viewForm.setSrcName(info.getName());
		viewForm.setSrcFTFlag(info.getFtflag());
		viewForm.setSrcOwner(info.getOwner());
		viewForm.setSrcCtlFile(info.getCtlFile());
		viewForm.setSrcFolder(info.getFolder());
		viewForm.setSrcConname(info.getConname());
		viewForm.setSrcFregrExp(info.getFregrExp());
		viewForm.setSrcTwsAction(info.getTwsAction());
		viewForm.setSrcPriority(info.getPriority());
	}
	
	public void doTgtRowSelectAction(SelectEvent event) {
		RdJobTgtInfo info = (RdJobTgtInfo) event.getObject();
		viewForm.setSelectedJobTgtInfo(info);
		viewForm.setCurrentTgtRanCode(Integer.valueOf(info.getRancode()));
		viewForm.setTgtName(info.getName());
		viewForm.setTgtFTFlag(info.getFtflag());
		viewForm.setTgtOwner(info.getOwner());
		viewForm.setTgtFolder(info.getFolder());
		viewForm.setTgtConname(info.getConname());
		viewForm.setTgtNode(info.getTgtNode());
		viewForm.setTgtDir(info.getTgtDir());
		viewForm.setTgtFilename(info.getTgtFilename());
		viewForm.setTgtSrcFileType(info.getSrcFiletype());
		viewForm.setTgtFileType(info.getTgtFiletype());
	}
	
	public void doHashRowSelectAction(SelectEvent event) {
		RdJobHashInfo info = (RdJobHashInfo) event.getObject();
		viewForm.setSelectedJobHashInfo(info);
		viewForm.setCurrentHashRanCode(Integer.valueOf(info.getRancode()));
		viewForm.setHashName(info.getName());
		viewForm.setHashFTFlag(info.getFtflag());
		viewForm.setHashOwner(info.getOwner());
		viewForm.setHashConname(info.getConname());
		viewForm.setHashFregrExp(info.getFregrExp());
	}
	
	public void doSubmitRowSelectAction(SelectEvent event) {
		RdSubmitJob job = (RdSubmitJob) event.getObject();
		viewForm.setSubmitSubJobName(job.getSubJobname());
		viewForm.setSelectedRdSubmitJob(job);
	}
	
	public void doUpdateSrcAction() {
		RdJobSrcInfo src = viewForm.getSelectedJobSrcInfo();
		RdJobSrcInfo info = new RdJobSrcInfo();
		if (validateJobSrcInfo()) {
			BeanUtils.copyProperties(src, info);
			
			info.setName(viewForm.getSrcName());
			info.setFtflag(viewForm.getSrcFTFlag());
			info.setOwner(viewForm.getSrcOwner());
			info.setCtlFile(viewForm.getSrcCtlFile());
			info.setFolder(viewForm.getSrcFolder());
			info.setConname(viewForm.getSrcConname());
			info.setFregrExp(viewForm.getSrcFregrExp());
			info.setTwsAction(viewForm.getSrcTwsAction());
			info.setPriority(viewForm.getSrcPriority());
			
			try {
				
				registerService.updateJobSrcInfo(info);
				
				// 工作日誌
				String logContent = String.format("Update JobSrcInfo[NUM:%s][RANCODE:%s][JOBNAME:%s][NAME:%s|%s][FTFLAG:%s|%s][OWNER:%s|%s][CTL_FILE:%s|%s][FOLDER:%s|%s][CONNAME:%s|%s][FREGR_EXP:%s|%s[TWS_ACTION:%s|%s][PRIORITY:%s|%s]", 
						src.getNum(), src.getRancode(), src.getJobname(),
						src.getName(), info.getName(),
						src.getFtflag(), info.getFtflag(),
						src.getOwner(), info.getOwner(),
						src.getCtlFile(), info.getCtlFile(),
						src.getFolder(), info.getFolder(),
						src.getConname(), info.getConname(),
						src.getFregrExp(), info.getFregrExp(),
						src.getTwsAction(), info.getTwsAction(),
						src.getPriority(), info.getPriority());
				saveWorkLog("JobSrcInfo", WorkLogAction.Update, logContent);
				
				setGlobalMessageFormat("msgs", "info.update.success");
				selectJobSrcInfo(src.getNum());
				
				PrimeFaces.current().executeScript("PF('newSrcDialog').hide()");
				
			} catch (Exception e) {
				_logger.error(e.getMessage(), e);
				setGlobalErrorMessageFormat("error.update.fail", e.getMessage());
			}
		}
	}
	
	public void doUpdateTgtAction() {
		RdJobTgtInfo tgt = viewForm.getSelectedJobTgtInfo();
		RdJobTgtInfo info = new RdJobTgtInfo();
		if (validateJobTgtInfo()) {
			BeanUtils.copyProperties(tgt, info);
			
			info.setName(viewForm.getTgtName());
			info.setFtflag(viewForm.getTgtFTFlag());
			info.setOwner(viewForm.getTgtOwner());
			info.setFolder(viewForm.getTgtFolder());
			info.setConname(viewForm.getTgtConname());
			info.setTgtNode(viewForm.getTgtNode());
			info.setTgtDir(viewForm.getTgtDir());
			info.setTgtFilename(viewForm.getTgtFilename());
			info.setSrcFiletype(viewForm.getTgtSrcFileType());
			info.setTgtFiletype(viewForm.getTgtFileType());
			
			try {
				
				registerService.updateJobTgtInfo(info);
				
				// 工作日誌
				String logContent = String.format("Update JobTgtInfo[NUM:%s][RANCODE:%s][JOBNAME:%s][NAME:%s|%s][FTFLAG:%s|%s][OWNER:%s|%s][FOLDER:%s|%s][CONNAME:%s|%s][TGT_NODE:%s|%s[TGT_DIR:%s|%s][TGT_FILENAME:%s|%s][SRC_FILETYPE:%s|%s][TGT_FILETYPE:%s|%s]", 
						tgt.getNum(), tgt.getRancode(), tgt.getJobname(),
						tgt.getName(), info.getName(),
						tgt.getFtflag(), info.getFtflag(),
						tgt.getOwner(), info.getOwner(),
						tgt.getFolder(), info.getFolder(),
						tgt.getConname(), info.getConname(),
						tgt.getTgtNode(), info.getTgtNode(),
						tgt.getTgtDir(), info.getTgtDir(),
						tgt.getTgtFilename(), info.getTgtFilename(),
						tgt.getSrcFiletype(), info.getSrcFiletype(),
						tgt.getTgtFiletype(), info.getTgtFiletype());
				saveWorkLog("JobTgtInfo", WorkLogAction.Update, logContent);
				
				setGlobalMessageFormat("msgs", "info.update.success");
				selectJobTgtInfo(tgt.getNum());
				
				PrimeFaces.current().executeScript("PF('newTgtDialog').hide()");
				
			} catch (Exception e) {
				_logger.error(e.getMessage(), e);
				setGlobalErrorMessageFormat("error.update.fail", e.getMessage());
			}
		}
	}
	
	public void doUpdateHashAction() {
		RdJobHashInfo hash = viewForm.getSelectedJobHashInfo();
		RdJobHashInfo info = new RdJobHashInfo();
		if (validateJobHashInfo()) {
			BeanUtils.copyProperties(hash, info);
			
			info.setName(viewForm.getHashName());
			info.setFtflag(viewForm.getHashFTFlag());
			info.setOwner(viewForm.getHashOwner());
			info.setConname(viewForm.getTgtConname());
			info.setFregrExp(viewForm.getHashFregrExp());
			
			try {
				
				registerService.updateJobHashInfo(info);
				
				// 工作日誌
				String logContent = String.format("Update JobHashInfo[NUM:%s][RANCODE:%s][JOBNAME:%s][NAME:%s|%s][FTFLAG:%s|%s][OWNER:%s|%s][CONNAME:%s|%s][FREGR_EXP:%s|%s]", 
						hash.getNum(), hash.getRancode(), hash.getJobname(),
						hash.getName(), info.getName(),
						hash.getFtflag(), info.getFtflag(),
						hash.getOwner(), info.getOwner(),
						hash.getConname(), info.getConname(),
						hash.getFregrExp(), info.getFregrExp());
				saveWorkLog("JobHashInfo", WorkLogAction.Update, logContent);
				
				setGlobalMessageFormat("msgs", "info.update.success");
				selectJobHashInfo(hash.getNum());
				
				PrimeFaces.current().executeScript("PF('newHashDialog').hide()");
				
			} catch (Exception e) {
				_logger.error(e.getMessage(), e);
				setGlobalErrorMessageFormat("error.update.fail", e.getMessage());
			}
		}
	}
	
	public void doUpdateSubmitAction() {
		RdSubmitJob src = viewForm.getSelectedRdSubmitJob();
		RdSubmitJob job = new RdSubmitJob();
		if (validateSubmitJob()) {
			BeanUtils.copyProperties(src, job);
			
			job.setSubJobname(viewForm.getSubmitSubJobName());
			
			try {
				
				registerService.updateSubmitJob(job);
				
				// 工作日誌
				String logContent = String.format("Update SubmitJob[NUM:%s][MAIN_JSNAME:%s][MAIN_JOBNAME:%s][SUB_JOBNAME:%s|%s]", 
						job.getNum(), job.getMainJsname(), job.getMainJobname(), src.getSubJobname(), job.getSubJobname());
				saveWorkLog("SubmitJob", WorkLogAction.Update, logContent);
				
				setGlobalMessageFormat("msgs", "info.update.success");
				selectSubmitJobInfo(job.getNum());
				
				PrimeFaces.current().executeScript("PF('newSubmitDialog').hide()");
				
			} catch (Exception e) {
				_logger.error(e.getMessage(), e);
				setGlobalErrorMessageFormat("error.update.fail", e.getMessage());
			}
		}
	}
}
