package tw.com.taipeifubon.jmrs.backing.sys;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.enterprise.context.SessionScoped;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.model.SelectItem;
import javax.inject.Named;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.annotation.Autowired;

import tw.com.hjct.jmrs.dao.bean.ConfigValue;
import tw.com.hjct.jmrs.dao.bean.ConfigValueKey;
import tw.com.taipeifubon.jmrs.BackingBeanBase;
import tw.com.taipeifubon.jmrs.Constants.WorkLogAction;
import tw.com.taipeifubon.jmrs.service.SystemService;
import tw.com.taipeifubon.jmrs.vo.ConfigValueVo;
import tw.com.taipeifubon.jmrs.vo.ConfigVo;

/**
 * <p>Title: tw.com.taipeifubon.jmrs.backing.sys.SYS101BackingBean</p>
 * <p>Description: Configure</p>
 * <p>Copyright: Copyright HJCT. 2020. All Rights Reserved.</p>
 * <p>Company: HJCT</p>
 * @author HJCT
 * @version 1.0
 */
@SuppressWarnings("serial")
@Named
@SessionScoped
public class SYS101BackingBean extends BackingBeanBase<SYS101ViewForm> {

	@Autowired
	private SystemService systemService;
	
	@Override
	protected void init() {
		List<SelectItem> typeItems = new ArrayList<>();
		Map<String, ConfigVo> allConfigs = systemService.selectAllConfigs();
		allConfigs.remove("ROLE_PERMISSION");
		viewForm.setConfigs(allConfigs);
		ConfigVo config = viewForm.getConfigs().get("CONFIG_TYPE");
		config.getConfigValueVos().forEach(valVo -> {
			typeItems.add(new SelectItem(valVo.getCode(), valVo.getConfigValue().getValue()));
		});
		viewForm.setTypeItems(typeItems);
	}

	/**
	 * 選擇類別
	 * @param event
	 */
	public void doSelectTypeAction(AjaxBehaviorEvent event) {
		clearConfigEditor();
		clearValueEditor();
	}
	
	/**
	 * 選擇組態列表
	 */
	public void doRowSelectAction(SelectEvent event) {
		ConfigVo vo = (ConfigVo) event.getObject();
		viewForm.setSelectConfig(vo);
		viewForm.setConfigCode(vo.getConfig().getKey());
		viewForm.setConfigType(vo.getConfig().getType());
		viewForm.setConfigDesc(vo.getConfig().getNote());
		clearValueEditor();
	}
	
	private void clearValueEditor() {
		viewForm.setSelectValue(null);
		viewForm.setValueCode(null);
		viewForm.setValue(null);
		viewForm.setState(null);
		viewForm.setDisableValueCode(false);
	}
	
	private void clearConfigEditor() {
		viewForm.setSelectConfig(null);
		viewForm.setConfigCode(null);
		viewForm.setConfigType(null);
		viewForm.setConfigDesc(null);
	}
	
	/**
	 * 取得目前選擇的類別組態
	 * @return
	 */
	public List<ConfigVo> getConfigs() {
		return viewForm.getConfigs().values()
				.stream()
				.filter(o -> o.getConfig().getType().equals(viewForm.getSelectType()))
				.sorted((o1, o2) -> o1.getConfig().getKey().compareTo(o2.getConfig().getKey()))
				.collect(Collectors.toList());
	}
	
	/**
	 * 取得目前選擇的類別組態值
	 * @return
	 */
	public List<ConfigValueVo> getConfigValues() {
		if (viewForm.getSelectConfig() != null) {
			return viewForm.getSelectConfig().getConfigValueVos();
		}
		return null;
	}
	
	/**
	 * 更新組態列表
	 */
	public void doUpdateConfigAction() {
		ConfigVo config = viewForm.getSelectConfig();
		String logContent = String.format("Update Configure[TYPE:%s|%s][NOTE:%s|%s]", 
				config.getConfig().getType(), viewForm.getConfigType(),
				config.getConfig().getNote(), viewForm.getConfigDesc());
		
		config.getConfig().setNote(viewForm.getConfigDesc());
		config.getConfig().setType(viewForm.getConfigType());
		try {
			String oldType = viewForm.getSelectType();
			
			systemService.updateSelective(config.getConfig());
			
			// 工作日誌
			saveWorkLog("Configure", WorkLogAction.Update, logContent);
			viewForm.setSelectType(oldType);
			setGlobalMessageFormat("msgs", "info.update.success");
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
			setGlobalErrorMessageFormat("error.update.fail", e.getMessage());
		}
	}
	
	/**
	 * 取消
	 */
	public void doCancelConfigEdit() {
		clearConfigEditor();
		clearValueEditor();
	}
	
	/**
	 * 選擇設定值
	 * @param event
	 */
	public void doConfigValSelectAction(SelectEvent event) {
		ConfigValueVo vo = (ConfigValueVo) event.getObject();
		viewForm.setSelectValue(vo);
		viewForm.setValueCode(vo.getCode());
		viewForm.setValue(vo.getConfigValue().getValue());
		viewForm.setState(vo.getConfigValue().getState());
		viewForm.setDisableValueCode(true);
		viewForm.setDisableDeleteBtn("T".equals(vo.getConfigValue().getReadOnly()));
	}
	
	/**
	 * 設定值取消
	 */
	public void doCancelValueEdit() {
		clearValueEditor();
	}
	
	/**
	 * 新增設定值
	 */
	public void doAddValueAction() {
		
		if (validateConfigValue()) {
			
			try {
				// 是否已存在
				ConfigValueKey key = new ConfigValueKey();
				key.setConfigId(viewForm.getSelectConfig().getConfigId());
				key.setCode(viewForm.getValueCode());
				ConfigValue exist = systemService.findConfigValue(key);
				if (exist != null) {
					// 設定碼已存在
					setGlobalErrorMessageFormat("msgs", "error.config.code.exist");
					return;
				}
				
				ConfigValue configValue = new ConfigValue();
				configValue.setCode(viewForm.getValueCode());
				configValue.setConfigId(viewForm.getSelectConfig().getConfigId());
				configValue.setValue(viewForm.getValue());
				configValue.setState(viewForm.getState());
				configValue.setReadOnly("F");
				
				systemService.insertConfigValue(configValue);
				
				// 工作日誌
				String logContent = String.format("Add Configure[KEY=%s][CODE=%s]", 
						viewForm.getSelectConfig().getConfig().getKey(),
						viewForm.getValueCode());
				saveWorkLog("Configure", WorkLogAction.Add, logContent);
				
				clearValueEditor();
				
				ConfigValueVo vo = new ConfigValueVo();
				vo.setConfigId(configValue.getConfigId());
				vo.setCode(configValue.getCode());
				vo.setConfigValue(configValue);
				viewForm.setSelectValue(null);
				viewForm.getSelectConfig().getConfigValueVos().add(vo);
				
				setGlobalMessageFormat("msgs", "info.create.success");
				
				if ("CONFIG_TYPE".equals(viewForm.getSelectConfig().getConfig().getKey())) {
					String oldType = viewForm.getSelectType();
					init();
					viewForm.setSelectType(oldType);
				}
				
			} catch (Exception e) {
				_logger.error(e.getMessage(), e);
				setGlobalErrorMessageFormat("error.create.fail", e.getMessage());
			}
		}
		
	}
	
	private boolean validateConfigValue() {
		boolean result = true;
		if (StringUtils.isBlank(viewForm.getValueCode())) {
			setComponentErrorMessage("valueCode", "msgs", "validate.required");
			result = false;
		}
		
		if (StringUtils.isBlank(viewForm.getValue())) {
			setComponentErrorMessage("valueFld", "msgs", "validate.required");
			result = false;
		}
		return result;
	}
	
	/**
	 * 更新設定值
	 */
	public void doUpdateValueAction() {
		if (validateConfigValue()) {
			ConfigValue selectValue = viewForm.getSelectValue().getConfigValue();
			ConfigValue configValue = new ConfigValue();
			try {
				BeanUtils.copyProperties(configValue, selectValue);
				String logContent = String.format("Update Configure[CODE=%s|%s][VALUE=%s|%s][STATE=%s|%s]", 
						selectValue.getCode(), viewForm.getValueCode(),
						selectValue.getValue(), viewForm.getValue(),
						selectValue.getState(), viewForm.getState());
				configValue.setCode(viewForm.getValueCode());
				configValue.setValue(viewForm.getValue());
				configValue.setState(viewForm.getState());
				
				systemService.updateConfigValue(configValue);
				
				// 工作日誌
				saveWorkLog("Configure", WorkLogAction.Update, logContent);
				
				selectValue.setCode(viewForm.getValueCode());
				selectValue.setValue(viewForm.getValue());
				selectValue.setState(viewForm.getState());
				clearValueEditor();
				viewForm.setSelectValue(null);
				setGlobalMessageFormat("msgs", "info.update.success");
				// [180906_Eric:更新CONFIG_TYPE 組態值時須Reset]
				if ("CONFIG_TYPE".equals(viewForm.getSelectConfig().getConfig().getKey())) {
					String oldType = viewForm.getSelectType();
					init();
					viewForm.setSelectType(oldType);
				}
			} catch (Exception e) {
				_logger.error(e.getMessage(), e);
				setGlobalErrorMessageFormat("msgs", "error.update.fail");
			}
		}
	}
	
	/**
	 * 刪除
	 */
	public void doDeleteValueEdit() {
		ConfigValue configValue = viewForm.getSelectValue().getConfigValue();
		
		try {
			ConfigValueKey pk = new ConfigValueKey();
			pk.setConfigId(configValue.getConfigId());
			pk.setCode(configValue.getCode());
			systemService.deleteConfigValue(pk);
			
			// 工作日誌
			String logContent = String.format("Delete Configure[CODE=%s][VALUE=%s][STATE=%s]", 
					configValue.getCode(), configValue.getValue(), configValue.getState());
			saveWorkLog("Configure", WorkLogAction.Delete, logContent);
			
			viewForm.getSelectConfig().getConfigValueVos().remove(viewForm.getSelectValue());
			clearValueEditor();
			viewForm.setSelectValue(null);
			setGlobalMessageFormat("msgs", "info.delete.success");
			if ("CONFIG_TYPE".equals(viewForm.getSelectConfig().getConfig().getKey())) {
				String oldType = viewForm.getSelectType();
				init();
				viewForm.setSelectType(oldType);
			}
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
			setGlobalErrorMessageFormat("msgs", "error.delete.fail");
		}
	}
}
