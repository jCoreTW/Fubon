package tw.com.taipeifubon.jmrs.backing.home;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

import org.springframework.beans.factory.annotation.Autowired;

import tw.com.taipeifubon.jmrs.BackingBeanBase;
import tw.com.taipeifubon.jmrs.service.OdsSystemService;

@Named
@RequestScoped
public class HomeBackingBean extends BackingBeanBase<HomeViewForm> {

	@Autowired
	private OdsSystemService service;
	
	public void doSomething() {
		System.out.println("######## hello world");
		service.test();
	}
	
	public void goSomewhere() {
		redirect("/WEB-INF/pages/test.xhtml");
	}

	@Override
	protected void init() {
		System.out.println("######## init");
	}
	
}
