package tw.com.taipeifubon.jmrs.backing;

/**
 * <p>Title: tw.com.taipeifubon.jmrs.backing.NavigationListener</p>
 * <p>Description: Menu導覽監聽器管理</p>
 * <p>Copyright: Copyright HJCT. 2014. All Rights Reserved.</p>
 * <p>Company: HJCT</p>
 * @author HJCT
 * @version 1.0
 */
public interface NavigationListener {

	public void onNavigation();
}
