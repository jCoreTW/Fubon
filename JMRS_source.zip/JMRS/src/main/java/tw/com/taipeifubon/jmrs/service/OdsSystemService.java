package tw.com.taipeifubon.jmrs.service;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tw.com.hjct.jmrs.dao.bean.RdJobSrcInfo;
import tw.com.hjct.jmrs.dao.bean.RdJobSrcInfoExample;
import tw.com.hjct.jmrs.dao.mapper.RdJobSrcInfoMapper;

@Service
public class OdsSystemService {

	@Autowired
	private SqlSessionTemplate sqlTemplate;
	
	public void test() {
		RdJobSrcInfoExample example = new RdJobSrcInfoExample();
		RdJobSrcInfoMapper mapper = sqlTemplate.getMapper(RdJobSrcInfoMapper.class);
		List<RdJobSrcInfo> infos = mapper.selectByExample(example);
		for (RdJobSrcInfo info : infos) {
			System.out.println("######## " + info.getJobname());
		}
	}
	
}
