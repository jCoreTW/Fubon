package tw.com.taipeifubon.jmrs.service;

import java.util.List;

import javax.transaction.Transactional;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tw.com.hjct.jmrs.dao.bean.RdJobHashInfo;
import tw.com.hjct.jmrs.dao.bean.RdJobHashInfoExample;
import tw.com.hjct.jmrs.dao.bean.RdJobHashInfoKey;
import tw.com.hjct.jmrs.dao.bean.RdJobInfo;
import tw.com.hjct.jmrs.dao.bean.RdJobInfoExample;
import tw.com.hjct.jmrs.dao.bean.RdJobSrcInfo;
import tw.com.hjct.jmrs.dao.bean.RdJobSrcInfoExample;
import tw.com.hjct.jmrs.dao.bean.RdJobSrcInfoKey;
import tw.com.hjct.jmrs.dao.bean.RdJobTgtInfo;
import tw.com.hjct.jmrs.dao.bean.RdJobTgtInfoExample;
import tw.com.hjct.jmrs.dao.bean.RdJobTgtInfoKey;
import tw.com.hjct.jmrs.dao.bean.RdOsHousekeeping;
import tw.com.hjct.jmrs.dao.bean.RdOsHousekeepingExample;
import tw.com.hjct.jmrs.dao.bean.RdOsHousekeepingKey;
import tw.com.hjct.jmrs.dao.bean.RdSubmitJob;
import tw.com.hjct.jmrs.dao.bean.RdSubmitJobExample;
import tw.com.hjct.jmrs.dao.bean.SidbHousekeeping;
import tw.com.hjct.jmrs.dao.bean.SidbHousekeepingExample;
import tw.com.hjct.jmrs.dao.bean.SidbHousekeepingKey;
import tw.com.hjct.jmrs.dao.mapper.CustomMapper;
import tw.com.hjct.jmrs.dao.mapper.RdJobHashInfoMapper;
import tw.com.hjct.jmrs.dao.mapper.RdJobInfoMapper;
import tw.com.hjct.jmrs.dao.mapper.RdJobSrcInfoMapper;
import tw.com.hjct.jmrs.dao.mapper.RdJobTgtInfoMapper;
import tw.com.hjct.jmrs.dao.mapper.RdOsHousekeepingMapper;
import tw.com.hjct.jmrs.dao.mapper.RdSubmitJobMapper;
import tw.com.hjct.jmrs.dao.mapper.SidbHousekeepingMapper;

@Service
public class RegisterService {

	@Autowired
	private SqlSessionTemplate sqlTemplate;
	
	/**
	 * 查詢JobInfo
	 * @param whereClause
	 * @return
	 */
	public List<RdJobInfo> selectJobInfos(String whereClause) {
		CustomMapper mapper = sqlTemplate.getMapper(CustomMapper.class);
		return mapper.selectJobInfo(whereClause);
	}
	
	/**
	 * 查詢OS Housekeeping
	 * @param whereClause
	 * @return
	 */
	public List<RdOsHousekeeping> selectOsHousekeepings(String whereClause) {
		CustomMapper mapper = sqlTemplate.getMapper(CustomMapper.class);
		return mapper.selectOsHousekeeping(whereClause);
	}
	
	/**
	 * 查詢SIDB Housekeeping
	 * @param whereClause
	 * @return
	 */
	public List<SidbHousekeeping> selectSidbHousekeepings(String whereClause) {
		CustomMapper mapper = sqlTemplate.getMapper(CustomMapper.class);
		return mapper.selectSidbHousekeeping(whereClause);
	}
	
	/**
	 * 查詢JobInfo
	 * @param num
	 * @return
	 */
	public RdJobInfo findJobInfoByNum(String num) {
		RdJobInfoMapper mapper = sqlTemplate.getMapper(RdJobInfoMapper.class);
		return mapper.selectByPrimaryKey(num);
	}
	
	/**
	 * 查詢JobInfo
	 * @param jobName
	 * @param jobSys
	 * @return
	 */
	public RdJobInfo findJobInfoByJobNameAndJobSys(String jobName, String jobSys) {
		RdJobInfoMapper mapper = sqlTemplate.getMapper(RdJobInfoMapper.class);
		RdJobInfoExample example = new RdJobInfoExample();
		RdJobInfoExample.Criteria criteria = example.createCriteria();
		
		criteria.andJobnameEqualTo(jobName);
		criteria.andJobsysEqualTo(jobSys);
		
		List<RdJobInfo> result = mapper.selectByExample(example);
		if (result.isEmpty()) {
			return null;
		}
		
		return result.get(0);
	}
	
	/**
	 * insert jobinfo
	 * @param info
	 */
	public void insertJobInfo(RdJobInfo info) {
		RdJobInfoMapper mapper = sqlTemplate.getMapper(RdJobInfoMapper.class);
		mapper.insert(info);
	}
	
	/**
	 * delete job info
	 * @param num
	 */
	@Transactional
	public void deleteJobInfoByNum(String num) {
		deleteJobSrcInfoByNum(num);
		deleteJobTgtInfoByNum(num);
		deleteJobHashInfoByNum(num);
		deleteSubmitJobByNum(num);
		
		RdJobInfoMapper mapper = sqlTemplate.getMapper(RdJobInfoMapper.class);
		mapper.deleteByPrimaryKey(num);
	}
	
	/**
	 * count JobSrcInfo for JobInfo
	 * @param num
	 */
	public long countJobSrcInfoByNum(String num) {
		RdJobSrcInfoMapper mapper = sqlTemplate.getMapper(RdJobSrcInfoMapper.class);
		RdJobSrcInfoExample example = new RdJobSrcInfoExample();
		RdJobSrcInfoExample.Criteria criteria = example.createCriteria();
		
		criteria.andNumEqualTo(num);
		
		return mapper.countByExample(example);
	}
	
	/**
	 * count JobTgtInfo for JobInfo
	 * @param num
	 */
	public long countJobTgtInfoByNum(String num) {
		RdJobTgtInfoMapper mapper = sqlTemplate.getMapper(RdJobTgtInfoMapper.class);
		RdJobTgtInfoExample example = new RdJobTgtInfoExample();
		RdJobTgtInfoExample.Criteria criteria = example.createCriteria();
		
		criteria.andNumEqualTo(num);
		
		return mapper.countByExample(example);
	}
	
	/**
	 * count JobHashInfo for JobInfo
	 * @param num
	 */
	public long countJobHashInfoByNum(String num) {
		RdJobHashInfoMapper mapper = sqlTemplate.getMapper(RdJobHashInfoMapper.class);
		RdJobHashInfoExample example = new RdJobHashInfoExample();
		RdJobHashInfoExample.Criteria criteria = example.createCriteria();
		
		criteria.andNumEqualTo(num);
		
		return mapper.countByExample(example);
	}
	
	/**
	 * count SubmitJob for JobInfo
	 * @param num
	 */
	public long countSubmitJobByNum(String num) {
		RdSubmitJobMapper mapper = sqlTemplate.getMapper(RdSubmitJobMapper.class);
		RdSubmitJobExample example = new RdSubmitJobExample();
		RdSubmitJobExample.Criteria criteria = example.createCriteria();
		
		criteria.andNumEqualTo(num);
		
		return mapper.countByExample(example);
	}
	
	/**
	 * delete JobSrcInfo for JobInfo
	 * @param num
	 */
	public void deleteJobSrcInfoByNum(String num) {
		RdJobSrcInfoMapper mapper = sqlTemplate.getMapper(RdJobSrcInfoMapper.class);
		RdJobSrcInfoExample example = new RdJobSrcInfoExample();
		RdJobSrcInfoExample.Criteria criteria = example.createCriteria();
		
		criteria.andNumEqualTo(num);
		
		mapper.deleteByExample(example);
	}
	
	/**
	 * delete JobTgtInfo for JobInfo
	 * @param num
	 */
	public void deleteJobTgtInfoByNum(String num) {
		RdJobTgtInfoMapper mapper = sqlTemplate.getMapper(RdJobTgtInfoMapper.class);
		RdJobTgtInfoExample example = new RdJobTgtInfoExample();
		RdJobTgtInfoExample.Criteria criteria = example.createCriteria();
		
		criteria.andNumEqualTo(num);
		
		mapper.deleteByExample(example);
	}
	
	/**
	 * delete JobHashInfo for JobInfo
	 * @param num
	 */
	public void deleteJobHashInfoByNum(String num) {
		RdJobHashInfoMapper mapper = sqlTemplate.getMapper(RdJobHashInfoMapper.class);
		RdJobHashInfoExample example = new RdJobHashInfoExample();
		RdJobHashInfoExample.Criteria criteria = example.createCriteria();
		
		criteria.andNumEqualTo(num);
		
		mapper.deleteByExample(example);
	}
	
	/**
	 * delete SubmitJob for JobInfo
	 * @param num
	 */
	public void deleteSubmitJobByNum(String num) {
		RdSubmitJobMapper mapper = sqlTemplate.getMapper(RdSubmitJobMapper.class);
		RdSubmitJobExample example = new RdSubmitJobExample();
		RdSubmitJobExample.Criteria criteria = example.createCriteria();
		
		criteria.andNumEqualTo(num);
		
		mapper.deleteByExample(example);
	}
	
	@Transactional
	public void deleteJobInfosByNum(List<String> nums) {
		for (String num : nums) {
			deleteJobInfoByNum(num);
		}
	}
	
	public void updateJobInfo(RdJobInfo jobInfo) {
		RdJobInfoMapper mapper = sqlTemplate.getMapper(RdJobInfoMapper.class);
		mapper.updateByPrimaryKey(jobInfo);
	}
	
	/**
	 * select JobSrcInfo for JobInfo
	 * @param num
	 */
	public List<RdJobSrcInfo> selectJobSrcInfoByNum(String num) {
		RdJobSrcInfoMapper mapper = sqlTemplate.getMapper(RdJobSrcInfoMapper.class);
		RdJobSrcInfoExample example = new RdJobSrcInfoExample();
		RdJobSrcInfoExample.Criteria criteria = example.createCriteria();
		
		criteria.andNumEqualTo(num);
		
		example.setOrderByClause("RANCODE");
		return mapper.selectByExample(example);
	}
	
	/**
	 * select JobTgtInfo for JobInfo
	 * @param num
	 */
	public List<RdJobTgtInfo> selectJobTgtInfoByNum(String num) {
		RdJobTgtInfoMapper mapper = sqlTemplate.getMapper(RdJobTgtInfoMapper.class);
		RdJobTgtInfoExample example = new RdJobTgtInfoExample();
		RdJobTgtInfoExample.Criteria criteria = example.createCriteria();
		
		criteria.andNumEqualTo(num);
		
		return mapper.selectByExample(example);
	}
	
	/**
	 * select JobHashInfo for JobInfo
	 * @param num
	 */
	public List<RdJobHashInfo> selectJobHashInfoByNum(String num) {
		RdJobHashInfoMapper mapper = sqlTemplate.getMapper(RdJobHashInfoMapper.class);
		RdJobHashInfoExample example = new RdJobHashInfoExample();
		RdJobHashInfoExample.Criteria criteria = example.createCriteria();
		
		criteria.andNumEqualTo(num);
		
		return mapper.selectByExample(example);
	}
	
	/**
	 * select SubmitJob for JobInfo
	 * @param num
	 */
	public List<RdSubmitJob> selectSubmitJobByNum(String num) {
		RdSubmitJobMapper mapper = sqlTemplate.getMapper(RdSubmitJobMapper.class);
		RdSubmitJobExample example = new RdSubmitJobExample();
		RdSubmitJobExample.Criteria criteria = example.createCriteria();
		
		criteria.andNumEqualTo(num);
		
		return mapper.selectByExample(example);
	}
	
	/**
	 * Delete JobSrcInfo
	 * @param pk
	 */
	public void deleteJobSrcInfoByPk(RdJobSrcInfoKey pk) {
		RdJobSrcInfoMapper mapper = sqlTemplate.getMapper(RdJobSrcInfoMapper.class);
		mapper.deleteByPrimaryKey(pk);
	}
	
	/**
	 * Delete JobTgtInfo
	 * @param pk
	 */
	public void deleteJobTgtInfoByPk(RdJobTgtInfoKey pk) {
		RdJobTgtInfoMapper mapper = sqlTemplate.getMapper(RdJobTgtInfoMapper.class);
		mapper.deleteByPrimaryKey(pk);
	}
	
	/**
	 * Delete JobHashInfo
	 * @param pk
	 */
	public void deleteJobHashInfoByPk(RdJobHashInfoKey pk) {
		RdJobHashInfoMapper mapper = sqlTemplate.getMapper(RdJobHashInfoMapper.class);
		mapper.deleteByPrimaryKey(pk);
	}
	
	/**
	 * Delete SubmitJob
	 * @param pk
	 */
	public void deleteSubmitJob(RdSubmitJob job) {
		RdSubmitJobMapper mapper = sqlTemplate.getMapper(RdSubmitJobMapper.class);
		RdSubmitJobExample example = new RdSubmitJobExample();
		RdSubmitJobExample.Criteria criteria = example.createCriteria();
		criteria.andNumEqualTo(job.getNum());
		criteria.andMainJobnameEqualTo(job.getMainJobname());
		criteria.andMainJsnameEqualTo(job.getMainJsname());
		mapper.deleteByExample(example);
	}
	
	/**
	 * Insert JobSrcInfo
	 * @param info
	 */
	private static Object _src_lock = new Object();
	public RdJobSrcInfo insertJobSrcInfo(RdJobSrcInfo info) {
		synchronized (_src_lock) {
			CustomMapper custMapper = sqlTemplate.getMapper(CustomMapper.class);
			String maxRanCode = custMapper.selectJobSrcMaxRancode(info.getNum());
			if (maxRanCode == null) {
				maxRanCode = "0";
			}
			info.setRancode(Integer.toString(Integer.valueOf(maxRanCode) + 1));
			
			RdJobSrcInfoMapper mapper = sqlTemplate.getMapper(RdJobSrcInfoMapper.class);
			mapper.insert(info);
			return info;
		}
		
	}
	
	/**
	 * Insert JobSrcInfo
	 * @param info
	 */
	private static Object _tgt_lock = new Object();
	public RdJobTgtInfo insertJobTgtInfo(RdJobTgtInfo info) {
		synchronized (_tgt_lock) {
			CustomMapper custMapper = sqlTemplate.getMapper(CustomMapper.class);
			String maxRanCode = custMapper.selectJobTgtMaxRancode(info.getNum());
			if (maxRanCode == null) {
				maxRanCode = "0";
			}
			info.setRancode(Integer.toString(Integer.valueOf(maxRanCode) + 1));
			
			RdJobTgtInfoMapper mapper = sqlTemplate.getMapper(RdJobTgtInfoMapper.class);
			mapper.insert(info);
			return info;
		}
		
	}
	
	/**
	 * Insert JobHashInfo
	 * @param info
	 */
	private static Object _hash_lock = new Object();
	public RdJobHashInfo insertJobHashInfo(RdJobHashInfo info) {
		synchronized (_hash_lock) {
			CustomMapper custMapper = sqlTemplate.getMapper(CustomMapper.class);
			String maxRanCode = custMapper.selectJobHashMaxRancode(info.getNum());
			if (maxRanCode == null) {
				maxRanCode = "0";
			}
			info.setRancode(Integer.toString(Integer.valueOf(maxRanCode) + 1));
			
			RdJobHashInfoMapper mapper = sqlTemplate.getMapper(RdJobHashInfoMapper.class);
			mapper.insert(info);
			return info;
		}
		
	}
	
	/**
	 * insert SubmitJob
	 * @param job
	 */
	public void insertSubmitJob(RdSubmitJob job) {
		RdSubmitJobMapper mapper = sqlTemplate.getMapper(RdSubmitJobMapper.class);
		mapper.insert(job);
	}
	
	@Transactional
	public void deleteJobSrcInfosByPk(String num, List<String> ranCodes) {
		RdJobSrcInfoMapper mapper = sqlTemplate.getMapper(RdJobSrcInfoMapper.class);
		
		for (String ranCode : ranCodes) {
			RdJobSrcInfoKey pk = new RdJobSrcInfoKey();
			pk.setNum(num);
			pk.setRancode(ranCode);
			mapper.deleteByPrimaryKey(pk);
		}
	}
	
	@Transactional
	public void deleteJobTgtInfosByPk(String num, List<String> ranCodes) {
		RdJobTgtInfoMapper mapper = sqlTemplate.getMapper(RdJobTgtInfoMapper.class);
		
		for (String ranCode : ranCodes) {
			RdJobTgtInfoKey pk = new RdJobTgtInfoKey();
			pk.setNum(num);
			pk.setRancode(ranCode);
			mapper.deleteByPrimaryKey(pk);
		}
	}
	
	@Transactional
	public void deleteJobHashInfosByPk(String num, List<String> ranCodes) {
		RdJobHashInfoMapper mapper = sqlTemplate.getMapper(RdJobHashInfoMapper.class);
		
		for (String ranCode : ranCodes) {
			RdJobHashInfoKey pk = new RdJobHashInfoKey();
			pk.setNum(num);
			pk.setRancode(ranCode);
			mapper.deleteByPrimaryKey(pk);
		}
	}
	
	@Transactional
	public void deleteSubmitJobs(List<RdSubmitJob> jobs) {
		jobs.forEach(j -> deleteSubmitJob(j));
	}
	
	public void updateJobSrcInfo(RdJobSrcInfo info) {
		RdJobSrcInfoMapper mapper = sqlTemplate.getMapper(RdJobSrcInfoMapper.class);
		mapper.updateByPrimaryKey(info);
	}
	
	public void updateJobTgtInfo(RdJobTgtInfo info) {
		RdJobTgtInfoMapper mapper = sqlTemplate.getMapper(RdJobTgtInfoMapper.class);
		mapper.updateByPrimaryKey(info);
	}
	
	public void updateJobHashInfo(RdJobHashInfo info) {
		RdJobHashInfoMapper mapper = sqlTemplate.getMapper(RdJobHashInfoMapper.class);
		mapper.updateByPrimaryKey(info);
	}
	
	public void updateSubmitJob(RdSubmitJob job) {
		RdSubmitJobMapper mapper = sqlTemplate.getMapper(RdSubmitJobMapper.class);
		RdSubmitJobExample example = new RdSubmitJobExample();
		RdSubmitJobExample.Criteria criteria = example.createCriteria();
		criteria.andNumEqualTo(job.getNum());
		criteria.andMainJobnameEqualTo(job.getMainJobname());
		criteria.andMainJsnameEqualTo(job.getMainJsname());
		mapper.updateByExample(job, example);
	}
	
	public RdOsHousekeeping findOsHousekeepingByPk(RdOsHousekeepingKey pk) {
		RdOsHousekeepingMapper mapper = sqlTemplate.getMapper(RdOsHousekeepingMapper.class);
		return mapper.selectByPrimaryKey(pk);
	}
	
	public SidbHousekeeping findSidbHousekeepingByPk(SidbHousekeepingKey pk) {
		SidbHousekeepingMapper mapper = sqlTemplate.getMapper(SidbHousekeepingMapper.class);
		return mapper.selectByPrimaryKey(pk);
	}
	
	public void insertOsHousekeeping(RdOsHousekeeping housekeeping) {
		RdOsHousekeepingMapper mapper = sqlTemplate.getMapper(RdOsHousekeepingMapper.class);
		mapper.insert(housekeeping);
	}
	
	public void insertSidbHousekeeping(SidbHousekeeping housekeeping) {
		SidbHousekeepingMapper mapper = sqlTemplate.getMapper(SidbHousekeepingMapper.class);
		mapper.insert(housekeeping);
	}
	
	public void deleteOsHousekeepingByPk(RdOsHousekeepingKey pk) {
		RdOsHousekeepingMapper mapper = sqlTemplate.getMapper(RdOsHousekeepingMapper.class);
		mapper.deleteByPrimaryKey(pk);
	}
	
	public void deleteSidbHousekeepingByPk(SidbHousekeepingKey pk) {
		SidbHousekeepingMapper mapper = sqlTemplate.getMapper(SidbHousekeepingMapper.class);
		mapper.deleteByPrimaryKey(pk);
	}
	
	@Transactional
	public void deleteOsHousekeepings(List<RdOsHousekeeping> hks) {
		hks.forEach(h -> deleteOsHousekeepingByPk(h));
	}
	
	@Transactional
	public void deleteSidbHousekeepings(List<SidbHousekeeping> hks) {
		hks.forEach(h -> deleteSidbHousekeepingByPk(h));
	}
	
	public void updateOsHousekeepingByPk(RdOsHousekeeping housekeeping, RdOsHousekeepingKey pk) {
		RdOsHousekeepingMapper mapper = sqlTemplate.getMapper(RdOsHousekeepingMapper.class);
		RdOsHousekeepingExample example = new RdOsHousekeepingExample();
		RdOsHousekeepingExample.Criteria criteria = example.createCriteria();
		criteria.andActionEqualTo(pk.getAction());
		criteria.andFolderEqualTo(pk.getFolder());
		criteria.andRsFlagEqualTo(pk.getRsFlag());
		
		mapper.updateByExample(housekeeping, example);
	}
	
	public void updateSidbHousekeepingByPk(SidbHousekeeping housekeeping, SidbHousekeepingKey pk) {
		SidbHousekeepingMapper mapper = sqlTemplate.getMapper(SidbHousekeepingMapper.class);
		SidbHousekeepingExample example = new SidbHousekeepingExample();
		SidbHousekeepingExample.Criteria criteria = example.createCriteria();
		criteria.andOwnerEqualTo(pk.getOwner());
		criteria.andColumnNameEqualTo(pk.getColumnName());
		criteria.andTableNameEqualTo(pk.getTableName());
		
		mapper.updateByExample(housekeeping, example);
	}
	
	public RdOsHousekeeping findOsHouseKeepingByPrimaryKey(String folder, String action, String rsFlag) {
		RdOsHousekeepingKey pk = new RdOsHousekeepingKey();
		pk.setAction(action);
		pk.setFolder(folder);
		pk.setRsFlag(rsFlag);
		RdOsHousekeepingMapper mapper = sqlTemplate.getMapper(RdOsHousekeepingMapper.class);
		return mapper.selectByPrimaryKey(pk);
	}
	
	public SidbHousekeeping findSidbHousekeepingByPrimaryKey(String owner, String tableName, String columnName) {
		SidbHousekeepingKey pk = new SidbHousekeepingKey();
		pk.setColumnName(columnName);
		pk.setOwner(owner);
		pk.setTableName(tableName);
		SidbHousekeepingMapper mapper = sqlTemplate.getMapper(SidbHousekeepingMapper.class);
		return mapper.selectByPrimaryKey(pk);
	}
}
