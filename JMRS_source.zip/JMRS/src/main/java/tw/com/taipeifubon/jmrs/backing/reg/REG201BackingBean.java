package tw.com.taipeifubon.jmrs.backing.reg;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.SessionScoped;
import javax.faces.event.AjaxBehaviorEvent;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.primefaces.PrimeFaces;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;

import tw.com.hjct.jmrs.dao.bean.RdOsHousekeeping;
import tw.com.hjct.jmrs.dao.bean.RdOsHousekeepingKey;
import tw.com.taipeifubon.jmrs.BackingBeanBase;
import tw.com.taipeifubon.jmrs.Constants.WorkLogAction;
import tw.com.taipeifubon.jmrs.service.RegisterService;

/**
 * <p>Title: tw.com.taipeifubon.jmrs.backing.reg.REG201BackingBean</p>
 * <p>Description: OS Housekeeping</p>
 * <p>Copyright: Copyright HJCT. 2020. All Rights Reserved.</p>
 * <p>Company: HJCT</p>
 * @author HJCT
 * @version 1.0
 */
@SuppressWarnings("serial")
@Named
@SessionScoped
public class REG201BackingBean extends BackingBeanBase<REG201ViewForm> {

	@Autowired
	private RegisterService registerService;
	
	@Override
	protected void init() {
		doAddOptions();
	}

	/**
	 * Search
	 */
	public void doSearchAction() {
		StringBuffer condition = new StringBuffer();
		String logical = viewForm.getLogical();
		
		for (int i = 0; i < viewForm.getParameters().size(); i++) {
			if (StringUtils.isNotBlank(viewForm.getParameters().get(i))) {
				String value = "'" + viewForm.getValues().get(i) + "'";
				if (viewForm.getOpts().get(i).indexOf("like") > -1) {
					value = "'%" + viewForm.getValues().get(i) + "%'";
					
				} else if (viewForm.getOpts().get(i).indexOf("in") > -1) {
					value = StringUtils.join(value.split(","), "','");
					value = "(" + value + ")";
				}
				
				condition.append(String.format(" (%s %s %s) ", 
						viewForm.getParameters().get(i),
						viewForm.getOpts().get(i),
						value));
				
			}
			
			if (i < viewForm.getParameters().size() - 1
					&& StringUtils.isNotBlank(viewForm.getParameters().get(i + 1))) {
				condition.append(logical);
			}
		}

		_logger.info("查詢條件 " + condition);
		
		String sql = "";
		if (condition.length() > 0) {
			sql = "where " + condition.toString();
		}
		
		viewForm.setHouseKeepings(registerService.selectOsHousekeepings(sql));
		
		List<Boolean> ckbox = new ArrayList<>();
		for (int i = 0; i < viewForm.getHouseKeepings().size(); i++) {
			ckbox.add(false);
		}
		viewForm.setSelectCkbox(ckbox);
	}
	
	/**
	 * Reset
	 */
	public void doResetAction() {
		viewForm.setParameters(new ArrayList<>());
		viewForm.setOpts(new ArrayList<>());
		viewForm.setValues(new ArrayList<>());
		doAddOptions();
	}
	
	/**
	 * 新增選項
	 */
	public void doAddOptions() {
		viewForm.getParameters().add("");
		viewForm.getOpts().add("");
		viewForm.getValues().add("");
		viewForm.getSelectCkbox().add(false);
	}
	
	public void doSubOption(int index) {
		viewForm.getParameters().remove(index);
		viewForm.getOpts().remove(index);
		viewForm.getValues().remove(index);
//		viewForm.getSelectCkbox().remove(index);
	}
	
	/**
	 * Add
	 */
	public void doAddAction() {
		clearFields();
	}
	
	/**
	 * Save
	 */
	public void doSaveAction() {
		if (validateCreate()) {
			
			RdOsHousekeepingKey key = new RdOsHousekeepingKey();
			key.setAction(viewForm.getNewAction());
			key.setFolder(viewForm.getNewFolder());
			key.setRsFlag(viewForm.getNewRsFlag());
			RdOsHousekeeping exist = registerService.findOsHousekeepingByPk(key);
			if (exist != null) {
				setGlobalErrorMessageFormat("msgs", "validate.data.duplicate", "Folder+Action+Rs_Flag");
				return;
			}
			
			/*[200822:doUpdateAction 亦須處理Folder、Destination append / 邏輯，故移至validateCreate處理]
			if (!viewForm.getNewFolder().endsWith("/")) {
				viewForm.setNewFolder(viewForm.getNewFolder() + "/");
			}
			
			if (StringUtils.isNotBlank(viewForm.getNewDestination()) && !viewForm.getNewDestination().endsWith("/")) {
				viewForm.setNewDestination(viewForm.getNewDestination() + "/");
			}
			*/
			
			RdOsHousekeeping toSave = new RdOsHousekeeping();
			toSave.setActionName(viewForm.getNewActionName());
			toSave.setFolder(viewForm.getNewFolder());
			toSave.setRsFlag(viewForm.getNewRsFlag());
			toSave.setExpiredate(Integer.toString(viewForm.getNewExpireDate()));
			toSave.setAction(viewForm.getNewAction());
			toSave.setDestination(viewForm.getNewDestination());
			
			try {
				registerService.insertOsHousekeeping(toSave);
				clearFields();
				
				// 工作日誌
				String logContent = String.format("Add OsHousekeeping[ACTION=%s][FOLDER=%s][RS_FLAG=%s]", 
						toSave.getAction(), toSave.getFolder(), toSave.getRsFlag());
				saveWorkLog("OsHousekeeping", WorkLogAction.Add, logContent);
				
				setGlobalMessageFormat("msgs", "info.create.success");
				
			} catch (Exception e) {
				_logger.error(e.getMessage(), e);
				setGlobalErrorMessageFormat("msgs", "error.create.fail");
			}
			
		}
	}
	
	private boolean validateCreate() {
		boolean result = true;
		if (StringUtils.isBlank(viewForm.getNewActionName())) {
			setComponentErrorMessage("newActionName", "msgs", "validate.required");
			result = false;
		}
		
		if (StringUtils.isBlank(viewForm.getNewFolder())) {
			setComponentErrorMessage("newFolder", "msgs", "validate.required");
			result = false;
		}
		
		//[200822:doUpdateAction 亦須處理Folder、Destination append / 邏輯，故移至validateCreate處理]
		if (!viewForm.getNewFolder().endsWith("/")) {
			viewForm.setNewFolder(viewForm.getNewFolder() + "/");
		}
		
		if (StringUtils.isNotBlank(viewForm.getNewDestination()) && !viewForm.getNewDestination().endsWith("/")) {
			viewForm.setNewDestination(viewForm.getNewDestination() + "/");
		}
		
		/*[200822:doUpdateAction呼叫validateCreate無法透過以下邏輯進行duplicate檢核，故取消，改catch DuplicateKeyException]
		if (result) {
			RdOsHousekeeping exist = registerService.findOsHouseKeepingByPrimaryKey(viewForm.getNewFolder(), viewForm.getNewAction(), viewForm.getNewRsFlag());
			if (exist != null) {
				setGlobalErrorMessageFormat("msgs", "error.housekeeping.uniquie.key.error");
				result = false;
			}
		}
		*/
		
		return result;
	}
	
	private void clearFields() {
		viewForm.setNewActionName("");
		viewForm.setNewFolder("");
		viewForm.setNewAction("CMP");
		viewForm.setNewRsFlag("");
		viewForm.setNewExpireDate(0);
		viewForm.setNewDestination("");
		viewForm.setSelectHousekeeping(null);
	}
	
	public boolean getDisplayDeleteBtn() {
		for (Boolean b : viewForm.getSelectCkbox()) {
			if (b) {
				return true;
			}
		}
		return false;
	}
	
	public void actionChanged(AjaxBehaviorEvent event) {
		if ("CMP".equals(viewForm.getNewAction())) {
			viewForm.setNewExpireDate(0);
		}
	}
	
	/**
	 * Delete
	 * @param info
	 */
	public void doDeleteOneAction(RdOsHousekeeping hk) {
		try {
			if (hk == null) {
				hk = viewForm.getSelectHousekeeping();
			}
			
			RdOsHousekeepingKey pk = new RdOsHousekeepingKey();
			pk.setAction(hk.getAction());
			pk.setFolder(hk.getFolder());
			pk.setRsFlag(hk.getRsFlag());
			registerService.deleteOsHousekeepingByPk(pk);
			
			// 工作日誌
			String logContent = String.format("Delete OsHousekeeping[ACTION_NAME=%s][FOLDER=%s][RS_FLAG=%s][EXPIREDATE=%s][ACTION=%s][DESTINATION=%s]", 
					hk.getActionName(), hk.getFolder(), hk.getRsFlag(), hk.getExpiredate(),
					hk.getAction(), hk.getDestination());
			saveWorkLog("OsHousekeeping", WorkLogAction.Delete, logContent);
			
			doSearchAction();
			setGlobalMessageFormat("msgs", "info.delete.success");
			
			PrimeFaces.current().executeScript("PF('newDialog').hide()");
			
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
			setGlobalErrorMessageFormat("msgs", "error.delete.fail");
		}
		
	}
	
	/**
	 * delete selected
	 */
	public void doDeleteSelectAction() {
		List<RdOsHousekeeping> toDelete = new ArrayList<>();
		List<String> logs = new ArrayList<>();
		
		for (int i = 0; i < viewForm.getSelectCkbox().size(); i++) {
			if (viewForm.getSelectCkbox().get(i)) {
				RdOsHousekeeping hk = viewForm.getHouseKeepings().get(i);
				toDelete.add(hk);
				
				String logContent = String.format("Delete OsHousekeeping[ACTION_NAME=%s][FOLDER=%s][RS_FLAG=%s][EXPIREDATE=%s][ACTION=%s][DESTINATION=%s]", 
						hk.getActionName(), hk.getFolder(), hk.getRsFlag(), hk.getExpiredate(),
						hk.getAction(), hk.getDestination());
				logs.add(logContent);
			}
		}
		
		try {
			registerService.deleteOsHousekeepings(toDelete);
			// 工作日誌
			for (String logContent : logs) {
				saveWorkLog("OsHousekeeping", WorkLogAction.Delete, logContent);
			}
			
			doSearchAction();
			setGlobalMessageFormat("msgs", "info.delete.success");
			
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
			setGlobalErrorMessageFormat("msgs", "error.delete.fail");
		}
		
	}
	
	/**
	 * 
	 * @param event
	 */
	public void doRowSelectAction(SelectEvent event) {
		RdOsHousekeeping hk = (RdOsHousekeeping) event.getObject();
		viewForm.setNewActionName(hk.getActionName());
		viewForm.setNewFolder(hk.getFolder());
		viewForm.setNewAction(hk.getAction());
		viewForm.setNewRsFlag(hk.getRsFlag());
		viewForm.setNewExpireDate(StringUtils.isBlank(hk.getExpiredate()) ? 0 : Integer.valueOf(hk.getExpiredate(), 10));
		viewForm.setNewDestination(hk.getDestination());
		viewForm.setSelectHousekeeping(hk);
	}
	
	/**
	 * Update
	 */
	public void doUpdateAction() {
		if (validateCreate()) {
			
			RdOsHousekeeping src = viewForm.getSelectHousekeeping();
			RdOsHousekeeping toUpdate = new RdOsHousekeeping();
			BeanUtils.copyProperties(src, toUpdate);
			
			toUpdate.setActionName(viewForm.getNewActionName());
			toUpdate.setFolder(viewForm.getNewFolder());
			toUpdate.setRsFlag(viewForm.getNewRsFlag());
			toUpdate.setExpiredate(Integer.toString(viewForm.getNewExpireDate()));
			toUpdate.setAction(viewForm.getNewAction());
			toUpdate.setDestination(viewForm.getNewDestination());
			
			try {
				RdOsHousekeepingKey pk = new RdOsHousekeepingKey();
				pk.setAction(src.getAction());
				pk.setFolder(src.getFolder());
				pk.setRsFlag(src.getRsFlag());
				registerService.updateOsHousekeepingByPk(toUpdate, pk);
				
				// 工作日誌
				String logContent = String.format("Update OsHousekeeping[ACTION_NAME=%s|%s][FOLDER=%s|%s][RS_FLAG=%s|%s][EXPIREDATE=%s|%s][ACTION=%s|%s][DESTINATION=%s|%s]", 
						src.getActionName(), toUpdate.getActionName(),
						src.getFolder(), toUpdate.getFolder(), 
						src.getRsFlag(), toUpdate.getRsFlag(), 
						src.getExpiredate(), toUpdate.getExpiredate(),
						src.getAction(), toUpdate.getAction(), 
						src.getDestination(), toUpdate.getDestination());
				saveWorkLog("OsHousekeeping", WorkLogAction.Update, logContent);
				
				doSearchAction();
				setGlobalMessageFormat("msgs", "info.update.success");
				
				PrimeFaces.current().executeScript("PF('newDialog').hide()");
				
			} catch (DuplicateKeyException e) {
				//[200822:更新時Unique Key duplicate check]
				setGlobalErrorMessageFormat("msgs", "error.housekeeping.uniquie.key.error");
			} catch (Exception e) {
				_logger.error(e.getMessage(), e);
				setGlobalErrorMessageFormat("msgs", "error.update.fail");
			}
			
		}
	}
}
