package tw.com.taipeifubon.jmrs.backing.reg;

import java.util.ArrayList;
import java.util.List;

import javax.faces.model.SelectItem;

import tw.com.hjct.jmrs.dao.bean.RdJobHashInfo;
import tw.com.hjct.jmrs.dao.bean.RdJobInfo;
import tw.com.hjct.jmrs.dao.bean.RdJobSrcInfo;
import tw.com.hjct.jmrs.dao.bean.RdJobTgtInfo;
import tw.com.hjct.jmrs.dao.bean.RdSubmitJob;
import tw.com.taipeifubon.jmrs.ViewForm;

@SuppressWarnings("serial")
public class REG102ViewForm extends ViewForm {

	private List<SelectItem> monitorItems;
	
	private RdJobInfo jobInfo;
	
	private String jobName;
	
	private String jobSys;
	
	private String jsName;
	
	private String firstName;
	
	private String secondName;
	
	private String isDraft;
	
	private String isSendMail;
	
	private String mFlag;
	
	private List<String> monitor = new ArrayList<>();
	
	private String groupName;
	
	private String fileDescription;
	
	private String memo;

	private String deleteConfirmMsg;
	
	private List<RdJobSrcInfo> jobSrcInfos;
	private List<Boolean> srcSelectCkbox = new ArrayList<>();
	private int currentSrcRanCode;
	private RdJobSrcInfo selectedJobSrcInfo;
	private String srcName;
	private String srcFTFlag;
	private String srcOwner;
	private String srcCtlFile;
	private String srcFolder;
	private String srcConname;
	private String srcFregrExp;
	private String srcTwsAction;
	private String srcPriority;
	
	
	private List<RdJobTgtInfo> jobTgtInfos;
	private List<Boolean> tgtSelectCkbox = new ArrayList<>();
	private int currentTgtRanCode;
	private RdJobTgtInfo selectedJobTgtInfo;
	private String tgtName;
	private String tgtFTFlag;
	private String tgtOwner;
	private String tgtFolder;
	private String tgtConname;
	private String tgtNode;
	private String tgtDir;
	private String tgtFilename;
	private String tgtSrcFileType;
	private String tgtFileType;
	
	private List<RdJobHashInfo> jobHashInfos;
	private List<Boolean> hashSelectCkbox = new ArrayList<>();
	private int currentHashRanCode;
	private RdJobHashInfo selectedJobHashInfo;
	private String hashName;
	private String hashFTFlag;
	private String hashOwner;
	private String hashConname;
	private String hashFregrExp;
	
	private List<RdSubmitJob> submitJobs;
	private List<Boolean> submitSelectCkbox = new ArrayList<>();
	private RdSubmitJob selectedRdSubmitJob;
	private String submitSubJobName;
	
	public RdJobInfo getJobInfo() {
		return jobInfo;
	}

	public void setJobInfo(RdJobInfo jobInfo) {
		this.jobInfo = jobInfo;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getJobSys() {
		return jobSys;
	}

	public void setJobSys(String jobSys) {
		this.jobSys = jobSys;
	}

	public String getJsName() {
		return jsName;
	}

	public void setJsName(String jsName) {
		this.jsName = jsName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getSecondName() {
		return secondName;
	}

	public void setSecondName(String secondName) {
		this.secondName = secondName;
	}

	public String getIsDraft() {
		return isDraft;
	}

	public void setIsDraft(String isDraft) {
		this.isDraft = isDraft;
	}

	public String getIsSendMail() {
		return isSendMail;
	}

	public void setIsSendMail(String isSendMail) {
		this.isSendMail = isSendMail;
	}

	public String getmFlag() {
		return mFlag;
	}

	public void setmFlag(String mFlag) {
		this.mFlag = mFlag;
	}

	public List<String> getMonitor() {
		return monitor;
	}

	public void setMonitor(List<String> monitor) {
		this.monitor = monitor;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getFileDescription() {
		return fileDescription;
	}

	public void setFileDescription(String fileDescription) {
		this.fileDescription = fileDescription;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public List<SelectItem> getMonitorItems() {
		return monitorItems;
	}

	public void setMonitorItems(List<SelectItem> monitorItems) {
		this.monitorItems = monitorItems;
	}

	public String getDeleteConfirmMsg() {
		return deleteConfirmMsg;
	}

	public void setDeleteConfirmMsg(String deleteConfirmMsg) {
		this.deleteConfirmMsg = deleteConfirmMsg;
	}

	public List<RdJobSrcInfo> getJobSrcInfos() {
		return jobSrcInfos;
	}

	public void setJobSrcInfos(List<RdJobSrcInfo> jobSrcInfos) {
		this.jobSrcInfos = jobSrcInfos;
	}

	public List<RdJobTgtInfo> getJobTgtInfos() {
		return jobTgtInfos;
	}

	public void setJobTgtInfos(List<RdJobTgtInfo> jobTgtInfos) {
		this.jobTgtInfos = jobTgtInfos;
	}

	public List<RdJobHashInfo> getJobHashInfos() {
		return jobHashInfos;
	}

	public void setJobHashInfos(List<RdJobHashInfo> jobHashInfos) {
		this.jobHashInfos = jobHashInfos;
	}

	public List<RdSubmitJob> getSubmitJobs() {
		return submitJobs;
	}

	public void setSubmitJobs(List<RdSubmitJob> submitJobs) {
		this.submitJobs = submitJobs;
	}

	public List<Boolean> getSrcSelectCkbox() {
		return srcSelectCkbox;
	}

	public void setSrcSelectCkbox(List<Boolean> srcSelectCkbox) {
		this.srcSelectCkbox = srcSelectCkbox;
	}

	public List<Boolean> getTgtSelectCkbox() {
		return tgtSelectCkbox;
	}

	public void setTgtSelectCkbox(List<Boolean> tgtSelectCkbox) {
		this.tgtSelectCkbox = tgtSelectCkbox;
	}

	public List<Boolean> getHashSelectCkbox() {
		return hashSelectCkbox;
	}

	public void setHashSelectCkbox(List<Boolean> hashSelectCkbox) {
		this.hashSelectCkbox = hashSelectCkbox;
	}

	public List<Boolean> getSubmitSelectCkbox() {
		return submitSelectCkbox;
	}

	public void setSubmitSelectCkbox(List<Boolean> submitSelectCkbox) {
		this.submitSelectCkbox = submitSelectCkbox;
	}

	public int getCurrentSrcRanCode() {
		return currentSrcRanCode;
	}

	public void setCurrentSrcRanCode(int currentSrcRanCode) {
		this.currentSrcRanCode = currentSrcRanCode;
	}

	public String getSrcName() {
		return srcName;
	}

	public void setSrcName(String srcName) {
		this.srcName = srcName;
	}

	public String getSrcFTFlag() {
		return srcFTFlag;
	}

	public void setSrcFTFlag(String srcFTFlag) {
		this.srcFTFlag = srcFTFlag;
	}

	public String getSrcOwner() {
		return srcOwner;
	}

	public void setSrcOwner(String srcOwner) {
		this.srcOwner = srcOwner;
	}

	public String getSrcCtlFile() {
		return srcCtlFile;
	}

	public void setSrcCtlFile(String srcCtlFile) {
		this.srcCtlFile = srcCtlFile;
	}

	public String getSrcFolder() {
		return srcFolder;
	}

	public void setSrcFolder(String srcFolder) {
		this.srcFolder = srcFolder;
	}

	public String getSrcConname() {
		return srcConname;
	}

	public void setSrcConname(String srcConname) {
		this.srcConname = srcConname;
	}

	public String getSrcFregrExp() {
		return srcFregrExp;
	}

	public void setSrcFregrExp(String srcFregrExp) {
		this.srcFregrExp = srcFregrExp;
	}

	public String getSrcTwsAction() {
		return srcTwsAction;
	}

	public void setSrcTwsAction(String srcTwsAction) {
		this.srcTwsAction = srcTwsAction;
	}

	public String getSrcPriority() {
		return srcPriority;
	}

	public void setSrcPriority(String srcPriority) {
		this.srcPriority = srcPriority;
	}

	public RdJobSrcInfo getSelectedJobSrcInfo() {
		return selectedJobSrcInfo;
	}

	public void setSelectedJobSrcInfo(RdJobSrcInfo selectedJobSrcInfo) {
		this.selectedJobSrcInfo = selectedJobSrcInfo;
	}

	public String getTgtName() {
		return tgtName;
	}

	public void setTgtName(String tgtName) {
		this.tgtName = tgtName;
	}

	public String getTgtFTFlag() {
		return tgtFTFlag;
	}

	public void setTgtFTFlag(String tgtFTFlag) {
		this.tgtFTFlag = tgtFTFlag;
	}

	public String getTgtOwner() {
		return tgtOwner;
	}

	public void setTgtOwner(String tgtOwner) {
		this.tgtOwner = tgtOwner;
	}

	public String getTgtFolder() {
		return tgtFolder;
	}

	public void setTgtFolder(String tgtFolder) {
		this.tgtFolder = tgtFolder;
	}

	public String getTgtConname() {
		return tgtConname;
	}

	public void setTgtConname(String tgtConname) {
		this.tgtConname = tgtConname;
	}

	public String getTgtNode() {
		return tgtNode;
	}

	public void setTgtNode(String tgtNode) {
		this.tgtNode = tgtNode;
	}

	public String getTgtDir() {
		return tgtDir;
	}

	public void setTgtDir(String tgtDir) {
		this.tgtDir = tgtDir;
	}

	public String getTgtFilename() {
		return tgtFilename;
	}

	public void setTgtFilename(String tgtFilename) {
		this.tgtFilename = tgtFilename;
	}

	public String getTgtSrcFileType() {
		return tgtSrcFileType;
	}

	public void setTgtSrcFileType(String tgtSrcFileType) {
		this.tgtSrcFileType = tgtSrcFileType;
	}

	public String getTgtFileType() {
		return tgtFileType;
	}

	public void setTgtFileType(String tgtFileType) {
		this.tgtFileType = tgtFileType;
	}

	public RdJobTgtInfo getSelectedJobTgtInfo() {
		return selectedJobTgtInfo;
	}

	public void setSelectedJobTgtInfo(RdJobTgtInfo selectedJobTgtInfo) {
		this.selectedJobTgtInfo = selectedJobTgtInfo;
	}

	public int getCurrentTgtRanCode() {
		return currentTgtRanCode;
	}

	public void setCurrentTgtRanCode(int currentTgtRanCode) {
		this.currentTgtRanCode = currentTgtRanCode;
	}

	public int getCurrentHashRanCode() {
		return currentHashRanCode;
	}

	public void setCurrentHashRanCode(int currentHashRanCode) {
		this.currentHashRanCode = currentHashRanCode;
	}

	public String getHashName() {
		return hashName;
	}

	public void setHashName(String hashName) {
		this.hashName = hashName;
	}

	public String getHashFTFlag() {
		return hashFTFlag;
	}

	public void setHashFTFlag(String hashFTFlag) {
		this.hashFTFlag = hashFTFlag;
	}

	public String getHashOwner() {
		return hashOwner;
	}

	public void setHashOwner(String hashOwner) {
		this.hashOwner = hashOwner;
	}

	public String getHashConname() {
		return hashConname;
	}

	public void setHashConname(String hashConname) {
		this.hashConname = hashConname;
	}

	public String getHashFregrExp() {
		return hashFregrExp;
	}

	public void setHashFregrExp(String hashFregrExp) {
		this.hashFregrExp = hashFregrExp;
	}

	public RdJobHashInfo getSelectedJobHashInfo() {
		return selectedJobHashInfo;
	}

	public void setSelectedJobHashInfo(RdJobHashInfo selectedJobHashInfo) {
		this.selectedJobHashInfo = selectedJobHashInfo;
	}

	public RdSubmitJob getSelectedRdSubmitJob() {
		return selectedRdSubmitJob;
	}

	public void setSelectedRdSubmitJob(RdSubmitJob selectedRdSubmitJob) {
		this.selectedRdSubmitJob = selectedRdSubmitJob;
	}

	public String getSubmitSubJobName() {
		return submitSubJobName;
	}

	public void setSubmitSubJobName(String submitSubJobName) {
		this.submitSubJobName = submitSubJobName;
	}

}
