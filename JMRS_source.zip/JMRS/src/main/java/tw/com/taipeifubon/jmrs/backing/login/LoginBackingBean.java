package tw.com.taipeifubon.jmrs.backing.login;

import java.util.Arrays;
import java.util.Date;
import java.util.Hashtable;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.naming.Context;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import tw.com.hjct.jmrs.dao.bean.Whitelist;
import tw.com.taipeifubon.jmrs.BackingBeanBase;
import tw.com.taipeifubon.jmrs.Constants;
import tw.com.taipeifubon.jmrs.Constants.WorkLogAction;
import tw.com.taipeifubon.jmrs.service.SystemService;
import tw.com.taipeifubon.jmrs.vo.ConfigValueVo;
import tw.com.taipeifubon.jmrs.vo.ConfigVo;
import tw.com.taipeifubon.jmrs.vo.SessionProfile;

/**
 * <p>Title: tw.com.taipeifubon.jmrs.backing.login.LoginBackingBean</p>
 * <p>Description: 登入</p>
 * <p>Copyright: Copyright HJCT. 2020. All Rights Reserved.</p>
 * <p>Company: HJCT</p>
 * @author HJCT
 * @version 1.0
 */
@SuppressWarnings("serial")
@Named
@RequestScoped
public class LoginBackingBean extends BackingBeanBase<LoginViewForm> {

	@Autowired
	protected SystemService systemService;
	
	@Value("${ldap.server:}")
	private String ldapServer;
	
	@Override
	protected void init() {
		
	}
	
	public void doDevLogin() {
		SessionProfile profile = new SessionProfile();
		profile.setUsername(viewForm.getUsername());
		profile.setWhitelist(new Whitelist());
		profile.getWhitelist().setLoginTime(new Date());
		profile.getWhitelist().setLastLoginTime(DateUtils.addDays(new Date(), -2));
		profile.setAuthFuncs(Arrays.asList("SYS101", "SYS201", "SYS301", "SYS401", "REG101", "REG201", "REG301"));
		getSession().setAttribute(Constants.SESSION_PROFILE, profile);
		
		if (profile.auth("REG101")) {
			redirect("/WEB-INF/pages/REG/REG101/REG101.xhtml");
		} else {
			redirect("/WEB-INF/pages/home.xhtml");
		}
	}

	/**
	 * 登入
	 */
	public void doLogin() {
		
		boolean valid = true;
		
		if (StringUtils.isBlank(viewForm.getUsername())) {
			setComponentErrorMessage("username", "msgs", "validate.required");
			valid = false;
		}
		
		if (StringUtils.isBlank(viewForm.getPassword())) {
			setComponentErrorMessage("password", "msgs", "validate.required");
			valid = false;
		}
		
		if (!valid) {
			return;
		}
		
		String username = "groupt\\" + viewForm.getUsername();
		String password = viewForm.getPassword();
		
		String server = ldapServer;
		Hashtable<String, String> env = new Hashtable<>();
		env.put(Context.SECURITY_PRINCIPAL, username);
		env.put(Context.SECURITY_CREDENTIALS, password);
		env.put(Context.PROVIDER_URL, server);
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		
		// 驗證的類型 "none", "simple", "strong"
		// env.put(Context.SECURITY_AUTHENTICATION, "simple");
		
		try {
			// 白名單
			Whitelist whitelist = systemService.findWhitelistByAccount(viewForm.getUsername());
			if (whitelist == null) {
				setGlobalErrorMessage("Not in white list");
				return;
			}
			
			LdapContext ldapContext = new InitialLdapContext(env, null);
			_logger.info("ldapContext:" + ldapContext);
			_logger.info("用戶" + username + "登錄驗證成功");
			
			// 授權
			ConfigVo vo = systemService.findConfigByKey("ROLE_PERMISSION");
			ConfigValueVo auth = vo.getConfigValueVos().stream().filter(p -> p.getCode().equals(whitelist.getRole()))
				.findFirst().orElse(null);
			
			if (auth == null) {
				setGlobalErrorMessage("No PERMISSIOIN");
				getSession().invalidate();
				return;
			}
			
			whitelist.setLastLoginTime(whitelist.getLoginTime());
			whitelist.setLoginTime(new Date());
			systemService.updateWhitelist(whitelist);
			
			SessionProfile profile = new SessionProfile();
			profile.setUsername(viewForm.getUsername());
			profile.setWhitelist(whitelist);
			profile.setAuthFuncs(Arrays.asList(auth.getConfigValue().getValue().split(",")));
			getSession().setAttribute(Constants.SESSION_PROFILE, profile);
			
			saveWorkLog("Login", WorkLogAction.Execute, String.format("User login[Account=%s]", username));
			
			if (profile.auth("REG101")) {
				redirect("/WEB-INF/pages/REG/REG101/REG101.xhtml");
			} else {
				redirect("/WEB-INF/pages/home.xhtml");
			}
			
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
			setGlobalErrorMessageFormat("msgs", "error.login.fail");
		}
		
	}
	
	/**
	 * 登出
	 */
	public void doLogout() {
		SessionProfile profile = (SessionProfile) getSession().getAttribute(Constants.SESSION_PROFILE);
		saveWorkLog("Logout", WorkLogAction.Execute, String.format("User logout[Account=%s]", profile.getUsername()));
		
		// 清除Session資訊
		getSession().invalidate();
		// 導至首頁
		redirect(_PAGE_MAIN_FRAME);
	}
}
