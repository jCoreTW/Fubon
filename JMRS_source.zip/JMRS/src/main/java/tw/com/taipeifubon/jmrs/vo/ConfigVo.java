package tw.com.taipeifubon.jmrs.vo;

import java.util.List;

import tw.com.hjct.jmrs.dao.bean.Config;

/**
 * <p>Title: com.torsc.tcbis.ext.vo.ConfigVo</p>
 * <p>Description: Config資料物件</p>
 * <p>Copyright: Copyright jCore. 2018. All Rights Reserved.</p>
 * <p>Company: jCore</p>
 * @author jCore
 * @version 1.0
 */
public class ConfigVo {
	
	private Integer configId;
	
	/** 組態管理 */
	private Config config;
	
	/** 組態值Vo */
	private List<ConfigValueVo> configValueVos;

	public Config getConfig() {
		return config;
	}

	public Integer getConfigId() {
		return configId;
	}

	public void setConfigId(Integer configId) {
		this.configId = configId;
	}

	public void setConfig(Config config) {
		this.config = config;
	}

	public List<ConfigValueVo> getConfigValueVos() {
		return configValueVos;
	}

	public void setConfigValueVos(List<ConfigValueVo> configValueVos) {
		this.configValueVos = configValueVos;
	}
	
}
