package tw.com.taipeifubon.jmrs.filter;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import tw.com.taipeifubon.jmrs.Constants;
import tw.com.taipeifubon.jmrs.vo.SessionProfile;


//import tw.com.hjct.fos.Constants;
//import tw.com.hjct.fos.Constants.UserStateEnum;
//import tw.com.hjct.fos.ext.vo.SessionProfile;

/**
 * <p>Title: tw.com.hjct.fos.web.filter.AuthenticateFilter</p>
 * <p>Description: 認證過濾器</p>
 * <p>Copyright: Copyright HJCT. 2014. All Rights Reserved.</p>
 * <p>Company: HJCT</p>
 * @author HJCT
 * @version 1.0
 */
@WebFilter
public class AuthenticateFilter implements Filter {

	/** 訊息追蹤 */
	private static Logger _logger = LoggerFactory.getLogger(AuthenticateFilter.class);
	
	/** 登入頁面 */
	private static final String _LOGIN_PAGE = "/login/login.xhtml";
	
	/** 錯誤頁 */
	private static final String _ERROR_PAGE = "/error.xhtml";
	
	public static final String PAGE_TIMER_ATTRIBUTE = "tw.com.hjct.fos.web.PAGE_TIMER";
	
	/** 忽略頁面 */
	private static final List<String> BYPASS_PAGES = new ArrayList<String>();
	static {
		BYPASS_PAGES.add(_LOGIN_PAGE); // 登入頁面
		//BYPASS_PAGES.add(_GET_PWD_PAGE); // 取得新密碼頁面
		BYPASS_PAGES.add(_ERROR_PAGE); // 錯誤頁 
	}
	
	/**
	 * 使用者身分認證
	 */
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
    	
    	HttpServletRequest rq = (HttpServletRequest) request;
		HttpServletResponse rs = (HttpServletResponse) response;
		// 防範 Cross Frame Scripting（XFS）弱點 (SAMEORIGIN: 只允許顯示在同網站的框架中)
		rs.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
	
		// 當request的資源為.css, .js, .gif, .css.xhtml, .js.xhtml, 登入頁面，不做身分認證
		String url = ((HttpServletRequest)request).getRequestURL().toString();

		if (!byPass(url)) { // 不做身分認證之頁面
			int extension = url.lastIndexOf(".");
			if (extension != -1) {
				String resourceType = url.substring(extension);
				if (".xhtml".equals(resourceType)) {
					url = url.replace(".xhtml", "");
					extension = url.lastIndexOf(".");
					if (extension != -1) {
						resourceType = url.substring(extension);
					}
					
					if (!".gif".equals(resourceType) && !".js".equals(resourceType) 
							&& !".css".equals(resourceType) && !".png".equals(resourceType)) {
						
						_logger.debug("來源: " + url);

						// 檢查Session是否有登入資訊
						SessionProfile profile = (SessionProfile) rq.getSession().getAttribute(Constants.SESSION_PROFILE);
						if (profile == null) {
							
							/* 判斷使用者的動作來源是否為ajax或partial submit
							 * note: 判斷 <p:ajax>可用 "XMLHttpRequest".equals(rq.getHeader("X-Requested-With")) */
							if ("partial/ajax".equals(rq.getHeader("Faces-Request"))) {
								// 回復前端通知要redirect
								rs.setContentType("text/xml");
								rs.getWriter()
							        .append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
							        .printf("<partial-response><redirect url=\"%s\"></redirect></partial-response>", rq.getContextPath() + _LOGIN_PAGE);
							} else {
    							rs.sendRedirect(rq.getContextPath() + _LOGIN_PAGE); // 尚未登入，導至登入頁
							}
    						return;
						}
					}
				}
			}
		}
    	
		/* 防範 Cross Site Scripting（XSS）弱點
		chain.doFilter(request, response); */
		chain.doFilter(new XSSRequestWrapper((HttpServletRequest) request), response);
		
	}
	
	private boolean byPass(String url) {
		for (String byPass : BYPASS_PAGES) {
			if (url.endsWith(byPass)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
	}

	@Override
	public void destroy() {
	}
	
}
