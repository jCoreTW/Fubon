package tw.com.taipeifubon.jmrs.backing.reg;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.enterprise.context.SessionScoped;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.model.SelectItem;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.annotation.Autowired;

import tw.com.hjct.jmrs.dao.bean.RdJobInfo;
import tw.com.taipeifubon.jmrs.BackingBeanBase;
import tw.com.taipeifubon.jmrs.Constants.WorkLogAction;
import tw.com.taipeifubon.jmrs.service.RegisterService;
import tw.com.taipeifubon.jmrs.service.SystemService;
import tw.com.taipeifubon.jmrs.vo.ConfigVo;

/**
 * <p>Title: tw.com.taipeifubon.jmrs.backing.reg.REG101BackingBean</p>
 * <p>Description: JobInfo</p>
 * <p>Copyright: Copyright HJCT. 2020. All Rights Reserved.</p>
 * <p>Company: HJCT</p>
 * @author HJCT
 * @version 1.0
 */
@SuppressWarnings("serial")
@Named
@SessionScoped
public class REG101BackingBean extends BackingBeanBase<REG101ViewForm> {

	@Autowired
	private RegisterService registerService;
	
	@Autowired
	private SystemService systemService;
	
	@Override
	protected void init() {
		doAddOptions();
	}

	/**
	 * Search
	 */
	public void doSearchAction() {
		StringBuffer condition = new StringBuffer();
		String logical = viewForm.getLogical();
		
		for (int i = 0; i < viewForm.getParameters().size(); i++) {
			if (StringUtils.isNotBlank(viewForm.getParameters().get(i))) {
				String value = "'" + viewForm.getValues().get(i) + "'";
				if (viewForm.getOpts().get(i).indexOf("like") > -1) {
					value = "'%" + viewForm.getValues().get(i) + "%'";
					
				} else if (viewForm.getOpts().get(i).indexOf("in") > -1) {
					value = StringUtils.join(value.split(","), "','");
					value = "(" + value + ")";
				}
				
				condition.append(String.format(" (%s %s %s) ", 
						viewForm.getParameters().get(i),
						viewForm.getOpts().get(i),
						value));
				
			}
			
			if (i < viewForm.getParameters().size() - 1
					&& StringUtils.isNotBlank(viewForm.getParameters().get(i + 1))) {
				condition.append(logical);
			}
		}

		_logger.info("查詢條件 " + condition);
		
		String sql = "";
		if (condition.length() > 0) {
			sql = "where " + condition.toString();
		}
		
		viewForm.setJobInfos(registerService.selectJobInfos(sql));
		
		List<Boolean> ckbox = new ArrayList<>();
		for (int i = 0; i < viewForm.getJobInfos().size(); i++) {
			ckbox.add(false);
		}
		viewForm.setSelectCkbox(ckbox);
	}
	
	/**
	 * Reset
	 */
	public void doResetAction() {
		viewForm.setParameters(new ArrayList<>());
		viewForm.setOpts(new ArrayList<>());
		viewForm.setValues(new ArrayList<>());
		doAddOptions();
	}
	
	/**
	 * 新增選項
	 */
	public void doAddOptions() {
		viewForm.getParameters().add("");
		viewForm.getOpts().add("");
		viewForm.getValues().add("");
		viewForm.getSelectCkbox().add(false);
	}
	
	public void doSubOption(int index) {
		viewForm.getParameters().remove(index);
		viewForm.getOpts().remove(index);
		viewForm.getValues().remove(index);
//		viewForm.getSelectCkbox().remove(index);
	}
	
	/**
	 * Add
	 */
	public void doAddAction() {
		ConfigVo config = systemService.findConfigByKey("MONITOR");
		List<SelectItem> monItems = new ArrayList<>();
		config.getConfigValueVos().forEach(valVo -> {
			monItems.add(new SelectItem(valVo.getCode(), valVo.getConfigValue().getValue()));
		});
		viewForm.setMonitorItems(monItems);
		clearFields();
	}
	
	/**
	 * Save
	 */
	public void doSaveAction() {
		if (validateCreate()) {
			RdJobInfo info = new RdJobInfo();
			info.setNum(viewForm.getNewNum());
			info.setJobname(viewForm.getNewJobName());
			info.setJobsys(viewForm.getNewJobSys());
			info.setJsName(viewForm.getNewJsName());
			info.setFirstName(viewForm.getNewFirstName());
			info.setSecondName(viewForm.getNewSecondName());
			info.setIsdraft(viewForm.getNewIsDraft());
			info.setIssendmail(viewForm.getNewIsSendMail());
			info.setMflag(viewForm.getNewMFlag());
			info.setMonitor(StringUtils.join(viewForm.getNewMonitor().toArray(), ","));
			info.setGroupName(viewForm.getNewGroupName());
			info.setFileDescription(viewForm.getNewFileDescription());
			info.setMemo(viewForm.getNewMemo());
			
			try {
				registerService.insertJobInfo(info);
				clearFields();
				
				// 工作日誌
				String logContent = String.format("Add JobInfo[Num=%s]", info.getNum());
				saveWorkLog("JobInfo", WorkLogAction.Add, logContent);
				
				setGlobalMessageFormat("msgs", "info.create.success");
				
			} catch (Exception e) {
				_logger.error(e.getMessage(), e);
				setGlobalErrorMessageFormat("msgs", "error.create.fail");
			}
			
		}
	}
	
	/**
	 * Num Dup check
	 * @param event
	 */
	public void checkNumDup(AjaxBehaviorEvent event) {
		viewForm.setDupNum(false);
		RdJobInfo exist = registerService.findJobInfoByNum(viewForm.getNewNum());
		if (exist != null) {
			setComponentErrorMessage("newNum", "msgs", "validate.duplicate");
			viewForm.setDupNum(true);
		}
	}
	
	private boolean validateCreate() {
		boolean result = true;
		if (StringUtils.isBlank(viewForm.getNewNum())) {
			setComponentErrorMessage("newNum", "msgs", "validate.required");
			result = false;
		}
		
		if (StringUtils.isBlank(viewForm.getNewJobName())) {
			setComponentErrorMessage("newJobName", "msgs", "validate.required");
			result = false;
		}
		
		if (StringUtils.isBlank(viewForm.getNewJobSys())) {
			setComponentErrorMessage("newJobSys", "msgs", "validate.required");
			result = false;
		}
		
		if (StringUtils.isBlank(viewForm.getNewJsName())) {
			setComponentErrorMessage("newJsName", "msgs", "validate.required");
			result = false;
		}
		
		if (StringUtils.isBlank(viewForm.getNewFirstName())) {
			setComponentErrorMessage("newFirstName", "msgs", "validate.required");
			result = false;
		}
		
		if (StringUtils.isBlank(viewForm.getNewSecondName())) {
			setComponentErrorMessage("newSecondName", "msgs", "validate.required");
			result = false;
		}
		
		if (StringUtils.isBlank(viewForm.getNewGroupName())) {
			setComponentErrorMessage("newGroupName", "msgs", "validate.required");
			result = false;
		}
		
		if (StringUtils.isBlank(viewForm.getNewFileDescription())) {
			setComponentErrorMessage("newFileDescription", "msgs", "validate.required");
			result = false;
		}
		
		if (result) {
			RdJobInfo exist = registerService.findJobInfoByNum(viewForm.getNewNum());
			if (exist != null) {
				setComponentErrorMessage("newNum", "msgs", "validate.duplicate");
				result = false;
			} else {
				exist = registerService.findJobInfoByJobNameAndJobSys(viewForm.getNewJobName(), viewForm.getNewJobSys());
				if (exist != null) {
					setGlobalErrorMessageFormat("msgs", "error.jobinfo.uniquie.key.error");
					result = false;
				}
			}
			
		}
		
		return result;
	}
	
	private void clearFields() {
		viewForm.setNewNum("");
		viewForm.setNewJobName("");
		viewForm.setNewJobSys("");
		viewForm.setNewJsName("");
		viewForm.setNewFirstName("");
		viewForm.setNewSecondName("");
		viewForm.setNewIsDraft("");
		viewForm.setNewIsSendMail("");
		viewForm.setNewMFlag("");
		viewForm.setNewMonitor(new ArrayList<>());
		viewForm.setNewGroupName("");
		viewForm.setNewFileDescription("");
		viewForm.setNewMemo("");
	}
	
	public boolean getDisplayDeleteBtn() {
		for (Boolean b : viewForm.getSelectCkbox()) {
			if (b) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Check Delete
	 */
	public void doCheckDeleteOneAction(RdJobInfo info, int index) {
		// 查詢關聯
		viewForm.setDeleteConfirmMsg(String.format("JobSrcInfo：%d\nJobTgtInfo：%d\nJobHashInfo：%d\nSubmitJob：%d", 
				registerService.countJobSrcInfoByNum(info.getNum()),
				registerService.countJobTgtInfoByNum(info.getNum()),
				registerService.countJobHashInfoByNum(info.getNum()),
				registerService.countSubmitJobByNum(info.getNum())));
		viewForm.setDeleteIndex(index);
	}
	
	/**
	 * Delete
	 * @param info
	 */
	public void doDeleteOneAction(RdJobInfo info) {
		try {
			registerService.deleteJobInfoByNum(info.getNum());
			viewForm.setDeleteConfirmMsg("");
			
			// 工作日誌
			String logContent = String.format("Delete JobInfo[NUM=%s][JOBNAME=%s][JOBSYS=%s][FILE_DESCRIPTION=%s][JS_NAME=%s][FIRST_NAME=%s][SECOND_NAME=%s][ISDRAFT=%s][GROUP_NAME=%s][ISSENDMAIL=%s][MEMO=%s][MFLAG=%s][MONITOR=%s]", 
					info.getNum(), info.getJobname(), info.getJobsys(), info.getFileDescription(),
					info.getJsName(), info.getFirstName(), info.getSecondName(), info.getIsdraft(),
					info.getGroupName(), info.getIssendmail(), info.getMemo(), info.getMflag(),
					info.getMonitor());
			saveWorkLog("JobInfo", WorkLogAction.Delete, logContent);
			
			doSearchAction();
			setGlobalMessageFormat("msgs", "info.delete.success");
			
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
			setGlobalErrorMessageFormat("msgs", "error.delete.fail");
		}
		
	}
	
	/**
	 * delete selected
	 */
	public void doDeleteSelectAction() {
		List<String> toDelete = new ArrayList<>();
		List<String> logs = new ArrayList<>();
		
		for (int i = 0; i < viewForm.getSelectCkbox().size(); i++) {
			if (viewForm.getSelectCkbox().get(i)) {
				RdJobInfo info = viewForm.getJobInfos().get(i);
				toDelete.add(info.getNum());
				
				String logContent = String.format("Delete JobInfo[NUM=%s][JOBNAME=%s][JOBSYS=%s][FILE_DESCRIPTION=%s][JS_NAME=%s][FIRST_NAME=%s][SECOND_NAME=%s][ISDRAFT=%s][GROUP_NAME=%s][ISSENDMAIL=%s][MEMO=%s][MFLAG=%s][MONITOR=%s]", 
						info.getNum(), info.getJobname(), info.getJobsys(), info.getFileDescription(),
						info.getJsName(), info.getFirstName(), info.getSecondName(), info.getIsdraft(),
						info.getGroupName(), info.getIssendmail(), info.getMemo(), info.getMflag(),
						info.getMonitor());
				logs.add(logContent);
			}
		}
		
		try {
			registerService.deleteJobInfosByNum(toDelete);
			// 工作日誌
			for (String logContent : logs) {
				saveWorkLog("JobInfo", WorkLogAction.Delete, logContent);
			}
			
			doSearchAction();
			setGlobalMessageFormat("msgs", "info.delete.success");
			
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
			setGlobalErrorMessageFormat("msgs", "error.delete.fail");
		}
		
	}
	
	/**
	 * 
	 * @param event
	 */
	public void doRowSelectAction(SelectEvent event) {
		viewForm.setDeleteConfirmMsg("");
		RdJobInfo info = (RdJobInfo) event.getObject();
		goToDetail(info);
	}
	
	/**
	 * go to detail page
	 * @param jobInfo
	 */
	public void goToDetail(RdJobInfo jobInfo) {
		REG102BackingBean bean = findBean("REG102BackingBean");
		REG102ViewForm nextView = bean.getViewForm();
		nextView.setJobInfo(jobInfo);
		nextView.setJobName(jobInfo.getJobname());
		nextView.setJobSys(jobInfo.getJobsys());
		nextView.setJsName(jobInfo.getJsName());
		nextView.setFirstName(jobInfo.getFirstName());
		nextView.setSecondName(jobInfo.getSecondName());
		nextView.setIsDraft(jobInfo.getIsdraft());
		nextView.setIsSendMail(jobInfo.getIssendmail());
		nextView.setmFlag(jobInfo.getMflag());
		//[200819_Eric:Monitor非必填，須判斷是否為null以避免NullPoint]
		if(jobInfo.getMonitor() != null) {
			nextView.setMonitor(Arrays.asList(jobInfo.getMonitor().split(",")));
		} else {
			nextView.setMonitor(new ArrayList<String>());
		}
		nextView.setGroupName(jobInfo.getGroupName());
		nextView.setFileDescription(jobInfo.getFileDescription());
		nextView.setMemo(jobInfo.getMemo());
		
		bean.initialData();
		redirect("/WEB-INF/pages/REG/REG102/REG102.xhtml");
		
	}
}
