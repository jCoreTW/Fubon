package tw.com.taipeifubon.jmrs.backing.home;

import tw.com.taipeifubon.jmrs.ViewForm;

public class HomeViewForm extends ViewForm {

}
