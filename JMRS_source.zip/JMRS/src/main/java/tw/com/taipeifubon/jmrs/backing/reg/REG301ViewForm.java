package tw.com.taipeifubon.jmrs.backing.reg;

import java.util.ArrayList;
import java.util.List;

import tw.com.hjct.jmrs.dao.bean.RdOsHousekeeping;
import tw.com.hjct.jmrs.dao.bean.SidbHousekeeping;
import tw.com.taipeifubon.jmrs.ViewForm;

@SuppressWarnings("serial")
public class REG301ViewForm extends ViewForm {

	private List<String> parameters = new ArrayList<>();
	
	private List<String> opts = new ArrayList<>();
	
	private List<String> values = new ArrayList<>();
	
	private List<SidbHousekeeping> houseKeepings;
	
	private List<Boolean> selectCkbox = new ArrayList<>();

	private SidbHousekeeping selectHousekeeping;
	
	private String newOwner;
	
	private String newTableName;
	
	private String newColumnName;
	
	private String newPeriod;
	
	private String newPeriodUnit;
	
	private String newRegistEmp;
	
	private String newRcNum;
	
	private String newFrequency;
	
	private String logical;
	
	public List<String> getParameters() {
		return parameters;
	}

	public void setParameters(List<String> parameters) {
		this.parameters = parameters;
	}

	public List<String> getOpts() {
		return opts;
	}

	public void setOpts(List<String> opts) {
		this.opts = opts;
	}

	public List<String> getValues() {
		return values;
	}

	public void setValues(List<String> values) {
		this.values = values;
	}

	public List<Boolean> getSelectCkbox() {
		return selectCkbox;
	}

	public void setSelectCkbox(List<Boolean> selectCkbox) {
		this.selectCkbox = selectCkbox;
	}

	public List<SidbHousekeeping> getHouseKeepings() {
		return houseKeepings;
	}

	public void setHouseKeepings(List<SidbHousekeeping> houseKeepings) {
		this.houseKeepings = houseKeepings;
	}

	public SidbHousekeeping getSelectHousekeeping() {
		return selectHousekeeping;
	}

	public void setSelectHousekeeping(SidbHousekeeping selectHousekeeping) {
		this.selectHousekeeping = selectHousekeeping;
	}

	public String getNewOwner() {
		return newOwner;
	}

	public void setNewOwner(String newOwner) {
		this.newOwner = newOwner;
	}

	public String getNewTableName() {
		return newTableName;
	}

	public void setNewTableName(String newTableName) {
		this.newTableName = newTableName;
	}

	public String getNewColumnName() {
		return newColumnName;
	}

	public void setNewColumnName(String newColumnName) {
		this.newColumnName = newColumnName;
	}

	public String getNewPeriod() {
		return newPeriod;
	}

	public void setNewPeriod(String newPeriod) {
		this.newPeriod = newPeriod;
	}

	public String getNewPeriodUnit() {
		return newPeriodUnit;
	}

	public void setNewPeriodUnit(String newPeriodUnit) {
		this.newPeriodUnit = newPeriodUnit;
	}

	public String getNewRegistEmp() {
		return newRegistEmp;
	}

	public void setNewRegistEmp(String newRegistEmp) {
		this.newRegistEmp = newRegistEmp;
	}

	public String getNewRcNum() {
		return newRcNum;
	}

	public void setNewRcNum(String newRcNum) {
		this.newRcNum = newRcNum;
	}

	public String getNewFrequency() {
		return newFrequency;
	}

	public void setNewFrequency(String newFrequency) {
		this.newFrequency = newFrequency;
	}

	public String getLogical() {
		return logical;
	}

	public void setLogical(String logical) {
		this.logical = logical;
	}

}
