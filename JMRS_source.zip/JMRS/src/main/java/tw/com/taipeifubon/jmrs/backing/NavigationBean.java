package tw.com.taipeifubon.jmrs.backing;

import java.awt.event.ActionEvent;
import java.io.IOException;
import java.io.Serializable;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryPoolMXBean;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.management.Attribute;
import javax.management.AttributeList;
import javax.management.MBeanServer;
import javax.management.ObjectName;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.primefaces.component.growl.Growl;
import org.springframework.context.annotation.Scope;

import tw.com.taipeifubon.jmrs.exception.JMRSRuntimeException;

/**
 * <p>Title: tw.com.hjct.fos.backing.NavigationBean</p>
 * <p>Description: Menu導覽管理</p>
 * <p>Copyright: Copyright HJCT. 2014. All Rights Reserved.</p>
 * <p>Company: HJCT</p>
 * @author HJCT
 * @version 1.0
 */
@Named
@Scope("session")
public class NavigationBean implements Serializable {

	private static final long serialVersionUID = 3490921835869949829L;
	public static String _HOME_PAGE = "/WEB-INF/pages/home.xhtml";
	public static String _MAIN_PAGE = "/jmrs.xhtml";
	private boolean extendedRender = false;
    private boolean customRender = true;
    private boolean tableRender = false;
    private boolean layoutRender = false;
    
    // 導頁路徑
    private String selectedIncludePath;

    /** 頁面導覽監聽器 */
    private List<NavigationListener> callbacks = new ArrayList<NavigationListener>();
    
    private transient Growl growl;
    
    /**
     * 建構子
     */
    public NavigationBean() {
    	// 若是web.xml內有設定home page路徑，使用web.xml設定值
    	FacesContext ctx = FacesContext.getCurrentInstance();
    	String home = ctx.getExternalContext().getInitParameter("navigation.home.page");
    	selectedIncludePath = _HOME_PAGE;
    	if (home != null) {
    		_HOME_PAGE = home;
    		selectedIncludePath = _HOME_PAGE;
    	}
    	
    	String main = ctx.getExternalContext().getInitParameter("navigation.main.page");
    	if (main != null) {
    		_MAIN_PAGE = main;
    	}
    }
    
    /**
     * 取得連結路徑
     * @return
     */
    public String getSelectedIncludePath() {
        FacesContext context = FacesContext.getCurrentInstance();
        Map<String, String> map = context.getExternalContext().getRequestParameterMap();
        String requestedPath = (String) map.get("includePath");
        if ((null != requestedPath) && (requestedPath.length() > 0))  {
            selectedIncludePath = requestedPath;
            navigated();
        }
        return selectedIncludePath;
    }

    /**
     * 設定目前頁面
     * @param selectedIncludePath
     */
    public void setSelectedIncludePath(String selectedIncludePath) {
        this.selectedIncludePath = selectedIncludePath;
        navigated();
    }

    /**
     * Menu連結變更
     * @param event
     */
    public void navigationPathChange(ActionEvent event){
        FacesContext context = FacesContext.getCurrentInstance();
        Map<String, String> map = context.getExternalContext().getRequestParameterMap();
        selectedIncludePath = (String) map.get("includePath");
        navigated();
    }
    
    /**
     * 回到首頁
     */
    public void goToHome() {
    	FacesContext facesContext = FacesContext.getCurrentInstance();
    	//HttpSession session = (HttpSession) facesContext.getExternalContext().getSession(false);
    	//session.invalidate();
    	
		try {
			HttpServletRequest rq = (HttpServletRequest) facesContext.getExternalContext().getRequest();
			selectedIncludePath = _HOME_PAGE;
			String homePage = rq.getContextPath() + "/" + _MAIN_PAGE;
			FacesContext.getCurrentInstance().getExternalContext().redirect(homePage);
		} catch (IOException e) {}
		
    	navigated();
    }
    
    /**
     * Menu呼叫, 由參數取得路徑
     */
    public void goToPath() {
    	ExternalContext ctx = FacesContext.getCurrentInstance().getExternalContext();
    	String path = ctx.getRequestParameterMap().get("path");
    	setSelectedIncludePath(path);
    	
    	// 切換功能，清除Session
    	HttpSession session = (HttpSession) ctx.getSession(false);
    	Set<String> keys = ctx.getSessionMap().keySet();
    	for (String key : keys) {
    		if (key.endsWith("BackingBean")) {
    			session.removeAttribute(key);
    		}
    	}
    	
    	// Menu為不同的form，用redirect刷新頁面
    	try {
    		ctx.redirect("jmrs.xhtml");
		} catch (IOException e) {
			
		}
    }
    
    /**
     * 註冊監聽器
     * @param listener
     */
    public void registryListener(NavigationListener listener) {
    	if (!callbacks.contains(listener)) {
    		callbacks.add(listener);
    	}
    }
    
    /**
     * 發佈導覽事件
     */
    private void navigated() {
    	for (NavigationListener listener : callbacks) {
    		listener.onNavigation();
    	}
    }
    
    /**
     * 取得系統資訊
     */
    public String getMemoryInfo() {
    	/* 原寫法
    	try {
    		double cpuRatio = getProcessCpuLoad();
			String hostName = InetAddress.getLocalHost().getHostName();
	        //long maxMem = Runtime.getRuntime().maxMemory() / 1024 / 1024;
	        long totalMem = Runtime.getRuntime().totalMemory() / 1024 / 1024;
	        long freeMem = Runtime.getRuntime().freeMemory() / 1024 / 1024;
	        return ("hostname : " + hostName + " (T=" + totalMem + "MB F=" + freeMem + "MB P=" + cpuRatio + "%)");
	        
    	} catch (UnknownHostException e) {
			e.printStackTrace();
		}
    	return null; */
    	
    	long mbUnit = 1024 * 1024;
        long maxMem = Runtime.getRuntime().maxMemory() / mbUnit;
        long totalMem = Runtime.getRuntime().totalMemory() / mbUnit;
        long freeMem = Runtime.getRuntime().freeMemory() / mbUnit;
        // 顯示PermGen Space資訊
        List<MemoryPoolMXBean> beans = ManagementFactory.getMemoryPoolMXBeans();
        long pgMax = 0;
        long pgUsed = 0;
        for(MemoryPoolMXBean bean : beans) {
            if(bean.getName().toLowerCase().indexOf("perm gen") >= 0) {
            	pgMax = bean.getUsage().getMax() / mbUnit;
            	pgUsed = bean.getUsage().getUsed() / mbUnit;
            	break;
            }
        }
        
        String info = "Memory Info [Max: %dMB] [Total: %dMB] [Free: %dMB] [PGMax: %dMB] [PGUsed: %dMB] [PGFree: %dMB]";
        return String.format(info, maxMem, totalMem, freeMem, pgMax, pgUsed, (pgMax - pgUsed));
    }
    
    /**
     * 取得CPU使用率
     */
	private double getProcessCpuLoad() {
		double cpuRatio = 0.0;

		try {
			MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
		    ObjectName name = ObjectName.getInstance("java.lang:type=OperatingSystem");
		    AttributeList list = mbs.getAttributes(name, new String[]{ "SystemCpuLoad" });
		    if (list.isEmpty())
		    	return cpuRatio;

		    Attribute att = (Attribute)list.get(0);
		    Double value  = (Double)att.getValue();
		    if (value == -1.0)
		    	return cpuRatio;

		    cpuRatio = (int)(value * 1000) / 10.0; 
		    
		} catch (Exception ex) {
			throw new JMRSRuntimeException(ex); // 記錄Exception log
		}
		
		return cpuRatio;
	}
    
    public boolean getExtendedRender() {
        return extendedRender;
    }
    
    public boolean getCustomRender() {
        return customRender;
    }
    
    public boolean getTableRender() {
        return tableRender;
    }
    
    public boolean getLayoutRender() {
        return layoutRender;
    }
    
    public void setExtendedRender(boolean extendedRender) {
        this.extendedRender = extendedRender;
    }
    
    public void setCustomRender(boolean customRender) {
        this.customRender = customRender;
    }
    
    public void setTableRender(boolean tableRender) {
        this.tableRender = tableRender;
    }
    
    public void setLayoutRender(boolean layoutRender) {
        this.layoutRender = layoutRender;
    }
	
    public Growl getGrowl() {
		return growl;
	}

	public void setGrowl(Growl growl) {
		this.growl = growl;
	}
}
