package tw.com.taipeifubon.jmrs.listener;

import javax.faces.application.Application;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.PostConstructApplicationEvent;
import javax.faces.event.PreDestroyApplicationEvent;
import javax.faces.event.SystemEvent;
import javax.faces.event.SystemEventListener;

//import tw.com.hjct.fos.SystemConfig;
//import tw.com.hjct.fos.ext.scheduler.SystemScheduler;

/**
 * <p>Title: tw.com.hjct.fos.web.listener.ApplicationListener</p>
 * <p>Description: JSF系統監聽器</p>
 * <p>Copyright: Copyright HJCT. 2014. All Rights Reserved.</p>
 * <p>Company: HJCT</p>
 * @author HJCT
 * @version 1.0
 */
public class ApplicationListener implements SystemEventListener {

	@Override
	public boolean isListenerForSource(Object source) {
		return (source instanceof Application);
	}

	@Override
	public void processEvent(SystemEvent event) throws AbortProcessingException {
		// 系統初始化
		if(event instanceof PostConstructApplicationEvent){
//			SystemConfig.getInstance(); // 取得全部組態資料
//			SystemScheduler.startAllSystemJobs(); // 啟動所有排程
		}
	 
		// 系統結束
		if(event instanceof PreDestroyApplicationEvent){
//			SystemScheduler.stopAllSystemJobs(); // 停止所有排程
		}
	}
	
	

}
