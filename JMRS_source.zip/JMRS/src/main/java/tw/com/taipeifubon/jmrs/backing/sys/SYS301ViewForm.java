package tw.com.taipeifubon.jmrs.backing.sys;

import java.util.Date;
import java.util.List;

import tw.com.hjct.jmrs.dao.bean.WorkLog;
import tw.com.taipeifubon.jmrs.ViewForm;

@SuppressWarnings("serial")
public class SYS301ViewForm extends ViewForm {

	private Date startDate;
	
	private Date endDate;
	
	private String account;
	
	private String ip;
	
	private String function;
	
	private String action;
	
	private String content;
	
	private List<WorkLog> workLogs;

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public List<WorkLog> getWorkLogs() {
		return workLogs;
	}

	public void setWorkLogs(List<WorkLog> workLogs) {
		this.workLogs = workLogs;
	}
	
}
