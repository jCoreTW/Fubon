package tw.com.taipeifubon.jmrs.backing.reg;

import java.util.ArrayList;
import java.util.List;

import tw.com.hjct.jmrs.dao.bean.RdOsHousekeeping;
import tw.com.taipeifubon.jmrs.ViewForm;

@SuppressWarnings("serial")
public class REG201ViewForm extends ViewForm {

	private List<String> parameters = new ArrayList<>();
	
	private List<String> opts = new ArrayList<>();
	
	private List<String> values = new ArrayList<>();
	
	private List<RdOsHousekeeping> houseKeepings;
	
	private List<Boolean> selectCkbox = new ArrayList<>();

	private RdOsHousekeeping selectHousekeeping;
	
	private String newActionName;
	
	private String newFolder;
	
	private String newAction;
	
	private String newRsFlag;
	
	private int newExpireDate;
	
	private String newDestination;
	
	private String logical;
	
	public List<String> getParameters() {
		return parameters;
	}

	public void setParameters(List<String> parameters) {
		this.parameters = parameters;
	}

	public List<String> getOpts() {
		return opts;
	}

	public void setOpts(List<String> opts) {
		this.opts = opts;
	}

	public List<String> getValues() {
		return values;
	}

	public void setValues(List<String> values) {
		this.values = values;
	}

	public List<RdOsHousekeeping> getHouseKeepings() {
		return houseKeepings;
	}

	public void setHouseKeepings(List<RdOsHousekeeping> houseKeepings) {
		this.houseKeepings = houseKeepings;
	}

	public List<Boolean> getSelectCkbox() {
		return selectCkbox;
	}

	public void setSelectCkbox(List<Boolean> selectCkbox) {
		this.selectCkbox = selectCkbox;
	}

	public String getNewActionName() {
		return newActionName;
	}

	public void setNewActionName(String newActionName) {
		this.newActionName = newActionName;
	}

	public String getNewFolder() {
		return newFolder;
	}

	public void setNewFolder(String newFolder) {
		this.newFolder = newFolder;
	}

	public String getNewAction() {
		return newAction;
	}

	public void setNewAction(String newAction) {
		this.newAction = newAction;
	}

	public String getNewRsFlag() {
		return newRsFlag;
	}

	public void setNewRsFlag(String newRsFlag) {
		this.newRsFlag = newRsFlag;
	}

	public int getNewExpireDate() {
		return newExpireDate;
	}

	public void setNewExpireDate(int newExpireDate) {
		this.newExpireDate = newExpireDate;
	}

	public String getNewDestination() {
		return newDestination;
	}

	public void setNewDestination(String newDestination) {
		this.newDestination = newDestination;
	}

	public RdOsHousekeeping getSelectHousekeeping() {
		return selectHousekeeping;
	}

	public void setSelectHousekeeping(RdOsHousekeeping selectHousekeeping) {
		this.selectHousekeeping = selectHousekeeping;
	}

	public String getLogical() {
		return logical;
	}

	public void setLogical(String logical) {
		this.logical = logical;
	}
	
}
