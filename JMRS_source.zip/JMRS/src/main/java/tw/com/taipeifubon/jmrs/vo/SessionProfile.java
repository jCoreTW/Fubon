package tw.com.taipeifubon.jmrs.vo;

import java.util.Date;
import java.util.List;

import tw.com.hjct.jmrs.dao.bean.Whitelist;

/**
 * <p>Title: com.cbms.ext.vo.SessionProfile</p>
 * <p>Description: 登入者資料</p>
 * <p>Copyright: Copyright HJCT. 2014. All Rights Reserved.</p>
 * <p>Company: HJCT</p>
 * @author HJCT
 * @version 1.0
 */
public class SessionProfile {

	private String username;
	
	private Whitelist whitelist;
	
	private List<String> authFuncs;

	public boolean auth(String func) {
		return authFuncs.contains(func);
	}
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public List<String> getAuthFuncs() {
		return authFuncs;
	}

	public void setAuthFuncs(List<String> authFuncs) {
		this.authFuncs = authFuncs;
	}

	public Whitelist getWhitelist() {
		return whitelist;
	}

	public void setWhitelist(Whitelist whitelist) {
		this.whitelist = whitelist;
	}
	
}
