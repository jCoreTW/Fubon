package tw.com.taipeifubon.jmrs.backing.reg;

import java.util.ArrayList;
import java.util.List;

import javax.faces.model.SelectItem;

import tw.com.hjct.jmrs.dao.bean.RdJobInfo;
import tw.com.taipeifubon.jmrs.ViewForm;

@SuppressWarnings("serial")
public class REG101ViewForm extends ViewForm {

	private List<String> parameters = new ArrayList<>();
	
	private List<String> opts = new ArrayList<>();
	
	private List<String> values = new ArrayList<>();

	private List<RdJobInfo> jobInfos;
	
	private List<Boolean> selectCkbox = new ArrayList<>();
	
	private String logical;
	
	private List<SelectItem> monitorItems;
	
	private boolean dupNum;
	
	private String newNum;
	
	private String newJobName;
	
	private String newJobSys;
	
	private String newJsName;
	
	private String newFirstName;
	
	private String newSecondName;
	
	private String newIsDraft;
	
	private String newIsSendMail;
	
	private String newMFlag;
	
	private List<String> newMonitor;
	
	private String newGroupName;
	
	private String newFileDescription;
	
	private String newMemo;
	
	private String deleteConfirmMsg;
	
	private int deleteIndex;
	
	public List<String> getParameters() {
		return parameters;
	}

	public void setParameters(List<String> parameters) {
		this.parameters = parameters;
	}

	public List<String> getOpts() {
		return opts;
	}

	public void setOpts(List<String> opts) {
		this.opts = opts;
	}

	public List<String> getValues() {
		return values;
	}

	public void setValues(List<String> values) {
		this.values = values;
	}

	public List<RdJobInfo> getJobInfos() {
		return jobInfos;
	}

	public void setJobInfos(List<RdJobInfo> jobInfos) {
		this.jobInfos = jobInfos;
	}

	public List<Boolean> getSelectCkbox() {
		return selectCkbox;
	}

	public void setSelectCkbox(List<Boolean> selectCkbox) {
		this.selectCkbox = selectCkbox;
	}

	public String getLogical() {
		return logical;
	}

	public void setLogical(String logical) {
		this.logical = logical;
	}

	public List<SelectItem> getMonitorItems() {
		return monitorItems;
	}

	public void setMonitorItems(List<SelectItem> monitorItems) {
		this.monitorItems = monitorItems;
	}

	public String getNewNum() {
		return newNum;
	}

	public void setNewNum(String newNum) {
		this.newNum = newNum;
	}

	public String getNewJobName() {
		return newJobName;
	}

	public void setNewJobName(String newJobName) {
		this.newJobName = newJobName;
	}

	public String getNewJobSys() {
		return newJobSys;
	}

	public void setNewJobSys(String newJobSys) {
		this.newJobSys = newJobSys;
	}

	public String getNewJsName() {
		return newJsName;
	}

	public void setNewJsName(String newJsName) {
		this.newJsName = newJsName;
	}

	public String getNewFirstName() {
		return newFirstName;
	}

	public void setNewFirstName(String newFirstName) {
		this.newFirstName = newFirstName;
	}

	public String getNewSecondName() {
		return newSecondName;
	}

	public void setNewSecondName(String newSecondName) {
		this.newSecondName = newSecondName;
	}

	public String getNewIsDraft() {
		return newIsDraft;
	}

	public void setNewIsDraft(String newIsDraft) {
		this.newIsDraft = newIsDraft;
	}

	public String getNewIsSendMail() {
		return newIsSendMail;
	}

	public void setNewIsSendMail(String newIsSendMail) {
		this.newIsSendMail = newIsSendMail;
	}

	public String getNewMFlag() {
		return newMFlag;
	}

	public void setNewMFlag(String newMFlag) {
		this.newMFlag = newMFlag;
	}

	public String getNewGroupName() {
		return newGroupName;
	}

	public void setNewGroupName(String newGroupName) {
		this.newGroupName = newGroupName;
	}

	public String getNewFileDescription() {
		return newFileDescription;
	}

	public void setNewFileDescription(String newFileDescription) {
		this.newFileDescription = newFileDescription;
	}

	public String getNewMemo() {
		return newMemo;
	}

	public void setNewMemo(String newMemo) {
		this.newMemo = newMemo;
	}

	public List<String> getNewMonitor() {
		return newMonitor;
	}

	public void setNewMonitor(List<String> newMonitor) {
		this.newMonitor = newMonitor;
	}

	public boolean isDupNum() {
		return dupNum;
	}

	public void setDupNum(boolean dupNum) {
		this.dupNum = dupNum;
	}
	
	public int getDeleteIndex() {
		return deleteIndex;
	}

	public void setDeleteIndex(int deleteIndex) {
		this.deleteIndex = deleteIndex;
	}

	public String getDeleteConfirmMsg() {
		return deleteConfirmMsg;
	}

	public void setDeleteConfirmMsg(String deleteConfirmMsg) {
		this.deleteConfirmMsg = deleteConfirmMsg;
	}
	
}
