package tw.com.taipeifubon.jmrs.service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tw.com.hjct.jmrs.dao.bean.WorkLog;
import tw.com.hjct.jmrs.dao.bean.WorkLogExample;
import tw.com.hjct.jmrs.dao.mapper.CustomMapper;
import tw.com.hjct.jmrs.dao.mapper.WorkLogMapper;

@Service
public class LogService {

	@Autowired
	private SqlSessionTemplate sqlTemplate;
	
	/**
	 * 查詢工作日誌
	 * @param startDate
	 * @param endDate
	 * @param account
	 * @param ip
	 * @param function
	 * @param action
	 * @param content
	 * @return
	 */
	public List<WorkLog> selectWorkLog(Date startDate, Date endDate, String account, String ip,
			String function, String action, String content) {
		WorkLogMapper mapper = sqlTemplate.getMapper(WorkLogMapper.class);
		WorkLogExample example = new WorkLogExample();
		WorkLogExample.Criteria criteria = example.createCriteria();
		
		if (startDate != null) {
			criteria.andLogTimeGreaterThanOrEqualTo(startDate);
		}
		
		if (endDate != null) {
			Calendar end = Calendar.getInstance();
			end.setTime(endDate);
			end.set(Calendar.HOUR_OF_DAY, 23);
			end.set(Calendar.MINUTE, 59);
			end.set(Calendar.SECOND, 59);
			end.set(Calendar.MILLISECOND, 999);
			criteria.andLogTimeLessThanOrEqualTo(end.getTime());
		}
		
		if (StringUtils.isNotBlank(account)) {
			criteria.andAccountLike("%" + account + "%");
		}
		
		if (StringUtils.isNotBlank(ip)) {
			criteria.andIpLike("%" + ip + "%");
		}
		
		if (StringUtils.isNotBlank(function)) {
			criteria.andFuncEqualTo(function);
		}
		
		if (StringUtils.isNotBlank(action)) {
			criteria.andActionEqualTo(action);
		}
		
		if (StringUtils.isNotBlank(content)) {
			criteria.andContentLike("%" + content + "%");
		}
		
		example.setOrderByClause("LOG_TIME DESC");
		
		return mapper.selectByExample(example);
	}
	
	/**
	 * 新增工作日誌
	 * @param workLog
	 */
	public void insertWorkLog(WorkLog workLog) {
		CustomMapper seqMapper = sqlTemplate.getMapper(CustomMapper.class);
		workLog.setWorkLogId(seqMapper.selectSequence("WORK_LOG_SEQ"));
		
		WorkLogMapper mapper = sqlTemplate.getMapper(WorkLogMapper.class);
		mapper.insert(workLog);
	}
}
