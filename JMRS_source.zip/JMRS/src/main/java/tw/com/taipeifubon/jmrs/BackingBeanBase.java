package tw.com.taipeifubon.jmrs;

import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.text.MessageFormat;
import java.util.Date;
import java.util.ResourceBundle;

import javax.annotation.PostConstruct;
import javax.faces.application.Application;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.UIViewRoot;
import javax.faces.component.visit.VisitCallback;
import javax.faces.component.visit.VisitContext;
import javax.faces.component.visit.VisitResult;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.sun.faces.component.visit.FullVisitContext;

import tw.com.hjct.jmrs.dao.bean.WorkLog;
import tw.com.taipeifubon.jmrs.Constants.WorkLogAction;
import tw.com.taipeifubon.jmrs.backing.NavigationBean;
import tw.com.taipeifubon.jmrs.backing.NavigationListener;
import tw.com.taipeifubon.jmrs.service.LogService;
import tw.com.taipeifubon.jmrs.vo.SessionProfile;

/**
 * <p>Title: tw.com.hjct.fos.BackingBeanBase</p>
 * <p>Description: Backing Bean基本類別</p>
 * <p>Copyright: Copyright HJCT. 2014. All Rights Reserved.</p>
 * <p>Company: HJCT</p>
 * @author HJCT
 * @version 1.0
 */
public abstract class BackingBeanBase<V extends ViewForm> implements Serializable {
	
	private static final long serialVersionUID = 2486074363889577214L;

	/** 訊息追蹤 */
	protected static Logger _logger = LoggerFactory.getLogger(BackingBeanBase.class);
	
	public static final String _PAGE_MAIN_FRAME = "jmrs.xhtml";
	
	public static final String MESSAGE_RESOURCE = "msgs";
	
	public static final String LOG_RESOURCE = "worklog";
	
	public static final String PAGENAV_RESOURCE = "pageNav";
	
	// ResourceBundle
	protected static ResourceBundle messagesBundle = null;
	
	/** 頁面表單欄位 */
	protected V viewForm;
	
	/** 頁面流程控制元件 */
	@Autowired
	private NavigationBean navigateion;
	
	@Autowired
	protected LogService logService;
	
	static {
		FacesContext context = FacesContext.getCurrentInstance();
		Application app = context.getApplication();
		messagesBundle = app.getResourceBundle(context, MESSAGE_RESOURCE); // msgs
	}
	
	/**
	 * Backing Bean初始化
	 */
	@PostConstruct
	protected abstract void init();
	
	/**
	 * 建構子
	 */
	@SuppressWarnings("unchecked")
	public BackingBeanBase() {
		// 實體化ViewForm物件
		try {
			ParameterizedType aParameterizedType = (ParameterizedType) getClass().getGenericSuperclass();
			Class<V> viewFormClz = (Class<V>) aParameterizedType.getActualTypeArguments()[0];
			viewForm = viewFormClz.newInstance();
			viewForm.setBackingBean(this);
		} catch (Exception e) {
			_logger.error("實體化ViewForm失敗", e);
			throw new RuntimeException(e);
		}
		navigateion = findBean("navigationBean");
	}
	
	/**
	 * 取得HttpSession物件
	 * @return
	 */
	public HttpSession getSession() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		return (HttpSession) facesContext.getExternalContext().getSession(false);
	}
	
	/**
	 * 取得log4j Logger物件
	 * @return Logger物件
	 */
	protected Logger getLogger() {
		return _logger;
	}
	
	/**
	 * 取得ViewForm物件
	 * @return
	 */
	public V getViewForm() {
		return viewForm;
	}

	/**
	 * 設定全域正常訊息
	 * @param msg
	 */
	public void setGlobalMessage(String msg) {
		FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, msg, msg);  
		FacesContext fc = FacesContext.getCurrentInstance();  
		fc.addMessage(null, facesMsg);
		NavigationBean navBean = findBean("navigationBean");
		navBean.getGrowl().setLife(3000);
	}
	
	/**
	 * 設定全域正常訊息-以MessageFormat處理
	 * @param msg
	 */
	protected void setGlobalMessageFormat(String bundleName, String key, String... texts) {
		String value = formatMessage(bundleName, key, texts);
		setGlobalMessage(value);
	}
	
	/**
	 * 設定全域錯誤訊息
	 * @param msg
	 */
	protected void setGlobalErrorMessage(String msg) {
		FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg);  
		FacesContext fc = FacesContext.getCurrentInstance();  
		fc.addMessage(null, facesMsg);  
		NavigationBean navBean = findBean("navigationBean");
		navBean.getGrowl().setLife(5000); // 一般訊息5s
	}
	
	/**
	 * 設定全域錯誤訊息-以MessageFormat處理
	 * @param msg
	 */
	protected void setGlobalErrorMessageFormat(String bundleName, String key, String... texts) {
		String value = formatMessage(bundleName, key, texts);
		setGlobalErrorMessage(value);
	}
	
	/**
	 * 設定元件訊息
	 * @param bundleName
	 * @param bundleKey
	 * @param clientId
	 */
	protected void setComponentErrorMessage(String clientId, String bundleName, String bundleKey, String... texts) {
		String msg = formatMessage(bundleName, bundleKey, texts);
		FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg);  
		FacesContext fc = FacesContext.getCurrentInstance();
		fc.addMessage(clientId, facesMsg);
	}
	
	/**
	 * 設定元件訊息
	 * @param bundleName
	 * @param bundleKey
	 * @param clientId
	 */
	protected void setComponentMessage(String clientId, String bundleName, String bundleKey, String... texts) {
		String msg = formatMessage(bundleName, bundleKey, texts);
		FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, msg, msg);  
		FacesContext fc = FacesContext.getCurrentInstance();
		fc.addMessage(clientId, facesMsg);
	}
	
	/**
	 * 設定元件訊息
	 * @param bundleName
	 * @param bundleKey
	 * @param clientId
	 */
	protected void setComponentErrorMessage(String clientId, String bundleName, String bundleKey) {
		String msg = getResourceBundle(bundleName).getString(bundleKey);
		FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg);  
		FacesContext fc = FacesContext.getCurrentInstance();
		fc.addMessage(clientId, facesMsg);
	}
	
	/**
	 * 取得多國語操作物件
	 * @param bundleName
	 * @return
	 */
	public static ResourceBundle getResourceBundle(String bundleName) {
		ResourceBundle rBundle = null;		
		if (MESSAGE_RESOURCE.equals(bundleName)) { // msgs
			rBundle = messagesBundle;
		} else { // 其他
			FacesContext context = FacesContext.getCurrentInstance();
			Application app = context.getApplication();
			rBundle = app.getResourceBundle(context, bundleName);
		}
		return rBundle;
	}
	
	/**
	 * 由預設的Resource Bundle取得多國語言的字串
	 * @param key
	 * @return String
	 */
	public static String getMsgFromDefaultBundle(String key){
		String msg = getResourceBundle(MESSAGE_RESOURCE).getString(key);
		return msg == null ? "" : msg;
	}
	
	/**
	 * 導向至指定頁面
	 * @param pagePath
	 */
	protected String goTo(String pagePath) {
		_logger.info("goto: " + pagePath);
		navigateion.setSelectedIncludePath(pagePath);
		return _PAGE_MAIN_FRAME;
	}
	
	/**
	 * 執行redirect
	 * @param path
	 */
	protected void redirect(String path) {
		try {
			goTo(path);
			String page = getRequest().getContextPath() + "/" + _PAGE_MAIN_FRAME;
			FacesContext.getCurrentInstance().getExternalContext().redirect(page);
		} catch (IOException e) {}
	}
	
	/**
	 * 執行redirect至外部網站
	 * @param path
	 * @throws IOException 
	 */
	protected void redirectExternal(String path) {
		try {
			FacesContext.getCurrentInstance().getExternalContext().redirect(path);
		} catch (Exception ex) {
			Throwable rootCause = ExceptionUtils.getRootCause(ex);
			getLogger().error(rootCause.getMessage(), rootCause);
//			putExceptionLog(rootCause); // 記錄Exception log
		}
	}
	
	/**
	 * 取得HttpServletRequest
	 * @return
	 */
	public HttpServletRequest getRequest() {
		return (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
	}
	
	/**
	 * 取得request parameter
	 * @param paramName
	 * @return
	 */
	protected String getRequestParameter(String paramName) {
		return getRequest().getParameter(paramName);
	}
	
	/**
	 * 取得HttpServletResponse
	 * @return
	 */
	protected HttpServletResponse getResponse() {
		return (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();
	}
	
	/**
	 * 取得Backing Bean
	 * @param <V>
	 * @param beanName
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "hiding" })
	public <V> V findBean(String beanName) {
		FacesContext context = FacesContext.getCurrentInstance();
	    return (V) context.getApplication().evaluateExpressionGet(context, "#{" + beanName + "}", Object.class);
	}
	
	/**
	 * 取得登入者資訊
	 * @return
	 */
	public SessionProfile getUserProfile() {
		return (SessionProfile) getSession().getAttribute(Constants.SESSION_PROFILE);
	}
	
	/**
	 * 註冊導覽事件
	 */
	protected void registerNavigationEvent(NavigationListener listener) {
		navigateion.registryListener(listener);
	}
		
	/**
	 * 依頁面元件id取得Component
	 * @param componentId
	 * @return
	 */
	protected UIComponent findComponentById(final String componentId){
	    FacesContext context = FacesContext.getCurrentInstance(); 
	    UIViewRoot root = context.getViewRoot();
	    
	    final UIComponent[] found = new UIComponent[1];
	    root.visitTree(new FullVisitContext(context), new VisitCallback() {     
	        @Override
	        public VisitResult visit(VisitContext context, UIComponent component) {
	            if(component.getId().equals(componentId)){
	                found[0] = component;
	                return VisitResult.COMPLETE;
	            }
	            return VisitResult.ACCEPT;              
	        }
	    });
	    return found[0];
	}
	
//	/**
//	 * 取得單筆組態值
//	 * @param key
//	 * @return 
//	 */
//	public String getConfigValue(String key) {
//		return SystemConfig.getInstance().getConfigValue(key);
//	}
//	
//	/**
//	 * 取得多筆組態值
//	 * @param key
//	 * @return 
//	 */
//	public List<String> getConfigValues(String key) {
//		return SystemConfig.getInstance().getConfigValues(key);
//	}
//	
//	/**
//	 * 取得單筆組態值Vo物件
//	 * @param key
//	 * @return 
//	 */
//	public ConfigValueVo getConfigValueObj(String key) {
//		return SystemConfig.getInstance().getConfigValueObj(key);
//	}
//	
//	/**
//	 * 取得多筆組態值Vo物件
//	 * @param key
//	 * @return 
//	 */
//	public List<ConfigValueVo> getConfigValueObjs(String key) {
//		return SystemConfig.getInstance().getConfigValueObjs(key);
//	}
//	
//	/**
//	 * 依狀態取得多筆組態值
//	 * @param key
//	 * @param state
//	 * @return 
//	 */
//	public List<String> getConfigValues(String key, String state) {
//		return SystemConfig.getInstance().getConfigValues(key, state);
//	}
//	
//	/**
//	 * 依狀態取得多筆組態值Vo物件
//	 * @param key
//	 * @param state
//	 * @return 
//	 */
//	public List<ConfigValueVo> getConfigValueObjs(String key, String state) {
//		return SystemConfig.getInstance().getConfigValueObjs(key, state);
//	}
//	
//	/**
//	 * 依組態KEY取得單筆組態值
//	 * @param key
//	 * @param code
//	 * @return 
//	 */
//	public String getConfigValueByKey(String key, String code) {
//		return SystemConfig.getInstance().getConfigValueByKey(key, code);
//	}
//	
//	/**
//	 * 依組態KEY取得單筆組態值Vo物件
//	 * @param key
//	 * @param code
//	 * @return 
//	 */
//	public ConfigValueVo getConfigValueObjByKey(String key, String code) {
//		return SystemConfig.getInstance().getConfigValueObjByKey(key, code);
//	}
	
	/**
	 * 格式化訊息文字
	 * @param key
	 * @param texts
	 * @return
	 */
	protected String formatMessage(String bundleName, String key, String... texts) {
		String msg = getResourceBundle(bundleName).getString(key);
		if (msg != null) {
			if (texts != null && texts.length > 0) {
				msg = MessageFormat.format(msg, (Object[])texts);
			}
		}
		return msg;
	}
	
	/**
	 * 新增WORK_LOG
	 */
	protected void saveWorkLog(String function, WorkLogAction action, String content) {
		try {
			WorkLog workLog = new WorkLog();
			workLog.setLogTime(new Date());
			workLog.setAccount(getUserProfile().getUsername());
			workLog.setIp(getRequest().getRemoteHost());
			workLog.setFunc(function);
			workLog.setAction(action.toString());
			workLog.setContent(content);
			// 寫入db
			logService.insertWorkLog(workLog);

		} catch (Exception ex) {
			Throwable rootCause = ExceptionUtils.getRootCause(ex);
			getLogger().error(rootCause.getMessage(), rootCause);
		}
	}
	
//	/**
//	 * 新增WORK_LOG
//	 * @param category
//	 * @param action
//	 * @param msgKey
//	 * @param logArgv
//	 */
//	protected void putWorkLog(String category, ActionEnum action, String msgKey, String... logArgv) {
//		try {
//			if (StringUtils.isNotBlank(msgKey)) {
//				String logDetail = formatMessage(LOG_RESOURCE, msgKey, logArgv);
//				putWorkLog(category, action, logDetail);
//			}
//		} catch (Exception ex) {
//			Throwable rootCause = ExceptionUtils.getRootCause(ex);
//			getLogger().error(rootCause.getMessage(), rootCause);
//			putExceptionLog(rootCause); // 記錄Exception log
//		}
//	}
//	
//	/**
//	 * 新增EXCEPTION_LOG
//	 * @param rootCause
//	 */
//	private void putExceptionLog(Throwable rootCause) {
//		try {
//			systemService.insertExceptionLog(rootCause, rootCause.getStackTrace()[2]); // 寫入db
//		} catch (Exception ex) {
//			_logger.error("新增EXCEPTION_LOG失敗", ex);
//			getLogger().error(rootCause.getMessage(), ExceptionUtils.getRootCause(ex));
//		}
//	}
	
}
