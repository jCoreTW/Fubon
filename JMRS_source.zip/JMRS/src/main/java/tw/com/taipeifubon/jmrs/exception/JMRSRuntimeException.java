package tw.com.taipeifubon.jmrs.exception;

/**
 * <p>Title: tw.com.hjct.fos.ext.exception.JMRSRuntimeException</p>
 * <p>Description: 執行時期例外類別，丟出此例外不會導至錯誤頁，但會紀錄Exception log</p>
 * <p>Copyright: Copyright HJCT. 2014. All Rights Reserved.</p>
 * <p>Company: HJCT</p>
 * @author HJCT
 * @version 1.0
 */
@SuppressWarnings("serial")
public class JMRSRuntimeException extends RuntimeException {

	/**
     * JMRSRuntimeException 預設建構子
     */
    public JMRSRuntimeException() {
        super();
    }
    
    /**
     * JMRSRuntimeException 建構子
     * @param message 例外訊息
     */
    public JMRSRuntimeException(String message) {
        super(message);
    }
    
    /**
     * JMRSRuntimeException 建構子
     * @param message 例外訊息
     * @param cause 根源例外元素
     */
    public JMRSRuntimeException(String message, Throwable cause) {
        super(message, cause);
    }
    
    /**
     * JMRSRuntimeException 建構子
     * @param cause 根源例外元素
     */
    public JMRSRuntimeException(Throwable cause) {
        super(cause);
    }
}
