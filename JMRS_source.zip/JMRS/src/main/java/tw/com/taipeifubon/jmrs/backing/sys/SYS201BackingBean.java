package tw.com.taipeifubon.jmrs.backing.sys;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.SessionScoped;
import javax.faces.model.SelectItem;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.primefaces.PrimeFaces;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.factory.annotation.Autowired;

import tw.com.hjct.jmrs.dao.bean.Whitelist;
import tw.com.taipeifubon.jmrs.BackingBeanBase;
import tw.com.taipeifubon.jmrs.Constants.WorkLogAction;
import tw.com.taipeifubon.jmrs.service.SystemService;
import tw.com.taipeifubon.jmrs.vo.ConfigVo;

/**
 * <p>Title: tw.com.taipeifubon.jmrs.backing.sys.SYS201BackingBean</p>
 * <p>Description: Whitelist</p>
 * <p>Copyright: Copyright HJCT. 2020. All Rights Reserved.</p>
 * <p>Company: HJCT</p>
 * @author HJCT
 * @version 1.0
 */
@SuppressWarnings("serial")
@Named
@SessionScoped
public class SYS201BackingBean extends BackingBeanBase<SYS201ViewForm> {

	@Autowired
	private SystemService systemService;
	
	@Override
	protected void init() {
		List<SelectItem> roleItems = new ArrayList<>();
		ConfigVo config = systemService.selectAllConfigs().get("USER_ROLE");
		config.getConfigValueVos().forEach(valVo -> {
			roleItems.add(new SelectItem(valVo.getCode(), valVo.getCode()));
		});
		viewForm.setRoleItems(roleItems);
		
		List<SelectItem> domainItems = new ArrayList<>();
		config = systemService.selectAllConfigs().get("LDAP_DOMAIN");
		config.getConfigValueVos().forEach(valVo -> {
			domainItems.add(new SelectItem(valVo.getCode(), valVo.getCode()));
		});
		viewForm.setDomainItems(domainItems);
	}

	/**
	 * Reset
	 */
	public void doResetAction() {
		viewForm.setAccount("");
		viewForm.setDomain("");
		viewForm.setRole("");
	}
	
	public void doAddAction() {
		viewForm.setNewAccount("");
		viewForm.setNewDomain("");
		viewForm.setNewRole("");
		viewForm.setSelectedWhitelist(null);
	}
	
	/**
	 * Search
	 */
	public void doQueryAction() {
		viewForm.setWhitelist(systemService.selectWhitelist(
				StringUtils.isNotBlank(viewForm.getAccount()) ? ("%" + viewForm.getAccount() + "%") : "", 
				StringUtils.isNotBlank(viewForm.getDomain()) ? ("%" + viewForm.getDomain() + "%") : "",
				viewForm.getRole()
				));
	}
	
	/**
	 * Save
	 */
	public void doSaveAction() {
		if (validateValue()) {
			
			try {
				// 是否已存在
				Whitelist exist = systemService.findWhitelistByAccount(viewForm.getNewAccount());
				if (exist != null) {
					setComponentErrorMessage("newAccount", "msgs", "validate.duplicate");
					return;
				}
				
				Whitelist whitelist = new Whitelist();
				whitelist.setAccount(viewForm.getNewAccount());
				whitelist.setDomain(viewForm.getNewDomain());
				whitelist.setRole(viewForm.getNewRole());
				
				systemService.insertWhitelist(whitelist);
				
				// 工作日誌
				String logContent = String.format("Add Whitelist[ACCOUNT=%s]", viewForm.getNewAccount());
				saveWorkLog("Whitelist", WorkLogAction.Add, logContent);
				
				setGlobalMessageFormat("msgs", "info.create.success");
				
				doQueryAction();
				PrimeFaces.current().executeScript("PF('newDialog').hide();");
				
			} catch (Exception e) {
				_logger.error(e.getMessage(), e);
				setGlobalErrorMessageFormat("error.create.fail", e.getMessage());
			}
		}
	}
	
	private boolean validateValue() {
		boolean result = true;
		if (StringUtils.isBlank(viewForm.getNewAccount())) {
			setComponentErrorMessage("newAccount", "msgs", "validate.required");
			result = false;
		}
		
		if (StringUtils.isBlank(viewForm.getNewDomain())) {
			setComponentErrorMessage("newDomain", "msgs", "validate.required");
			result = false;
		}
		
		if (StringUtils.isBlank(viewForm.getNewRole())) {
			setComponentErrorMessage("newRole", "msgs", "validate.required");
			result = false;
		}
		return result;
	}
	
	public void doRowSelectAction(SelectEvent event) {
		Whitelist whitelist = (Whitelist) event.getObject();
		viewForm.setSelectedWhitelist(whitelist);
		viewForm.setNewAccount(whitelist.getAccount());
		viewForm.setNewDomain(whitelist.getDomain());
		viewForm.setNewRole(whitelist.getRole());
		
	}
	
	public void doUpdateAction() {
		if (validateValue()) {
			try {
				// 是否已存在
				Whitelist exist = systemService.findWhitelistByAccount(viewForm.getNewAccount());
				if (exist != null && !exist.getWhitelistId().equals(viewForm.getSelectedWhitelist().getWhitelistId())) {
					setComponentErrorMessage("newAccount", "msgs", "validate.duplicate");
					return;
				}
				
				Whitelist whitelist = viewForm.getSelectedWhitelist();
				String logContent = String.format("Update Whitelist[ACCOUNT=%s|%s][DOMAIN=%s|%s][ROLE=%s|%s]", 
						whitelist.getAccount(), viewForm.getNewAccount(),
						whitelist.getDomain(), viewForm.getNewDomain(),
						whitelist.getRole(), viewForm.getNewRole());
				
				whitelist.setAccount(viewForm.getNewAccount());
				whitelist.setDomain(viewForm.getNewDomain());
				whitelist.setRole(viewForm.getNewRole());
				
				systemService.updateWhitelist(whitelist);
				
				// 工作日誌
				saveWorkLog("Whitelist", WorkLogAction.Update, logContent);
				
				setGlobalMessageFormat("msgs", "info.update.success");
				
				doQueryAction();
				PrimeFaces.current().executeScript("PF('newDialog').hide();");
				
			} catch (Exception e) {
				_logger.error(e.getMessage(), e);
				setGlobalErrorMessageFormat("error.create.fail", e.getMessage());
			}
		}
	}
	
	/**
	 * Delete
	 */
	public void doDeleteAction() {
		try {
			systemService.deleteWhitelistByPK(viewForm.getSelectedWhitelist().getWhitelistId());
			setGlobalMessageFormat("msgs", "info.delete.success");
			
			// 工作日誌
			String logContent = String.format("Delete Whitelist[ACCOUNT=%s][DOMAIN=%s][ROLE=%s]", 
					viewForm.getSelectedWhitelist().getAccount(),
					viewForm.getSelectedWhitelist().getDomain(),
					viewForm.getSelectedWhitelist().getRole());
			saveWorkLog("Whitelist", WorkLogAction.Delete, logContent);
			
			doQueryAction();
			PrimeFaces.current().executeScript("PF('newDialog').hide();");
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
			setGlobalErrorMessageFormat("error.delete.fail", e.getMessage());
		}
		
	}
}
