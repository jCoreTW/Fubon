package tw.com.taipeifubon.jmrs.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tw.com.hjct.jmrs.dao.bean.Config;
import tw.com.hjct.jmrs.dao.bean.ConfigExample;
import tw.com.hjct.jmrs.dao.bean.ConfigValue;
import tw.com.hjct.jmrs.dao.bean.ConfigValueExample;
import tw.com.hjct.jmrs.dao.bean.ConfigValueExample.Criteria;
import tw.com.hjct.jmrs.dao.bean.ConfigValueKey;
import tw.com.hjct.jmrs.dao.bean.Whitelist;
import tw.com.hjct.jmrs.dao.bean.WhitelistExample;
import tw.com.hjct.jmrs.dao.mapper.ConfigMapper;
import tw.com.hjct.jmrs.dao.mapper.ConfigValueMapper;
import tw.com.hjct.jmrs.dao.mapper.CustomMapper;
import tw.com.hjct.jmrs.dao.mapper.WhitelistMapper;
import tw.com.taipeifubon.jmrs.vo.ConfigValueVo;
import tw.com.taipeifubon.jmrs.vo.ConfigVo;

@Service
public class SystemService {

	@Autowired
	private SqlSessionTemplate sqlTemplate;
	
	/**
	 * 取得組態設定
	 * @return
	 */
	public Map<String, ConfigVo> selectAllConfigs() {
		ConfigMapper configMapper = sqlTemplate.getMapper(ConfigMapper.class);
		ConfigValueMapper configValueMapper = sqlTemplate.getMapper(ConfigValueMapper.class);
		ConfigValueExample example = new ConfigValueExample();
		
		List<Config> configs = configMapper.selectByExample(new ConfigExample());
		Map<String, ConfigVo> result = new HashMap<>();
		for (Config conf : configs) {
			Criteria criteria = example.createCriteria();
			criteria.andConfigIdEqualTo(conf.getConfigId());
			List<ConfigValue> values = configValueMapper.selectByExample(example);
			List<ConfigValueVo> vos = new ArrayList<>();
			for (ConfigValue configValue : values) {
				ConfigValueVo vo = new ConfigValueVo();
				vo.setConfigId(conf.getConfigId());
				vo.setCode(configValue.getCode());
				vo.setConfigValue(configValue);
				vos.add(vo);
			}
			
			
			ConfigVo configVo = new ConfigVo();
			configVo.setConfig(conf);
			configVo.setConfigId(conf.getConfigId());
			configVo.setConfigValueVos(vos);
			result.put(conf.getKey(), configVo);
			
			example.clear();
		}
		
		return result;
	}
	
	public ConfigVo findConfigByKey(String key) {
		ConfigMapper configMapper = sqlTemplate.getMapper(ConfigMapper.class);
		ConfigExample configExample = new ConfigExample();
		ConfigExample.Criteria configCritera = configExample.createCriteria();
		configCritera.andKeyEqualTo(key);
		
		List<Config> configs = configMapper.selectByExample(configExample);
		if (configs.isEmpty()) {
			return null;
		}
		
		ConfigValueMapper configValueMapper = sqlTemplate.getMapper(ConfigValueMapper.class);
		ConfigValueExample example = new ConfigValueExample();
		
		List<ConfigVo> result = new ArrayList<>();
		for (Config conf : configs) {
			Criteria criteria = example.createCriteria();
			criteria.andConfigIdEqualTo(conf.getConfigId());
			List<ConfigValue> values = configValueMapper.selectByExample(example);
			List<ConfigValueVo> vos = new ArrayList<>();
			for (ConfigValue configValue : values) {
				ConfigValueVo vo = new ConfigValueVo();
				vo.setConfigId(conf.getConfigId());
				vo.setCode(configValue.getCode());
				vo.setConfigValue(configValue);
				vos.add(vo);
			}
			
			
			ConfigVo configVo = new ConfigVo();
			configVo.setConfig(conf);
			configVo.setConfigId(conf.getConfigId());
			configVo.setConfigValueVos(vos);
			result.add(configVo);
			
			example.clear();
		}
		
		return result.get(0);
	}
	
	/**
	 * 更新組態設定
	 * @param config
	 */
	public void updateSelective(Config config) {
		ConfigMapper configMapper = sqlTemplate.getMapper(ConfigMapper.class);
		configMapper.updateByPrimaryKey(config);
	}
	
	/**
	 * 查詢組態值
	 * @param key
	 * @return
	 */
	public ConfigValue findConfigValue(ConfigValueKey key) {
		ConfigValueMapper configValueMapper = sqlTemplate.getMapper(ConfigValueMapper.class);
		return configValueMapper.selectByPrimaryKey(key);
	}
	
	/**
	 * 新增組態值
	 * @param configValue
	 */
	public void insertConfigValue(ConfigValue configValue) {
		ConfigValueMapper configValueMapper = sqlTemplate.getMapper(ConfigValueMapper.class);
		configValueMapper.insert(configValue);
	}
	
	/**
	 * 更新組態值
	 * @param configValue
	 */
	public void updateConfigValue(ConfigValue configValue) {
		ConfigValueMapper configValueMapper = sqlTemplate.getMapper(ConfigValueMapper.class);
		configValueMapper.updateByPrimaryKey(configValue);
	}
	
	/**
	 * 刪除組態值
	 * @param key
	 */
	public void deleteConfigValue(ConfigValueKey key) {
		ConfigValueMapper configValueMapper = sqlTemplate.getMapper(ConfigValueMapper.class);
		configValueMapper.deleteByPrimaryKey(key);
	}
	
	/**
	 * 查詢白名單
	 * @param acct
	 * @param domain
	 * @param role
	 * @return
	 */
	public List<Whitelist> selectWhitelist(String acct, String domain, String role) {
		WhitelistMapper mapper = sqlTemplate.getMapper(WhitelistMapper.class);
		WhitelistExample example = new WhitelistExample();
		WhitelistExample.Criteria criteria = example.createCriteria();
		
		if (StringUtils.isNotBlank(acct)) {
			criteria.andAccountLike(acct);
		}
		
		if (StringUtils.isNotBlank(domain)) {
			criteria.andDomainLike(domain);
		}
		
		if (StringUtils.isNotBlank(role)) {
			criteria.andRoleEqualTo(role);
		}
		
		return mapper.selectByExample(example);
	}
	
	/**
	 * 查詢白名單
	 * @param account
	 * @return
	 */
	public Whitelist findWhitelistByAccount(String account) {
		WhitelistMapper mapper = sqlTemplate.getMapper(WhitelistMapper.class);
		WhitelistExample example = new WhitelistExample();
		WhitelistExample.Criteria criteria = example.createCriteria();
		
		criteria.andAccountEqualTo(account);
		
		List<Whitelist> result = mapper.selectByExample(example);
		if (result.isEmpty()) {
			return null;
		} else {
			return result.get(0);
		}
	}
	
	/**
	 * 新增白名單
	 * @param whitelist
	 */
	public void insertWhitelist(Whitelist whitelist) {
		CustomMapper seqMapper = sqlTemplate.getMapper(CustomMapper.class);
		WhitelistMapper mapper = sqlTemplate.getMapper(WhitelistMapper.class);
		whitelist.setWhitelistId(seqMapper.selectSequence("WHITELIST_SEQ"));
		mapper.insert(whitelist);
	}
	
	/**
	 * 更新白名單
	 * @param whitelist
	 */
	public void updateWhitelist(Whitelist whitelist) {
		WhitelistMapper mapper = sqlTemplate.getMapper(WhitelistMapper.class);
		mapper.updateByPrimaryKey(whitelist);
	}
	
	/**
	 * 刪除白名單
	 * @param whitelistId
	 */
	public void deleteWhitelistByPK(Integer whitelistId) {
		WhitelistMapper mapper = sqlTemplate.getMapper(WhitelistMapper.class);
		mapper.deleteByPrimaryKey(whitelistId);
	}
	
	/**
	 * 更新權限
	 * @param configId
	 * @param valueList
	 */
	@Transactional
	public void updatePermission(Integer configId, List<ConfigValue> valueList) {
		ConfigValueMapper configValueMapper = sqlTemplate.getMapper(ConfigValueMapper.class);
		ConfigValueExample example = new ConfigValueExample();
		ConfigValueExample.Criteria criteria = example.createCriteria();
		criteria.andConfigIdEqualTo(configId);
		configValueMapper.deleteByExample(example);
		
		for (ConfigValue value : valueList) {
			configValueMapper.insert(value);
		}
	}
}
