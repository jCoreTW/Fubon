package tw.com.taipeifubon.jmrs.listener;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * <p>Title: com.cbms.web.listener.SessionListener</p>
 * <p>Description: Session監聽器</p>
 * <p>Copyright: Copyright HJCT. 2014. All Rights Reserved.</p>
 * <p>Company: HJCT</p>
 * @author HJCT
 * @version 1.0
 */
@WebListener
public class SessionListener implements HttpSessionListener {

	/** 訊息追蹤 */
//	private static Logger _logger = Logger.getLogger(SessionListener.class);
	
	/** 線上人數 */
	private static int onlineCnt = 0;
	
	public void sessionCreated(HttpSessionEvent event) {
		onlineCnt++;
	}
	
	/**
	 * Session結束
	 */
	public void sessionDestroyed(HttpSessionEvent event) {
//		_logger.info("Session結束，清除暫存資料...");
		onlineCnt--;
	}

	public static int getOnlineCnt() {
		return onlineCnt;
	}
}
