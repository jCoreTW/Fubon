package tw.com.taipeifubon.jmrs.backing.reg;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.primefaces.PrimeFaces;
import org.primefaces.event.SelectEvent;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;

import tw.com.hjct.jmrs.dao.bean.SidbHousekeeping;
import tw.com.hjct.jmrs.dao.bean.SidbHousekeepingKey;
import tw.com.taipeifubon.jmrs.BackingBeanBase;
import tw.com.taipeifubon.jmrs.Constants.WorkLogAction;
import tw.com.taipeifubon.jmrs.service.RegisterService;

/**
 * <p>Title: tw.com.taipeifubon.jmrs.backing.reg.REG301BackingBean</p>
 * <p>Description: SIDB Housekeeping</p>
 * <p>Copyright: Copyright HJCT. 2020. All Rights Reserved.</p>
 * <p>Company: HJCT</p>
 * @author HJCT
 * @version 1.0
 */
@SuppressWarnings("serial")
@Named
@SessionScoped
public class REG301BackingBean extends BackingBeanBase<REG301ViewForm> {

	@Autowired
	private RegisterService registerService;
	
	@Override
	protected void init() {
		doAddOptions();
	}

	/**
	 * Search
	 */
	public void doSearchAction() {
		StringBuffer condition = new StringBuffer();
		String logical = viewForm.getLogical();
		
		for (int i = 0; i < viewForm.getParameters().size(); i++) {
			if (StringUtils.isNotBlank(viewForm.getParameters().get(i))) {
				String value = "'" + viewForm.getValues().get(i) + "'";
				if (viewForm.getOpts().get(i).indexOf("like") > -1) {
					value = "'%" + viewForm.getValues().get(i) + "%'";
					
				} else if (viewForm.getOpts().get(i).indexOf("in") > -1) {
					value = StringUtils.join(value.split(","), "','");
					value = "(" + value + ")";
				}
				
				condition.append(String.format(" (%s %s %s) ", 
						viewForm.getParameters().get(i),
						viewForm.getOpts().get(i),
						value));
				
			}
			
			if (i < viewForm.getParameters().size() - 1
					&& StringUtils.isNotBlank(viewForm.getParameters().get(i + 1))) {
				condition.append(logical);
			}
		}

		_logger.info("查詢條件 " + condition);
		
		String sql = "";
		if (condition.length() > 0) {
			sql = "where " + condition.toString();
		}
		
		viewForm.setHouseKeepings(registerService.selectSidbHousekeepings(sql));
		
		List<Boolean> ckbox = new ArrayList<>();
		for (int i = 0; i < viewForm.getHouseKeepings().size(); i++) {
			ckbox.add(false);
		}
		viewForm.setSelectCkbox(ckbox);
	}
	
	/**
	 * Reset
	 */
	public void doResetAction() {
		viewForm.setParameters(new ArrayList<>());
		viewForm.setOpts(new ArrayList<>());
		viewForm.setValues(new ArrayList<>());
		doAddOptions();
	}
	
	/**
	 * 新增選項
	 */
	public void doAddOptions() {
		viewForm.getParameters().add("");
		viewForm.getOpts().add("");
		viewForm.getValues().add("");
		viewForm.getSelectCkbox().add(false);
	}
	
	public void doSubOption(int index) {
		viewForm.getParameters().remove(index);
		viewForm.getOpts().remove(index);
		viewForm.getValues().remove(index);
//		viewForm.getSelectCkbox().remove(index);
	}
	
	/**
	 * Add
	 */
	public void doAddAction() {
		clearFields();
	}
	
	/**
	 * Save
	 */
	public void doSaveAction() {
		if (validateCreate()) {
			
			SidbHousekeepingKey key = new SidbHousekeepingKey();
			key.setColumnName(viewForm.getNewColumnName());
			key.setOwner(viewForm.getNewOwner());
			key.setTableName(viewForm.getNewTableName());
			SidbHousekeeping exist = registerService.findSidbHousekeepingByPk(key);
			if (exist != null) {
				//[200822:原錯誤訊息會超出訊息視窗，故改用預先定義的error.sidb.housekeeping.uniquie.key.error]
				//setGlobalErrorMessageFormat("msgs", "validate.data.duplicate", "Owner+Table_Name+Column_Name");
				setGlobalErrorMessageFormat("msgs", "error.sidb.housekeeping.uniquie.key.error");
				return;
			}
			
			SidbHousekeeping toSave = new SidbHousekeeping();
			toSave.setOwner(viewForm.getNewOwner());
			toSave.setTableName(viewForm.getNewTableName());
			toSave.setColumnName(viewForm.getNewColumnName());
			toSave.setPeriod(viewForm.getNewPeriod() + viewForm.getNewPeriodUnit());
			toSave.setRegistEmp(viewForm.getNewRegistEmp());
			toSave.setRcNum(viewForm.getNewRcNum());
			toSave.setFrequency(viewForm.getNewFrequency());
			
			try {
				registerService.insertSidbHousekeeping(toSave);
				clearFields();
				
				// 工作日誌
				String logContent = String.format("Add SidbHousekeeping[COLUMN_NAME=%s][OWNER=%s][TABLE_NAME=%s]", 
						toSave.getColumnName(), toSave.getOwner(), toSave.getTableName());
				saveWorkLog("SidbHousekeeping", WorkLogAction.Add, logContent);
				
				setGlobalMessageFormat("msgs", "info.create.success");
				
			} catch (Exception e) {
				_logger.error(e.getMessage(), e);
				setGlobalErrorMessageFormat("msgs", "error.create.fail");
			}
			
		}
	}
	
	private boolean validateCreate() {
		boolean result = true;
		if (StringUtils.isBlank(viewForm.getNewOwner())) {
			setComponentErrorMessage("newOwner", "msgs", "validate.required");
			result = false;
		}
		
		if (StringUtils.isBlank(viewForm.getNewTableName())) {
			setComponentErrorMessage("newTableName", "msgs", "validate.required");
			result = false;
		}
		
		if (StringUtils.isBlank(viewForm.getNewColumnName())) {
			setComponentErrorMessage("newColumnName", "msgs", "validate.required");
			result = false;
		}
		
		if (StringUtils.isBlank(viewForm.getNewPeriod())) {
			setComponentErrorMessage("newPeriod", "msgs", "validate.required");
			result = false;
		}
		
		if (StringUtils.isBlank(viewForm.getNewRegistEmp())) {
			setComponentErrorMessage("newRegistEmp", "msgs", "validate.required");
			result = false;
		}
		
		/*[200822:doUpdateAction呼叫validateCreate無法透過以下邏輯進行duplicate檢核，故取消，改catch DuplicateKeyException]
		if (result) {
			SidbHousekeeping exist = registerService.findSidbHousekeepingByPrimaryKey(viewForm.getNewOwner(), viewForm.getNewTableName(), viewForm.getNewColumnName());
			if (exist != null) {
				setGlobalErrorMessageFormat("msgs", "error.sidb.housekeeping.uniquie.key.error");
				result = false;
			}
		}
		*/
		
		return result;
	}
	
	private void clearFields() {
		viewForm.setNewOwner("");
		viewForm.setNewTableName("");
		viewForm.setNewColumnName("");
		viewForm.setNewPeriod("");
		viewForm.setNewPeriodUnit("M");
		viewForm.setNewRegistEmp("");
		viewForm.setNewRcNum("");
		viewForm.setNewFrequency("");
		viewForm.setSelectHousekeeping(null);
	}
	
	public boolean getDisplayDeleteBtn() {
		for (Boolean b : viewForm.getSelectCkbox()) {
			if (b) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Delete
	 * @param info
	 */
	public void doDeleteOneAction(SidbHousekeeping hk) {
		try {
			if (hk == null) {
				hk = viewForm.getSelectHousekeeping();
			}
			
			SidbHousekeepingKey pk = new SidbHousekeepingKey();
			pk.setColumnName(hk.getColumnName());
			pk.setOwner(hk.getOwner());
			pk.setTableName(hk.getTableName());
			registerService.deleteSidbHousekeepingByPk(pk);
			
			// 工作日誌
			String logContent = String.format("Delete SidbHousekeeping[OWNER=%s][TABLE_NAME=%s][COLUMN_NAME=%s][PERIOD=%s][REGIST_EMP=%s][RC_NUM=%s][FREQUENCY=%s]", 
					hk.getOwner(), hk.getTableName(), hk.getColumnName(), hk.getPeriod(),
					hk.getRegistEmp(), hk.getRcNum(), hk.getFrequency());
			saveWorkLog("SidbHousekeeping", WorkLogAction.Delete, logContent);
			
			doSearchAction();
			setGlobalMessageFormat("msgs", "info.delete.success");
			
			PrimeFaces.current().executeScript("PF('newDialog').hide()");
			
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
			setGlobalErrorMessageFormat("msgs", "error.delete.fail");
		}
		
	}
	
	/**
	 * delete selected
	 */
	public void doDeleteSelectAction() {
		List<SidbHousekeeping> toDelete = new ArrayList<>();
		List<String> logs = new ArrayList<>();
		
		for (int i = 0; i < viewForm.getSelectCkbox().size(); i++) {
			if (viewForm.getSelectCkbox().get(i)) {
				SidbHousekeeping hk = viewForm.getHouseKeepings().get(i);
				toDelete.add(hk);
				
				String logContent = String.format("Delete SidbHousekeeping[OWNER=%s][TABLE_NAME=%s][COLUMN_NAME=%s][PERIOD=%s][REGIST_EMP=%s][RC_NUM=%s][FREQUENCY=%s]", 
						hk.getOwner(), hk.getTableName(), hk.getColumnName(), hk.getPeriod(),
						hk.getRegistEmp(), hk.getRcNum(), hk.getFrequency());
				logs.add(logContent);
			}
		}
		
		try {
			registerService.deleteSidbHousekeepings(toDelete);
			// 工作日誌
			for (String logContent : logs) {
				saveWorkLog("SidbHousekeeping", WorkLogAction.Delete, logContent);
			}
			
			doSearchAction();
			setGlobalMessageFormat("msgs", "info.delete.success");
			
		} catch (Exception e) {
			_logger.error(e.getMessage(), e);
			setGlobalErrorMessageFormat("msgs", "error.delete.fail");
		}
		
	}
	
	/**
	 * 
	 * @param event
	 */
	public void doRowSelectAction(SelectEvent event) {
		SidbHousekeeping hk = (SidbHousekeeping) event.getObject();
		viewForm.setNewOwner(hk.getOwner());
		viewForm.setNewTableName(hk.getTableName());
		viewForm.setNewColumnName(hk.getColumnName());
		viewForm.setNewPeriod(StringUtils.left(hk.getPeriod(), hk.getPeriod().length() - 1));
		viewForm.setNewPeriodUnit(StringUtils.right(hk.getPeriod(), 1));
		viewForm.setNewRegistEmp(hk.getRegistEmp());
		viewForm.setNewRcNum(hk.getRcNum());
		viewForm.setNewFrequency(hk.getFrequency());
		viewForm.setSelectHousekeeping(hk);
	}
	
	/**
	 * Update
	 */
	public void doUpdateAction() {
		if (validateCreate()) {
			
			SidbHousekeeping src = viewForm.getSelectHousekeeping();
			SidbHousekeeping toUpdate = new SidbHousekeeping();
			BeanUtils.copyProperties(src, toUpdate);
			
			toUpdate.setOwner(viewForm.getNewOwner());
			toUpdate.setTableName(viewForm.getNewTableName());
			toUpdate.setColumnName(viewForm.getNewColumnName());
			toUpdate.setPeriod(viewForm.getNewPeriod() + viewForm.getNewPeriodUnit());
			toUpdate.setRegistEmp(viewForm.getNewRegistEmp());
			toUpdate.setRcNum(viewForm.getNewRcNum());
			toUpdate.setFrequency(viewForm.getNewFrequency());
			
			try {
				SidbHousekeepingKey pk = new SidbHousekeepingKey();
				pk.setOwner(src.getOwner());
				pk.setColumnName(src.getColumnName());
				pk.setTableName(src.getTableName());
				registerService.updateSidbHousekeepingByPk(toUpdate, pk);
				
				// 工作日誌
				String logContent = String.format("Update SidbHousekeeping[OWNER=%s|%s][TABLE_NAME=%s|%s][COLUMN_NAME=%s|%s][PERIOD=%s|%s][REGIST_EMP=%s|%s][RC_NUM=%s|%s][FREQUENCY=%s|%s]", 
						src.getOwner(), toUpdate.getOwner(),
						src.getTableName(), toUpdate.getTableName(), 
						src.getColumnName(), toUpdate.getColumnName(), 
						src.getPeriod(), toUpdate.getPeriod(),
						src.getRegistEmp(), toUpdate.getRegistEmp(), 
						src.getRcNum(), toUpdate.getRcNum(),
						src.getFrequency(), toUpdate.getFrequency());
				saveWorkLog("SidbHousekeeping", WorkLogAction.Update, logContent);
				
				doSearchAction();
				setGlobalMessageFormat("msgs", "info.update.success");
				
				PrimeFaces.current().executeScript("PF('newDialog').hide()");
				
			} catch (DuplicateKeyException e) {
				//[200822:更新時Unique Key duplicate check]
				setGlobalErrorMessageFormat("msgs", "error.sidb.housekeeping.uniquie.key.error");
			} catch (Exception e) {
				_logger.error(e.getMessage(), e);
				setGlobalErrorMessageFormat("msgs", "error.update.fail");
			}
			
		}
	}
}
