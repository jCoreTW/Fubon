package tw.com.taipeifubon.jmrs.backing.sys;

import java.util.Date;
import java.util.concurrent.TimeUnit;

import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import org.springframework.beans.factory.annotation.Autowired;

import tw.com.taipeifubon.jmrs.BackingBeanBase;
import tw.com.taipeifubon.jmrs.service.LogService;

/**
 * <p>Title: tw.com.taipeifubon.jmrs.backing.sys.SYS301BackingBean</p>
 * <p>Description: WorkLog</p>
 * <p>Copyright: Copyright HJCT. 2020. All Rights Reserved.</p>
 * <p>Company: HJCT</p>
 * @author HJCT
 * @version 1.0
 */
@SuppressWarnings("serial")
@Named
@SessionScoped
public class SYS301BackingBean extends BackingBeanBase<SYS301ViewForm> {

	@Autowired
	private LogService logService;
	
	@Override
	protected void init() {
		viewForm.setStartDate(new Date());
		viewForm.setEndDate(new Date());
	}

	/**
	 * Reset
	 */
	public void doResetAction() {
		viewForm.setStartDate(new Date());
		viewForm.setEndDate(new Date());
		viewForm.setAccount("");
		viewForm.setIp("");
		viewForm.setFunction("");
		viewForm.setAction("");
		viewForm.setContent("");
	}
	
	/**
	 * Search
	 */
	public void doSearchAction() {
		long diffInMillies = Math.abs(viewForm.getEndDate().getTime() - viewForm.getStartDate().getTime());
	    long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
		if (diff > 90) {
			setComponentErrorMessage("collDtS", "msgs", "validate.date.out.of.range");
			return;
		}
		
		viewForm.setWorkLogs(logService.selectWorkLog(viewForm.getStartDate(), viewForm.getEndDate(), 
				viewForm.getAccount(), viewForm.getIp(), viewForm.getFunction(), viewForm.getAction(), 
				viewForm.getContent()));
	}
}
