package tw.com.taipeifubon.jmrs;

import org.jasypt.encryption.StringEncryptor;
import org.jasypt.util.text.BasicTextEncryptor;

public class ConfigEncrypt {

	public static void main(String[] args) {
		BasicTextEncryptor textEncryptor = new BasicTextEncryptor();
		//設定密碼，與 application.properties 相同
		textEncryptor.setPassword("!!!yourpassword!!!");
		//要加密的資訊
		String username = textEncryptor.encrypt("ods_system");
		String password = textEncryptor.encrypt("!QAZ2wsx");
		System.out.println("username:"+username);
		System.out.println("password:"+password);
		System.out.println("username:"+textEncryptor.decrypt(username));
		System.out.println("password:"+textEncryptor.decrypt(password));
		
		
		StringEncryptor encryptor = AppConfig.stringEncryptor();
        
        username = encryptor.encrypt("ods_system");
		password = encryptor.encrypt("!QAZ2wsx");
		System.out.println("username:"+username);
		System.out.println("password:"+password);
		System.out.println("username:"+encryptor.decrypt("iNiAIM9FeDmz9zn0FPvmHk0wST0EzZzd"));
		System.out.println("password:"+encryptor.decrypt("nIzZeB+gHuhMG2fjhVJsfw=="));
	}

}
